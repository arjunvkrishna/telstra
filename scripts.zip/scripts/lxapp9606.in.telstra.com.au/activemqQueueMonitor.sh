#!/bin/bash/
#####################################################################
#####################################################################
# Script name: activemqQueueMonitor.sh
# Description: This script will monitor the ActiveMQ queues and
#              report if there are Pending messages in Queues.It is
#              scheduled to run every hour on Cron
# Date       : 11-Mar-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################
PATH=/opt/knowesis/sift/orchestrator/jdk1.8.0_45/bin:/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/siftuser/bin:/data/knowesis/sift/orchestrator/jdk1.8.0_45/bin

# Variables 
activemqPath="/opt/knowesis/sift/orchestrator/apache-activemq-5.14.2/bin"
QueueLogFile="/home/siftuser/PSNM_Scripts/HealthCheck/ActiveMqQueueLog.`date +%F`.log"
StatsLogFile="/home/siftuser/PSNM_Scripts/HealthCheck/Stats_ActiveMq.`date +%F`.log"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo "Usage: sh activemqQueueMonitor.sh"
    echo "This script will monitor the ActiveMQ queues and"
    echo "will report if there are Pending messages in Queues"

}

#####################################################################
# Function    : sendEmailAlert
# Description : 
#
#
#####################################################################
function sendEmailAlert ()
{
    hostname=`uname -n`
    emailSubject="SIFT EMAIL ALERT "\!\!\!" $hostname Pending Queue Status - `date +%F`"
    toAddressArray=('bhuvan.siddaramu@infosys.com' 'Manoj_Kumar51@infosys.com' 'Shiju_R@infosys.com')
    ccAddressArray=('Anshul.Tiwari@team.telstra.com' 'Rao.Sanagapalli@team.telstra.com' 'Brett.L.Born@team.telstra.com' 'Kathy.Hudson@team.telstra.com')

    prevHour=`date -d '1 hour ago' "+%H:"`
    currHour=`date "+%H:"`
    prevHourQueueLogFile="/home/siftuser/PSNM_Scripts/HealthCheck/prevHourQueueLog.`date +%F`.log"
    currHourQueueLogFile="/home/siftuser/PSNM_Scripts/HealthCheck/currHourQueueLog.`date +%F`.log"
    ignoreLinePattern=`date +%F`
 
    cat $QueueLogFile | sed -n "/"$prevHour"/,/"$prevHour"/p" > $prevHourQueueLogFile
    cat $QueueLogFile | sed -n "/"$currHour"/,/"$currHour"/p" > $currHourQueueLogFile

    if [ $currHour <> "00:" ]
    then
        #Do a silent diff to find changes from the previous hour
        diff -q -I "$ignoreLinePattern" "$prevHourQueueLogFile" "$currHourQueueLogFile"
        if [ $? -ne 0 ];
        then
            #send email alert
            cat $currHourQueueLogFile | mailx -s "`echo $emailSubject`" -S smtp=mail.in.telstra.com.au "`echo ${toAddressArray[*]}`" 
        fi
    fi

    if [ $currHour = "00:" ]; then
        #send email alert
        cat $currHourQueueLogFile | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`" 
    fi

    # Delete the temp files
    rm -f $prevHourQueueLogFile
    rm -f $currHourQueueLogFile
    
}


#####################################################################
# Function    : getQueuesInfo
# Description : This will run the command line utlity provided by 
#               ActiveMQ to extract the stats and reports all queues
#               which have pending messages (non-zero)
#####################################################################
function getQueuesInfo ()
{
    cd $activemqPath
    echo "==========================================================" | tee -a $QueueLogFile
    echo "`date '+%F %T'` | INFO | Server: `uname -n` | Queue status " | tee -a $QueueLogFile
    queue_count=$(./activemq dstat queues | sed -n '/dead/,$p' | awk '($2>0){print $1,$2}'|wc -l)
    if [ $queue_count -gt 0 ]; then
        #Dump same into log file 
        ./activemq dstat queues | sed -n '/dead/,$p' | awk '($2>0){print $1,$2}' >> $QueueLogFile
        echo "`date '+%F %T'` | WARN | Pending messages in Activemq Queues" | tee -a $QueueLogFile
        sendEmailAlert
    else
        echo "`date '+%F %T'` | INFO | No Pending messages in Activemq Queues" | tee -a $QueueLogFile
    fi
    echo "==========================================================" | tee -a $QueueLogFile
}


#####################################################################
# Function    : getStats
# Description : This will run the command line utlity provided by 
#               ActiveMQ to extract the stats and reports all queues
#               which have pending messages (non-zero)
#####################################################################
function getStats ()
{
    echo "==========================================================" >> $StatsLogFile
    echo "`date '+%F %T'` | INFO | Server: `uname -n` | ActiveMQ Stats " >> $StatsLogFile
    ./activemq dstat queues | sed -n '/Name/,$p' | awk '($4!=0 || $2!=0) {print}' >> $StatsLogFile
    echo "==========================================================" >> $StatsLogFile
}

#####################################################################
#main
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" -o $# -gt 0 ]
then
    usage
    exit 0
fi

getQueuesInfo
getStats

