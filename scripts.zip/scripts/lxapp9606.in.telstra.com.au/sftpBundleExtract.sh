#!/bin/bash
#########################################
## sftpBundleExtract Script 
#########################################

#running the script 
#bash sftpBundleExtract.sh

#Script Dir. Configs.
BUNDLE_EXTRACT_PATH=/opt/knowesis/sift/orchestrator/sift-stitcher/data/output
EXTRACT_FILE_NAME=Orpheus_Bundle_Extract_$(date +"%Y%m%d")_1.csv
EXTRACT_FILE_HEADER=SERVICENO,BALANCE_NAME,BALANCE_CLASS,BALANCE_TYPE,BALANCE_UNIT,BALANCE_AMOUNT,BALANCE_THRESHOLD,BALANCE_START_DATE_TIME,BALANCE_END_DATE_TIME,PERIODICITY,NO_OF_PERIODS,BALANCE_AS_OF_DATE,LASTUPDATETIME
# PROCESSED_PATH=

#Script Dir. Configs.
SCRIPT_HOME=/opt/knowesis/sift/scripts/exec
LOG_DIR=/opt/knowesis/sift/scripts/log
DATE_LOG=$(date +"%Y%m")
LOG_FILE=$LOG_DIR/sftpBundleExtract_$DATE_LOG.log


#sftp credentials config
KEY_FILE=/home/siftuser/.ssh/id_rsa
DESTINATION_USER=OPOLO_SFX_P01
DESTINATION_SERVER=10.75.65.163
DESTINATION_PATH=/SFMC/OPOLO_SFMC/toSFMC
PGP_USER_ID=Vivian.Wang@team.telstra.com

#Logger Function
function logger {
    echo "$(date) | $1" >> $LOG_FILE
}


# Function to transfer file to remote server
function fileTransferFunc {

		fileName=$1

		logger "INFO  | attempting encryption of file -> $fileName to $fileName.pgp"
		gpg -o $fileName.pgp -r ${PGP_USER_ID} -e $fileName

		if [ $? -eq 0 ];
		then
			fileToTransfer=$fileName.pgp
			#sftp
	    	sftp -o "IdentityFile=${KEY_FILE}" ${DESTINATION_USER}@${DESTINATION_SERVER} <<EOF
	     	put $fileToTransfer ${DESTINATION_PATH}
	     	quit
EOF
			status=$?
		fi
		return $status
}


logger "INFO  | ######### Starting Process ..!"

#check if the dir contains the ExtractFile
if [ ! -f ${BUNDLE_EXTRACT_PATH}/${EXTRACT_FILE_NAME%.*}.eot ];
then
	logger "ERROR | Extract file not found for transfer..! "
else
	#adding headerRow to the Extract File
	sed -i '1i '$EXTRACT_FILE_HEADER'' ${BUNDLE_EXTRACT_PATH}/${EXTRACT_FILE_NAME}
	if [ $? -eq 0 ];
    then
        logger "INFO  | HeaderRow appended successfully with Status : $?"
    else
     	logger "ERROR | Appending HeaderRow failed with Status : $?"
    fi

	#calling fileTransfer function to send out the files
	fileTransferFunc ${BUNDLE_EXTRACT_PATH}/${EXTRACT_FILE_NAME}
	if [ $? -eq 0 ];
    then
        logger "INFO  | SFTP successful. Status : $?"
        # mv $BUNDLE_EXTRACT_PATH/* DESTINATION_PATH
    else
     	logger "ERROR | SFTP failed with Status : $?"
    fi
fi

logger "INFO  | ######### Completed Processing ..!"
