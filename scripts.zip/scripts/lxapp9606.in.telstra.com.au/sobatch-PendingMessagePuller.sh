#! /bin/sh

HANDLER_NAME='Batch Pending-Message-Puller Handler'
PID_FILE_NAME=.batch_pending_message_puller.pid
LOG4J_PROPERTIES_FILENAME=log4j-athenian-pending.properties
FLOW_JAR_NAME=sift-athenian-pending-msg-handler-1.0.0-SNAPSHOT.jar
SYSOUT_LOG_NAME=batch_athenian_pending-msg_sysout.log

source /opt/knowesis/sift/orchestrator/batchHandlers/bin/sobatch-common.sh
