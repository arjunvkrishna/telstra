PATH=/opt/knowesis/sift/orchestrator/jdk1.8.0_45/bin:/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/siftuser/bin:/data/knowesis/sift/orchestrator/jdk1.8.0_45/bin

# Variables
activemqPath="/opt/knowesis/sift/orchestrator/apache-activemq-5.14.2/bin"

cd $activemqPath

./activemq purge db.req.bad.queue

