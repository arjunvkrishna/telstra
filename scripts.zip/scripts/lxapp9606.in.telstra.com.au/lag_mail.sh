#!/bin/bash
export PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/siftuser/bin:/opt/knowesis/sift/orchestrator/jdk1.8.0_45/jre/bin


#to="odcsupport@knowesis.com,soumya@knowesis.com"
to="odcsupport@knowesis.com,Manoj_Kumar51@infosys.com,sumit.srivastava02@infosys.com,rajani.jagga@infosys.com,shinu.antony01@infosys.com,telstra_athenian@infosys.com,ajith@knowesis.com, 1391cbfc.knowesis.com@apac.teams.ms"

dt=$(date +"%Y%m%d")

#count=$(sh /home/siftuser/kcommands/pandalagscount.sh | awk '{sum+=$1}END{print sum}')
count=$(for i in {0..4}
do
/opt/knowesis/sift/queues/confluent-5.4.0/bin/kafka-consumer-groups --describe --group SiftDSConsumer_${i} --bootstrap-server lxapp9606.in.telstra.com.au:9092,lxapp9607.in.telstra.com.au:9092,lxapp9608.in.telstra.com.au:9092 | awk '{sum+=$6}END {print sum}'
done| awk '{sum+=$1}END{print sum}'
)
LOG_FILE=/home/siftuser/kcommands/panda_lag_$dt.log
echo $(date)","$count>>$LOG_FILE
#echo "Count =$count"
#threshold=100000
threshold=500000
if [ "$count" -ge "$threshold" ] ; then
	echo "Panda Kafka Total Count is high-$count on $(date). "|mail -s "[Opolo] Panda Lag Alert!" -S smtp=mail.in.telstra.com.au "$to"
else
	echo "Count is less"
fi


