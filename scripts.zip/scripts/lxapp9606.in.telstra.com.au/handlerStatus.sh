#!/bin/bash

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# title           : handlerStatus.sh
# description     : This script checks the handlerStatus.
# author          : SIFT SO Team
# version         : 0.0.1    
# usage           : bash handlerStatus.sh
# 
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#configs
SO_HOME="/data/knowesis/opolo/orchestrator"
SO_HANDLERS="opolo-recordkeeper so-configdumphandler so-ocsil-fulfilmenthandler so-patternmanager"

#script config
SCRIPT_HOME=$(dirname `pwd`)
SCRIPT_LOG_FILE=${SCRIPT_HOME}/log/handlerStatus_$(date +"%Y%m").log

#mail configs
TO="TelstraSalesForcePersonalisationCloudsupport@team.telstra.com,sonal.winston@infosys.com,mohammedsuhayab.r@infosys.com,anjana.ramachandran@infosys.com,akshai.saju@infosys.com,1391cbfc.knowesis.com@apac.teams.ms"
ALERT_SUB="[OPOLO] SO Handler Status Check [ALERT!!]"
MAIL_SERVER="mail.in.telstra.com.au"

#decleration
declare -a HANDLERS_DOWN

#Logger Function
function logger {
    echo "$(date +"%m-%d-%Y %H:%M:%S") | $1" >> ${SCRIPT_LOG_FILE}
}

#going to handler-scripts path and check for status
cd ${SO_HOME}/bin
for eachHandler in $SO_HANDLERS
do
        PROCESS_STATUS=$( bash $eachHandler'.sh' status )
        if [[ $PROCESS_STATUS == *"not found"* ]]; then
                HANDLERS_DOWN+=( $eachHandler )
        fi
done
cd -

#sending mail alert part
if [[ ! -z "$HANDLERS_DOWN" ]]; then
	HANDLERS_DOWN_STRING=${HANDLERS_DOWN[*]}        
	COMMA_SEP_HANDLER_LIST=`echo "${HANDLERS_DOWN_STRING//${IFS:0:1}/,}"`
	
        #preparing mail alert
        echo "SO Handlers: ${COMMA_SEP_HANDLER_LIST} down on $(hostname) as on $(date)" | mailx -s "${ALERT_SUB}" -S smtp=${MAIL_SERVER} "${TO}"
        logger "ERROR  | SO Handlers:${COMMA_SEP_HANDLER_LIST} down on $(hostname), sent alert with Status : $?"
else
        logger "INFO  | All SO handlers are up and running"
fi
