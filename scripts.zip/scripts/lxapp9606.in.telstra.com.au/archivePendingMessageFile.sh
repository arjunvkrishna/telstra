#!/bin/sh

exec >> /opt/knowesis/sift/orchestrator/batchHandlers/scripts/logs/PendingMessageArchiveLogs_`date +%F`.log
echo "****************** Starting archiving folder $DATE_FOLDER_TO_ARCHIVE at `date`*******************"

if [ $# -ne 2 ]
then
	echo "Paramteres provided is not correct. Correct Parameters : Folder path containing the daily folders to archive, Archive folder path"
	exit
fi

INPUT_FOLDER_PATH=$1
ARCHIVE_FOLDER_PATH=$2

DATE_FOLDER_TO_ARCHIVE=`date +%Y%m%d --date="yesterday"`

if [ ! -d $DATE_FOLDER_TO_ARCHIVE ]
then
	echo "Yesterday folder doesn't exist. Nothing to Archive"
	exit
fi

tar -cvzf ${ARCHIVE_FOLDER_PATH}/${DATE_FOLDER_TO_ARCHIVE}.tar.gz ${INPUT_FOLDER_PATH}/${DATE_FOLDER_TO_ARCHIVE}

echo "****************** Finished archiving folder $DATE_FOLDER_TO_ARCHIVE at `date`*******************"
