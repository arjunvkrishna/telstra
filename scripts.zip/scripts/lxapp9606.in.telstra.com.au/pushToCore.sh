#! /bin/bash

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#title           :pushToCore.sh
#description     :This script copies the balance snapshot file from core to SO
#author          :SIFT Team
#version         :0.0.1
#				 :0.0.2 - PSNM Update to Filter Active Customer Alone From Sticthed Output, using Mystique Input				
#usage           :bash pushToCore.sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Core user with which the user should connect
CORE_USER=siftuser
#Core host name
CORE_SERVER=lxapp9604.in.telstra.com.au
CORE_BAL_INPUT=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/BUNDLE_SNAPSHOT/
CORE_COPY_TEMP=/data/BUNDLE_COPY_TEMP/
MYST_INPUT_PATH=/data/knowesis/sift/orchestrator/sift-stitcher/data/mystique_input
STITCH_OUTPUT_DIR=/opt/knowesis/sift/orchestrator/sift-stitcher/data/output/BAL_BUNDLE*`date "+%Y%m%d"`*
COMPARE_INPUT_DIR=/opt/knowesis/sift/orchestrator/sift-stitcher/data/compare/input/
COMPARE_OUTPUT=/opt/knowesis/sift/orchestrator/sift-stitcher/data/compare/output/OUTPUT_`date "+%Y%m%d"`.txt
SPLIT_PATH=/opt/knowesis/sift/orchestrator/sift-stitcher/data/split
SPLIT_FILE_NAME=$SPLIT_PATH/SPLIT
BUNDLE_OUTPUT_DIR=$SPLIT_PATH/BAL_BUNDLE*`date "+%Y%m%d"`*
#This is the input directory for stitching utility for SO
#BUNDLE_INPUT_DIR=/opt/knowesis/sift/orchestrator/sift-stitcher/sample/input/


LOG_PATH=/opt/knowesis/sift/orchestrator/sift-stitcher/log
exec 1>> $LOG_PATH/PushtoCore`date "+%Y%m"`.log
exec 2>> $LOG_PATH/PushtoCore`date "+%Y%m"`.err

#Removing Older Files From SPLIT PATH
echo "`date` [INFO]  | Removing Older Files From SPLIT PATH Started"
rm -f $SPLIT_PATH/BAL_BUNDLE_`date -d'1 days ago' "+%Y%m%d"`*.csv
echo "`date` [INFO]  | Removing Older Files From SPLIT PATH Completed"

#Combining Mystique Input Files to Single File
echo "`date` [INFO]  | Combining Mystique Input Files to Single File Started"
cat $MYST_INPUT_PATH/msisdn*.csv >> $MYST_INPUT_PATH/mystique_input.txt
echo "`date` [INFO]  | Combining Mystique Input Files to Single File Completed"


#Move the Files From STICTHING OUTPUT to COMPARE Input
echo "`date` [INFO]  | Move the Files From STICTHING OUTPUT to COMPARE INPUT Started"
mv $STITCH_OUTPUT_DIR $COMPARE_INPUT_DIR
COMPARE_INPUT_FILE_NAME=$COMPARE_INPUT_DIR/BAL_BUNDLE*`date "+%Y%m%d"`*
echo "`date` [INFO]  | Record Count of Stitch Output: `wc -l $COMPARE_INPUT_FILE_NAME | grep 'total'`"
echo "`date` [INFO]  | Move the Files From STICTHING OUTPUT to COMPARE INPUT Completed"


#Compare Combined Mystique File Against Files in Compare Input and Filter Out Inactive MSISDNs
echo "`date` [INFO]  | Compare and Filter Only Active MSISDNS Started"
awk -F',' 'FNR==NR{a[$1]++;next}a[$2]' $MYST_INPUT_PATH/mystique_input.txt $COMPARE_INPUT_DIR/BAL_BUNDLE*`date "+%Y%m%d"`* > $COMPARE_OUTPUT
echo "`date` [INFO]  | Compare and Filter Only Active MSISDNS Completed"
echo "`date` [INFO]  | Record Count of Active Only Output: `wc -l $COMPARE_OUTPUT`"

#Split Active File to Small Chunks and Rename
echo "`date` [INFO]  | Split File With Active MSISDNs Alone to Small Chunks Started"
NoOfFiles=100
LineCount=`wc -l $COMPARE_OUTPUT | cut -f1 -d' '`
SplitCount=$((($LineCount + ($NoOfFiles - 1)) / $NoOfFiles))
#split -l $SplitCount $COMPARE_OUTPUT $SPLIT_FILE_NAME
split -l $SplitCount --numeric-suffixes $COMPARE_OUTPUT $SPLIT_PATH/BAL_BUNDLE_`date "+%Y%m%d"`_
echo "`date` [INFO]  | Split File With Active MSISDNs Alone to Small Chunks Completed"

#Renaming Split Files to Name Expected by CORE
echo "`date` [INFO]  | Renaming Split Files Started"
find $SPLIT_PATH/BAL_BUNDLE* -type f -exec mv '{}' '{}'.csv \;
echo "`date` [INFO]  | Renaming Split Files Completed"

#The while loop below polls for any stitched output file. The following parameters control how many times will it poll and after how long.
feeder_delay=20m
echo "`date` [INFO]  |moving batch 1"
scp $BUNDLE_OUTPUT_DIR*_0*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_0*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  | moving batch 2"
scp $BUNDLE_OUTPUT_DIR*_1*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_1*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 3"
scp $BUNDLE_OUTPUT_DIR*_2*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_2*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 4"
scp $BUNDLE_OUTPUT_DIR*_3*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_3*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 5"

scp $BUNDLE_OUTPUT_DIR*_4*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_4*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 6"
scp $BUNDLE_OUTPUT_DIR*_5*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_5*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 7"

scp $BUNDLE_OUTPUT_DIR*_6*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_6*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 8"
scp $BUNDLE_OUTPUT_DIR*_7*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_7*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 9"

scp $BUNDLE_OUTPUT_DIR*_8*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_8*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "wait for $feeder_delay"
sleep $feeder_delay
echo "`date` [INFO]  |moving batch 10"

scp $BUNDLE_OUTPUT_DIR*_9*csv $CORE_USER@$CORE_SERVER:$CORE_BAL_INPUT
scp $BUNDLE_OUTPUT_DIR*_9*csv $CORE_USER@$CORE_SERVER:$CORE_COPY_TEMP

echo "Moved!"

#Removing Files From Directories Before Next Run
rm -f $MYST_INPUT_PATH/mystique*
rm -f $MYST_INPUT_PATH/msisdn*
rm -f $COMPARE_INPUT_DIR/BAL*
rm -f $COMPARE_OUTPUT


