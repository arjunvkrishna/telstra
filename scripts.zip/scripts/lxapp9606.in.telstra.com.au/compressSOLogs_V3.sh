#Parent Path to be Defined Here
archiveFolderPaths="/opt/knowesis/sift/orchestrator/so-batch-telstra/log/archive/ /opt/knowesis/sift/orchestrator/so-telstra/log/archive/"
#Log will be written in this file
LogPath=/home/siftuser/PSNM_Scripts/Archival_Logs
exec >>  $LogPath/archive_`date +%F`.log

for dir in $archiveFolderPaths;
do
echo "==================================================================="
#Function to Archive the SO Logs
echo "Log Compress Process Has Started For $dir at `date "+%Y%m%d%H%M%S"`"
date_Folder=`date --date="2 days ago" +"%F"`
cd $dir
mkdir -p $date_Folder
mv *.log-$date_Folder* $date_Folder"/"
echo "Compressing Logs of $date_Folder"
folderPath=$dir$date_Folder
	if [ -d "$folderPath" ]
	then
		archive_Dir_Name=$folderPath".tar.gz"
		actual_Dir_Name=$folderPath
		export GZIP=-9
		tar cfz $archive_Dir_Name -P $actual_Dir_Name
		rm -rf $actual_Dir_Name
	fi
echo "Logs Compress Process Completed For $dir at `date "+%Y%m%d%H%M%S"`"
echo "==================================================================="
done
