#!/bin/bash

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#title           :stitchingFeeder.sh
#description     :This script pulls balance snapshot files using scp from core and feed it in stitcher
#author          :SIFT Team
#version         :1.0.0
#usage           :sh stitchingFeeder.sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

LOG_PATH=/opt/knowesis/sift/orchestrator/sift-stitcher/log
exec 1>> $LOG_PATH/stitchingFeeder`date "+%Y%m"`.log
exec 2>> $LOG_PATH/stitchingFeeder`date "+%Y%m"`.err

FILE_DATE=$(date -d'1 days ago' "+%Y%m%d")
CORE_USER=siftuser
CORE_HOST=lxapp9604.in.telstra.com.au
CORE_LANDING_ZONE=/data/ingest/BUNDLE_SNAPSHOT
CORE_BALANCE_FILE=$CORE_LANDING_ZONE/*_cmpbalraw_${FILE_DATE}*dat*

STITCHER_HOME=/opt/knowesis/sift/orchestrator/sift-stitcher/

SO_LANDING_ZONE=$STITCHER_HOME/data/
STITCHING_INPUT_DIR=$STITCHER_HOME/data/input
STITCHING_OUTPUT_DIR=$STITCHER_HOME/data/output

rm $STITCHING_OUTPUT_DIR/BAL_BUNDLE_`date -d'1 days ago' "+%Y%m%d"`*.csv

pull_status=1
max_attempt=5
attempt=1
retry_delay=10m
file_found_flag=1

while [ $attempt -le $max_attempt ]
do
    if [ $pull_status -ne 0 ];then
        scp $CORE_USER@$CORE_HOST:$CORE_BALANCE_FILE $SO_LANDING_ZONE
        if [ $? -eq 0 ];then
            echo "`date` [INFO]  | Balance snapshot for $FILE_DATE successfully copied to SO from core"
	    file_found_flag=0
            break;
        else
            echo "`date` [ERROR] | Attempt # $attempt failed. Will try again"
        fi
    fi

    attempt=`expr $attempt + 1`

    #wait before next retry
    sleep $retry_delay
done

#if the file is not found then exit
if [ $file_found_flag -ne 0 ];then
	echo "`date` [ERROR] | No file found. Max attempts exhausted. Will exit now"
	exit 1
fi

echo "`date` [INFO]  | Inflating the file using gunzip"
gunzip $SO_LANDING_ZONE/*_cmpbalraw_${FILE_DATE}*dat*
if [ $? -ne 0 ];then
	echo "`date` [INFO]  | Inflate operation failed,  trying again"
	gunzip $SO_LANDING_ZONE/*_cmpbalraw_${FILE_DATE}*dat*
else
	echo "`date` [INFO]  | Moving balance snapshot file for stitching"
	mv $SO_LANDING_ZONE/*_cmpbalraw_${FILE_DATE}*dat $STITCHING_INPUT_DIR
	echo "`date` [INFO]  | File moved for processing"
fi
