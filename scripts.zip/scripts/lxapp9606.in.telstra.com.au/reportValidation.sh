#!/bin/bash
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# title:	reportValidation.sh
# description:	This script is to validate the OfferList from EventHistoryFile
# author:	SIFT Team
# version:	1.0.0
# usage:	bash reportValidation.sh offerIdList.csv
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

##Configuration params
OFFERID_LIST=$1
DATE_OF_EVENTHISTORY_FILE=$(date --date="$2 days ago" +"%Y%m%d")
EVEN_HISTORY_FILENAME=/opt/knowesis/opolo/orchestrator/opolo_meta_data-processed/Opolo_EventHistory_$DATE_OF_EVENTHISTORY_FILE*.csv
#EVEN_HISTORY_FILENAME=/opt/knowesis/opolo/orchestrator/opolo_meta_data/Opolo_EventHistory_$DATE_OF_EVENTHISTORY_FILE*.csv
OUTPUT_FILE_NAME=/opt/knowesis/opolo/orchestrator/reportValidationTesting/ContactHistorySummary_$DATE_OF_EVENTHISTORY_FILE.csv

#processor for listing all the grouped OfferId
while read offer
do
	for action in CORENOTIFICATION COREFULFILMENT OFFERNOTIFY FULFILL FULFILLNOTIFY FULFILL-PR RA_OFFER_SUCCESS
	do
		for control_group in true false
		do
			echo -n "$offer,$action,$control_group,$DATE_OF_EVENTHISTORY_FILE," >> $OUTPUT_FILE_NAME
			grep $offer $EVEN_HISTORY_FILENAME | grep -w $action | grep -Ec "[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\|$control_group" >> $OUTPUT_FILE_NAME 
		done
	done
done < $OFFERID_LIST
