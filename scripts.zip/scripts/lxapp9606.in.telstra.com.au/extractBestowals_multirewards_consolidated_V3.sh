#####################################################################
#####################################################################
# Script name: extractBestowals_multirewards_consolidated.sh
# Description: This script gets the MSISDNs details for bestowal events
#              as listed in the input file from all the logs for the 
#              mentioned date and generates one csv file per event. 
#              It also generates a csv file containing all the end to end counts"
# Version History:
# 1.0 | 09-May-2016 | Infosys | Original Version
# 2.0 | 22-Jul-2016 | Infosys | Consolidated Version
# 3.0 | 31-May-2018 | Infosys | Version For SIFT V3
#####################################################################
#####################################################################

#!/bin/sh

#Variables
logFilePath="/opt/knowesis/sift/orchestrator/so-telstra/log/archive"
export LC_ALL=C

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
# Input Args : None
#####################################################################
function usage ()
{
    echo -e "\nusage: sh extractBestowals_multirewards_consolidated.sh [<DD-Mmm-YYYY>]"
    echo "where:"
    echo -e "\tDate is optional. If no date is given, it runs for current date. Format is DD-Mmm-YYYY (`date +%d-%b-%Y`)"
    echo ""
    echo -e "\tThis script gets the MSISDNs details for bestowal events as listed"
    echo -e "\tin the input file from all the logs for the mentioned date and generates one csv file per event." 
    echo -e "\tIt also generates a consolidated file by merging all individual csv files"
    echo -e "\tAnd it also generates a csv file containing all the end to end counts"
    exit
}

#####################################################################
# Function   : set_ValidateParams
# Description: This function will set and validate required params
#              -> set the date if passed on
#              -> creates output directories, if not present
#              -> set the log files, input files names and path
#              -> checks if the input file exists or not
# Input Args : Run date passed on as DD-mmm-YYYY
#####################################################################
function set_ValidateParams()
{
    if [ $# -eq 1 ]; then
        runDate=$(date -d "$1" +"%d-%b-%Y")
        if [[ -z "$runDate" ]];   then
             echo "Please supply the date in DD-Mmm-YYYY Format i.e.,"$(date +"%d-%b-%Y") 
             exit 1
        fi
        echo "Date Supplied is "$runDate | tee -a $bestowalLogFile
    else
        runDate=$(date +"%d-%b-%Y")
        echo "No Date Supplied, so running the reconciliation for today i.e., "$runDate | tee -a $bestowalLogFile
    fi

    #Log file names
    fileDate=`date -d "$runDate" +%F`
    InteractLogFile="so-interacthandler.log-$fileDate*"
    ApolloLogFile="so-ocsfulfilmenthandler.log-$fileDate*"
    MainsLogFile="so-mainshandler.log-$fileDate*"
    ResponsysLogFile="so-responsyshandler.log-$fileDate*"

	SO1_hostname="lxapp9606"
	SO2_hostname="lxapp9607"
	if [ `uname -n` = "$SO1_hostname" ]; then
	FileNameSuffix="S01"
	fi
	if [ `uname -n` = "$SO2_hostname" ]; then
	FileNameSuffix="S02"
	fi
	
    InputFile="/home/siftuser/PSNM_Scripts/EventIds_List_Bestowals_consolidated.txt"
    #InputFile="/home/siftuser/PSNM_Scripts/EventIds_List_Bestowals_consolidated_test.txt"
    OutputBestowalsPath="/home/siftuser/PSNM_Scripts/Output_Bestowals/"$fileDate"_new/"
    OutputALLBestowalsCountsFile="$OutputBestowalsPath/AllCounts_Bestowals_${FileNameSuffix}_$runDate.csv"
    ConsolidatedBestowalFile="$OutputBestowalsPath/Consolidated_Bestowals_${FileNameSuffix}_$runDate.csv"
    bestowalLogFile="$OutputBestowalsPath/bestowalLogFile_$runDate.csv"

    echo "====================================================================" >> $bestowalLogFile
    echo "    BESTOWAL RECONCILIATION PROCESS STARTED at `date +"%F %T"`    "   | tee -a $bestowalLogFile
    echo "====================================================================" >> $bestowalLogFile

    # If condition to check for the Event Ids File Existance
    if [ ! -f "$InputFile" ]; then
        echo "Event File Not Found, Please create a Event File "$InputFile" and add the event names for which you want to verify the Bestowals" | tee -a $bestowalLogFile
        echo "==============================================================================" | tee -a $bestowalLogFile
        echo "           BESTOWAL RECONCILIATION PROCESS FAILED at `date +"%F %T"`          " | tee -a $bestowalLogFile
        echo "==============================================================================" | tee -a $bestowalLogFile
        exit 1
    fi

    if [ ! -d $OutputBestowalsPath ]; then
        mkdir -p $OutputBestowalsPath
    fi

    # If loop is to check for the same output file exists,if exists it will remove
    if [ -f $OutputALLBestowalsCountsFile ]; then
        rm $OutputALLBestowalsCountsFile
    fi

    # Write Header
    echo "Event ID","Interact Request Counts","Interact Response Counts","Interact ContactGroup","Interact ControlGroup","Interact NoOffer","OCS Provisioning Success Counts","OCS Provisioning Failure Counts","Mains/Responsys Counts" >> $OutputALLBestowalsCountsFile

    # If loop is to check for the same consolidate output file exists,if exists it will remove
    if [ -f $ConsolidatedBestowalFile ]; then
        rm $ConsolidatedBestowalFile
    fi

    # Write Header
    echo "Event ID, Interact Requests, Interact Response-TopupProfile, Interact Response-Offertype, Interact Response-MSISDN, OCS Provisioning Request-MSISDN, OCS Provisioning Response-MSISDN, OCS Provisioning Response-Status,  Mains/Responsys-MSISDN,  Mains/Responsys-Msg" >> $ConsolidatedBestowalFile
}

#####################################################################
# Function   : deleteTempFiles
# Description: This function deletes the temp files
# Input Args : None
#####################################################################
function deleteTempFiles ()
{
    rm -f $tempInteractRequest
    rm -f $tempInteractResponse
    rm -f $tempApolloResponse
    rm -f $tempApollo1
    rm -f $tempApollo2
    rm -f $tempApolloStatus
    rm -f $tempMainsResponse
    rm -f $tempResponsysResponse
    rm -f $tempConsolidateFile
}

#####################################################################
# Function   : extract_bestowals
# Description: This function does the following
#              -> extracts the MSISDNs and other details for each of the
#                 event ID from Interact, Apollo, MAINS and Responsys logs 
#                 files and writes it to corresponding temp files
#              -> Concatenates these temp files to create one .csv file per
#                 event ID which has all the details and summary counts on top
#              -> Creates overall detailed counts file for all event IDs
# Input Args : runDate and Event ID
#####################################################################
function extract_bestowals()
{
    OutputBestowalsFile="$OutputBestowalsPath/Bestowals_"$i"_"$runDate".csv"
    tempInteractRequest="$OutputBestowalsPath/"$runDate"_tempInteractRequest.csv"
    tempInteractResponse="$OutputBestowalsPath/"$runDate"_tempInteractResponse.csv"
    tempApolloResponse="$OutputBestowalsPath/"$runDate"_tempApolloResponse.csv"
    tempApollo1="$OutputBestowalsPath/"$runDate"_tempApollo1.csv"
    tempApollo2="$OutputBestowalsPath/"$runDate"_tempApollo2.csv"
    tempApolloStatus="$OutputBestowalsPath/"$runDate"_tempApolloStatus.csv"
    tempMainsResponse="$OutputBestowalsPath/"$runDate"_tempMainsResponse.csv"
    tempResponsysResponse="$OutputBestowalsPath/"$runDate"_tempResponsysResponse.csv"
    tempConsolidateFile="$OutputBestowalsPath/"$runDate"_tempConsolidateFile.csv"

    # If loop is to check for the same output file exists,if exists it will remove and creates a new one
    if [ -f $OutputBestowalsFile ] ;then
        rm $OutputBestowalsFile
    fi
    
    #delete all temp files
    deleteTempFiles

    cd $logFilePath
    logDate=`date -d "$runDate" "+%m/%d/%y"`
	logDatePattern="\[$logDate"
	
#     Search patterns to find out the details and dump the output in temp files
    searchString="\"MULTI_EVENT_ID\":\"$i\""
    grep -r "$logDatePattern" $InteractLogFile| grep ','$searchString',' | grep 'Incoming Msg' | awk -F"ServiceId" '{print $2}' | sed 's/"://g' | sed 's/}//g' > $tempInteractRequest
    InteractRequestCounts=`wc -l $tempInteractRequest | awk '{print $1}'`
    
    searchString="\"EventId\":\"$i\""
    grep -r "$logDatePattern" $InteractLogFile | grep -i ','$searchString','  | grep 'Incoming PostEvent Msg' | awk -F"EventGroup" '{print $2}' | awk -F"," '{print $2,",",$3,",",$4}' | sed 's/"ServiceId"://g' > $tempInteractResponse

    searchString="EventId=$i"     
    grep -r "$logDatePattern" $InteractLogFile | grep 'EventId=' | grep -w $i | grep 'InteractResponseRo' | grep 'No Offer'|  awk -F"ServiceId=" '{print $2}' | sort -u  | awk -F"," '{print ",",$4,",",$1}' >> $tempInteractResponse
    InteractResponseCounts=`wc -l $tempInteractResponse | awk '{print $1}'`
    InteractContactGroupCounts=`grep "Contact" $tempInteractResponse | wc -l  | awk '{print $1}'`
    InteractControlGroupCounts=`grep "Control" $tempInteractResponse | wc -l  | awk '{print $1}'`
    InteractNoOfferCounts=`grep -v "Control" $tempInteractResponse | grep -v "Contact" | wc -l  | awk '{print $1}'`

    searchString="\"EventId\":\"$i\""
    grep -r "$logDatePattern" $ApolloLogFile | grep -i ','$searchString','  | grep 'Incoming Msg' | awk -F"ServiceId" '{print $2}' | cut -d"," -f1 | sed 's/"://g'> $tempApolloResponse

    searchString="EventId:$i"
    #Get error message
    grep -r "$logDatePattern" $ApolloLogFile  | grep "ProvisionFinalResp" | grep -i ','$searchString',' | awk -F"ServiceId" '{print $2}' |  grep "One of the Multiple Rewards" | awk -F"," '{print $1,"-",$5}'| awk -F"-" '{print $1,",",$4,$5}' | sed 's/\://g' | sed 's/TopUpProfileId/-/g' | sed 's/with/-/g'> $tempApolloStatus
    #grep -r "$runDate" $ApolloLogFile  | grep "ApolloResponseProcessor" | grep 'INFO' | grep -i ','$searchString',' |  awk -F"," '{print $NF}' > $tempApollo2
    #paste $tempApollo1 $tempApollo2 > $tempApolloStatus
    ApolloSuccessCounts=`grep -c "SUCCESS for" $tempApolloStatus`
    ApolloFailureCounts=`grep -c "FAILED for" $tempApolloStatus`

 
    if [ $ServiceType = "HH" ]; then
        searchString="\"EventId\":\"$i\""   
       grep -r "$logDatePattern" $MainsLogFile | grep -i ','$searchString','  | grep 'Incoming Msg' | awk -F"ServiceId" '{print $2}' | cut -d"," -f1,3 | sed 's/"://g'  > $tempMainsResponse
        MainsResponseCounts=`wc -l $tempMainsResponse  | awk '{print $1}'`

    elif [ $ServiceType = "MBB" ]; then
        searchString="EventId:"$i""
        grep -r "$logDatePattern" $ResponsysLogFile  | grep ','$searchString','  | grep 'Responsys Mail Request Added in the Bath' | awk -F"," '{print $2}'  | cut -d":" -f2  > $tempResponsysResponse
        ResponsysResponseCounts=`wc -l $tempResponsysResponse | awk '{print $1}'`
    fi
    
    # Print the Summary counts on top
    echo "Interact Request Counts :,$InteractRequestCounts" >> $OutputBestowalsFile
    echo "Interact Response Counts:,$InteractResponseCounts" >> $OutputBestowalsFile
    echo "Interact No Offers Counts:,$InteractNoOfferCounts" >> $OutputBestowalsFile
    echo "Interact Control group Counts:,$InteractControlGroupCounts" >> $OutputBestowalsFile
    echo "OCS Provisioning Success Counts  :,$ApolloSuccessCounts" >> $OutputBestowalsFile
    echo "OCS Provisioning Failed Counts  :,$ApolloFailureCounts" >> $OutputBestowalsFile

    
    if [ $ServiceType = "HH" ]; then
        echo "Mains Response Counts   :,$MainsResponseCounts" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
 
        echo "Interact Requests, Interact Response-TopupProfile, Interact Response-Offertype, Interact Response-MSISDN, OCS Provisioning Request-MSISDN, OCS Provisioning Response-MSISDN, OCS Provisioning Response-Status,  Mains-MSISDN,  Mains-SMS text" >> $OutputBestowalsFile

        # Concatenate all the temp files sepeared by comma
        paste -d "," $tempInteractRequest $tempInteractResponse $tempApolloResponse $tempApolloStatus $tempMainsResponse >> $OutputBestowalsFile

        echo "$i","$InteractRequestCounts","$InteractResponseCounts","$InteractContactGroupCounts","$InteractControlGroupCounts","$InteractNoOfferCounts","$ApolloSuccessCounts", "$ApolloFailureCounts","$MainsResponseCounts" >> $OutputALLBestowalsCountsFile

    elif [ $ServiceType = "MBB" ]; then
        echo "Responsys Response Counts   :,$ResponsysResponseCounts" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
        
        echo "Interact Requests, Interact Response-TopupProfile, Interact Response-Offertype, Interact Response-MSISDN, OCS Provisioning Request-MSISDN, OCS Provisioning Response-MSISDN, OCS Provisioning Response-Status, Responsys Response" >> $OutputBestowalsFile

        # Concatenate all the temp files sepeared by comma
        paste -d "," $tempInteractRequest $tempInteractResponse $tempApolloResponse $tempApolloStatus $tempResponsysResponse >> $OutputBestowalsFile

        echo "$i","$InteractRequestCounts","$InteractResponseCounts","$InteractContactGroupCounts","$InteractControlGroupCounts","$InteractNoOfferCounts","$ApolloSuccessCounts", "$ApolloFailureCounts", "$ResponsysResponseCounts" >> $OutputALLBestowalsCountsFile
    fi

    cat $OutputBestowalsFile | sed -e '1,/Interact Response-TopupProfile/ d'  > $tempConsolidateFile
    sed "s/^/$i,/" $tempConsolidateFile >> $ConsolidatedBestowalFile

    #Forcefully delete all temp files
    deleteTempFiles
}

#####################################################################
# Function   : sendFilesSFTP
# Description: This function does the following
#              -> transfers the below two files to lxfile 0023
#                   Consolidate file
#                   All Counts files
# Input Args : None
#####################################################################
function sendFilesSFTP ()
{
    AthenianFileServer="lxfile0023.in.telstra.com.au"
    AthenianUserId="n100417"
    AthenianPath="/Athenian/Sift/reporting/bestowals"
    scp -p $ConsolidatedBestowalFile $OutputALLBestowalsCountsFile $AthenianUserId@$AthenianFileServer:$AthenianPath
    scp_status=`echo $?`
    if [ $scp_status -ne 0 ]
    then
        echo "Failed to TRANSFER the files `basename $ConsolidatedBestowalFile` and `basename $OutputALLBestowalsCountsFile` to Athenian file Server" >> $bestowalLogFile
        echo "==============================================================================" | tee -a $bestowalLogFile
        echo "           BESTOWAL RECONCILIATION PROCESS FAILED at `date +"%F %T"`          " | tee -a $bestowalLogFile
        echo "==============================================================================" | tee -a $bestowalLogFile
        exit 1
    fi
 
    echo "Sucessfully transferred the files `basename $ConsolidatedBestowalFile` and `basename $OutputALLBestowalsCountsFile` to Athenian file server" >> $bestowalLogFile
    echo "==============================================================================" | tee -a $bestowalLogFile
    echo "   BESTOWAL RECONCILIATION PROCESS COMPLETED SUCESSFULLY at `date +"%F %T"`   " | tee -a $bestowalLogFile
    echo "==============================================================================" | tee -a $bestowalLogFile
    exit 0
}
#####################################################################
# Function   : main
# Description: 
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" -o $# -lt 1 -o $# -gt 2 ]
then
    usage
    exit 0
fi

# Set paramaters - file locations and paths and validate the input arguments
set_ValidateParams $1

# For loop to run recursively for all the events in the input file 
for line in `cat $InputFile`
do
    # Set the service type and Event ID  as per the event
    i=`echo $line | awk -F"," '{print $1}'`
    ServiceType=`echo $line | awk -F"," '{print $2}'`

    echo "`date +"%F %T"` : Now processing $i for $ServiceType" >> $bestowalLogFile
    extract_bestowals $runDate $i
done

# Transfer the Consolidate file and allcounts file to Athenian file server
sendFilesSFTP

