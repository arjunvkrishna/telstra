#Parent Path to be Defined Here
auditFolderPaths="/opt/knowesis/sift/orchestrator/so-telstra/log/audit/ /opt/knowesis/sift/orchestrator/so-batch-telstra/log/audit/"
#Log will be written in this file
LogPath=/home/siftuser/PSNM_Scripts/Archival_Logs
exec >>  $LogPath/archive_audit_`date +%F`.log

echo "==================================================================="
echo "Audit Logs Compress Process Has Started at `date "+%Y%m%d%H%M%S"`"

for dir in $auditFolderPaths;
do
auditFolderName=`date -d '1 hour ago' +"%Y%m%d-%H"`
if [ -d $dir$auditFolderName ]
then
	echo "Compressing "$dir$auditFolderName
	export GZIP=-9
	tar cfz $dir$auditFolderName".tar.gz" -P $dir$auditFolderName
	rm -rf $dir$auditFolderName
fi
done

echo "Audit Logs Compress Process Completed at `date "+%Y%m%d%H%M%S"`"
echo "==================================================================="
