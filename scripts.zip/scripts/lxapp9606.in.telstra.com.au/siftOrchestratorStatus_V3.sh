#####################################################################
#####################################################################
# Script name: siftOrchestratorStatus.sh
# Description: This script gets the overall status of Sift Orchestrator
#              -> ActiveMQ
#              -> Redis Server
#              -> Prority Handlers
#              -> Normal Handlers
#			   -> Opt In Hanlders	
#			   -> Web Console Handler
#			   -> MO Handler
#              -> Record Keeper Handler
#              -> Batch Unica Handler
#Version History:
#Ver|Date       |Author |Description
#1.0|11-Mar-2016|Infosys|Version 1 For V1 Handler Configurations
#2.0|07-Jun-2016|Infosys|Updated For SIFT V3 Handler Configurations
#####################################################################
#####################################################################

# Variables
PriorityHandlersPath="/opt/knowesis/sift/orchestrator/so-telstra/bin"
NormalHandlersPath="/opt/knowesis/sift/orchestrator/so-batch-telstra/bin"
#apolloReplicatorPath="/opt/knowesis/sift/orchestrator/sift-apollo-replicator/bin"
#monitorReplicatorPath="/opt/knowesis/sift/orchestrator/sift-monitor-replicator/bin"
optinHandlerPath="/opt/knowesis/sift/orchestrator/optinHandler/bin"
MohandlerPath="/opt/knowesis/sift/orchestrator/optinHandler/bin"
RecordkeeperPath="/opt/knowesis/sift/orchestrator/recordkeeper/bin"
RedisHandlerPath="/opt/knowesis/sift/orchestrator/bin"
WebConsoleHandlerPath="/opt/knowesis/sift/orchestrator/bin"
BatchUnicaHandlerPath="/opt/knowesis/sift/orchestrator/batchHandlers/bin"

SO1_hostname="lxapp9606"
SO2_hostname="lxapp9607"
batchwindowStart="9"
batchwindowEnd="18"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo "usage: sh siftOrchestratorStatus.sh"
    echo "This script checks the overall status of Sift Orchestrator"
}

#####################################################################
# Function   : SendEmailAlert
# Description: Send Email and SMS Alerts out.
#####################################################################
function sendEmailAlert ()
{
    emailSubject="SIFT EMAIL ALERT "\!\!\!" $MSG- `date +%F`"
toAddressArray=('Shabeena_M@infosys.com' 'Saikrishna_Doli@infosys.com' 'Manoj_Kumar51@infosys.com' 'bhuvan.siddaramu@infosys.com')
tail -7 ${LOG_FILE} | head -6 | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0408574590@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0466961887@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919496152994@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919663679814@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0431812571@sms.in.telstra.com.au"
}

#####################################################################
# Function   : activemqStatus
# Description: This functions checks if Active MQ is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function activemqStatus ()
{
    # sift orchestrator activemq status
    status=$(netstat -na | grep :8161  | awk 'NR==1{printf "%s\n", $6}');
    if [ "$status" = "LISTEN" ];then
        echo "Active MQ Status : Running" | tee -a $SOStatusFile
    else
		  echo "Active MQ Status : Not Running" | tee -a $SOStatusFile
          MSG="$ServerName Active MQ is Not Running"
          content="$ServerName ActiveMQ is Not Running. Please Check!"
          sendEmailAlert    
fi
}

#####################################################################
# Function   : redisMasterStatus
# Description: This functions checks if Redis Server Master in SO1 is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function redisMasterStatus ()
{
    status=$(netstat -na | grep ':6379 '  | awk 'NR==1{printf "%s\n", $6}');
    if [ "$status" = "LISTEN" ];then
        echo "Redis Server Master Status : Running"  | tee -a $SOStatusFile
    else
        echo "Redis Server Master Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Redis Server Master is Not Running"
          content="$ServerName Redis Master Server is Not Running. Please Check!"
          sendEmailAlert 
    fi
}

#####################################################################
# Function   : redisSlaveStatus
# Description: This functions checks if Redis Server Slave in SO2 is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function redisSlaveStatus ()
{
    status=$(netstat -na | grep ':6380 '  | awk 'NR==1{printf "%s\n", $6}');
    if [ "$status" = "LISTEN" ];then
        echo "Redis Server Slave Status : Running"  | tee -a $SOStatusFile
    else
        echo "Redis Server Slave Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Redis Slave Server is Not Running"
          content="$ServerName Redis Slave Server is Not Running. Please Check!"
          sendEmailAlert 
    fi
}

#####################################################################
# Function   : webConsoleStatus
# Description: This functions checks if Web Console Handler is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function webConsoleStatus ()
{
    cd $WebConsoleHandlerPath
	webhandler_row=$(sh checkWebHandler.sh | wc -l);
    if [ "$webhandler_row" = 2 ]; then
        echo "Web Console Handler Status : Running" | tee -a $SOStatusFile
    else
        echo "Web Console Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Web Console Handler is Not Running"
          content="$ServerName Web Console Handler is Not Running. Please Check!"
          sendEmailAlert  
    fi
}

#####################################################################
# Function   : priorityHandlersStatus
# Description: This functions checks if all the Priority handlers are 
#              running or not and displays the status accordingly on 
#              the console and also writes it to log file 
#              It checks the below handlers
#              -> Core Handler
#              -> Interact Handler
#              -> Mains Handler 
#              -> Responsys Handler 
#              -> OCS Fulfillment Handler 
#              -> Audit Handler 
#####################################################################
function priorityHandlersStatus ()
{

#Execute From Priority Handlers Bin Directory
#    cd $PriorityHandlersPath

    # Core handler status
    corehandler_row=$(ps -ef | grep "so-corehandler-0.0.1.jar" | wc -l);
	if [ "$corehandler_row" = 2 ]; then
        echo "Priority Core Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Priority Core Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Priority Core Handler is Not Running"
          content="$ServerName Priority Core Handler is Not Running. Please Check!"
          sendEmailAlert   
    fi

		
    #Interact handler status
    interacthandler_row=$(ps -ef | grep "so-interacthandler-0.0.1.jar" | wc -l);
	if [ "$interacthandler_row" = 2 ]; then
        echo "Priority Interact Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Priority Interact Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Priority Interact Handler is Not Running"
          content="$ServerName Priority Interact Handler is Not Running. Please Check!"
          sendEmailAlert   
    fi
	
	
    #Mains handler status
    mainshandler_row=$(ps -ef | grep "so-mainshandler-0.0.1.jar" | wc -l);
	if [ "$mainshandler_row" = 2 ]; then
        echo "Priority Mains Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Priority Mains Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Priority Mains Handler is Not Running"
          content="$ServerName Priority Mains Handler is Not Running. Please Check!"
          sendEmailAlert   
    fi

    #Responsys handler status
    responsyshandler_row=$(ps -ef | grep "so-responsyshandler-0.0.1.jar" | wc -l);
	if [ "$responsyshandler_row" = 2 ]; then
        echo "Priority Responsys Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Priority Responsys Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Priority Responsys Handler is Not Running"
          content="$ServerName Priority Responsys Handler is Not Running. Please Check!"
          sendEmailAlert   
    fi


    #OCS Fulfillment Handler status
    ocsfulfillmenthandler_row=$(ps -ef | grep "so-ocsfulfilmenthandler-0.0.1.jar" | wc -l);
	if [ "$ocsfulfillmenthandler_row" = 2 ]; then
        echo "Priority OCS Fulfillment Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Priority OCS Fulfillment Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Priority OCS Fulfillment Handler is Not Running"
          content="$ServerName Priority OCS Fulfillment Handler is Not Running. Please Check!"
          sendEmailAlert   
    fi
  
    #Audit Handler status
    audithandler_row=$(ps -ef | grep "so-audithandler-0.0.1.jar" | wc -l);
	if [ "$audithandler_row" = 2 ]; then
        echo "Priority Audit Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Priority Audit Handler Status : Not Running" | tee -a $SOStatusFile  
    fi

}

#####################################################################
# Function   : normalHandlerStatus
# Description: This functions checks if all the Normal handlers are 
#              running or not and displays the status accordingly on 
#              the console and also writes it to log file 
#              It checks the below handlers
#              -> Core Handler
#              -> Interact Handler
#              -> Mains Handler 
#              -> Responsys Handler 
#              -> OCS Fulfillment Handler 
#              -> Audit Handler 
#####################################################################
function normalHandlerStatus ()
{

#Execute From Normal Handlers Bin Directory
    cd $NormalHandlersPath

    # Core handler status
    corehandler_row=$(sh so-corehandler.sh status);
	echo $corehandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Normal Core handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Normal Core handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Normal Core Handler is Not Running"
          content="$ServerName Normal Core Handler is Not Running. Please Check!"
          sendEmailAlert 
    fi

		
    #Interact handler status
    interacthandler_row=$(sh so-interacthandler.sh status);
	echo $interacthandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Normal Interact Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Normal Interact Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Normal Interact Handler is Not Running"
          content="$ServerName Normal Interact Handler is Not Running. Please Check!"
          sendEmailAlert 
    fi

	
    #Mains handler status
    mainshandler_row=$(sh so-mainshandler.sh status);
	echo $mainshandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Normal Mains Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Normal Mains Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Normal Mains Handler is Not Running"
          content="$ServerName Normal Mains Handler is Not Running. Please Check!"
          sendEmailAlert 
    fi

    #Responsys handler status
    responsyshandler_row=$(sh so-responsyshandler.sh status);
	echo $responsyshandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Normal Responsys Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Normal Responsys Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Normal Responsys Handler is Not Running"
          content="$ServerName Normal Responsys Handler is Not Running. Please Check!"
          sendEmailAlert 
    fi


    #OCS Fulfillment Handler status
    ocsfulfillmenthandler_row=$(sh so-ocsfulfilmenthandler.sh status);
	echo $ocsfulfillmenthandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Normal OCS Fulfillment Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Normal OCS Fulfillment Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Normal OCS Fulfillment Handler is Not Running"
          content="$ServerName Normal OCS Fulfillment Handler is Not Running. Please Check!"
          sendEmailAlert 
    fi
  
    #Audit Handler status
    audithandler_row=$(sh so-audithandler.sh status);
	echo $audithandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Normal Audit Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Normal Audit Handler Status : Not Running" | tee -a $SOStatusFile
    fi

}

#####################################################################
# Function   : optinHandlerStatus
# Description: This functions checks if Opt In Handler is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function optinHandlerStatus ()
{
    cd $optinHandlerPath
	optinhandler_row=$(sh so-apioptinhandler.sh status);
	echo $optinhandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Opt In Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Opt In Handler Status : Not Running" | tee -a $SOStatusFile
    fi
}

#####################################################################
# Function   : moHandlerStatus
# Description: This functions checks if MO Handler is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function moHandlerStatus ()
{
    cd $MohandlerPath
	mohandler_row=$(sh so-apioptinhandler.sh status);
	echo $mohandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "MO Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "MO Handler Status : Not Running" | tee -a $SOStatusFile
    fi
}

#####################################################################
# Function   : recordKeeperHandlerStatus
# Description: This functions checks if Record Keeper Handler is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function recordKeeperHandlerStatus ()
{
	cd $RecordkeeperPath
    recordkeeperhandler_row=$(sh so-recordkeeper.sh status);
	echo $recordkeeperhandler_row | grep -i 'process found'
	STATUS=$?
    if [ $STATUS -eq 0 ];then
        echo "Record Keeper Handler Status : Running" | tee -a $SOStatusFile
    else
          echo "Record Keeper Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Record Keeper Handler is Not Running"
          content="$ServerName Record Keeper Handler is Not Running. Please Check!"
          sendEmailAlert 
    fi
}

#####################################################################
# Function   : batchUnicaHandlerStatus
# Description: This functions checks if Batch Unica Handler is running or not.
#			   This runs only on SO1 between 09:00 AM and 06:00 PM
#              It displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function batchUnicaHandlerStatus ()
{
    cd $BatchUnicaHandlerPath
	batchunicahandler_row=$(sh sobatch-Unica.sh status | wc -l);
    if [ "$batchunicahandler_row" = 2 ]; then
        echo "Batch Unica Handler Status : Running" | tee -a $SOStatusFile
    else
          currHour=`date "+%H"`
		  if [ $currHour -ge $batchwindowStart ] && [ $currHour -lt $batchwindowEnd ];
		  then
		  echo "Batch Unica Handler Status : Not Running" | tee -a $SOStatusFile
		  MSG="$ServerName Batch Unica Handler is Not Running"
          content="$ServerName Batch Unica Handler is Not Running. Please Check!"
          sendEmailAlert 
          fi
          echo "Batch Unica Handler Status : Handler Will Only Run Between 09:00 AM and 06:00 PM" | tee -a $SOStatusFile		  
    fi
}

#####################################################################
# Function   : main
# Description: 
#####################################################################

if [ `uname -n` = "$SO1_hostname" ]; then
    SOStatusFile="/home/siftuser/PSNM_Scripts/HealthCheck/SO1_Status.`date +%F`.log"
	ServerName="S01"
    echo "======================================================" | tee -a $SOStatusFile
    echo "`date '+%F %T'` | INFO | Server: `uname -n` | Sift Orchestrator status" | tee -a $SOStatusFile
    activemqStatus
    redisSlaveStatus
	webConsoleStatus
    priorityHandlersStatus
	normalHandlerStatus
	optinHandlerStatus
	moHandlerStatus
	recordKeeperHandlerStatus
	batchUnicaHandlerStatus
    echo "======================================================" | tee -a $SOStatusFile
fi

if [ `uname -n` = "$SO2_hostname" ]; then
    SOStatusFile="/home/siftuser/PSNM_Scripts/HealthCheck/SO2_Status.`date +%F`.log"
	ServerName="S02"
    echo "======================================================" | tee -a $SOStatusFile
    echo "`date '+%F %T'` | INFO | Server: `uname -n` | Sift Orchestrator status" | tee -a $SOStatusFile
    activemqStatus
    redisMasterStatus
	webConsoleStatus
    priorityHandlersStatus
	normalHandlerStatus
	optinHandlerStatus
	moHandlerStatus
	recordKeeperHandlerStatus
    echo "======================================================" | tee -a $SOStatusFile
fi
