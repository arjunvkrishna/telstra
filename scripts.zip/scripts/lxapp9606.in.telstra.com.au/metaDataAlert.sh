#!/bin/bash
#########################################
## metaData-Alert Script
#########################################

#running the script 
#sh metaDataAlert.sh 

#Script Dir. Configs.
SCRIPT_HOME=/opt/knowesis/sift/scripts/exec
LOG_DIR=/opt/knowesis/sift/scripts/log
DATE_LOG=$(date +"%Y%m")
LOG_FILE=$LOG_DIR/metaDataAlert_$DATE_LOG.log

#Config read parameters
SOURCE_PATH=/opt/knowesis/opolo/orchestrator/opolo_meta_data-processed
#Entities delimited with space
ENTITIES="OFFER PROGRAM TRIGGER"
FILENAME_PATTERNS="OFFER=Opolo_OfferConfiguration_$(date +"%Y%m%d")*.csv,PROGRAM=Opolo_ProgramConfiguration_$(date +"%Y%m%d")*.csv,TRIGGER=Opolo_TriggerConfiguration_$(date +"%Y%m%d")*.csv"
ENTITY_ENDDATE_POSITION="OFFER=15,PROGRAM=8,TRIGGER=8"
ALERT_WINDOW=30
DATE_OF_EXPIRY=$(date +"%Y-%m-%d" --date="+$ALERT_WINDOW days")

#Bash level Mail configs
MAIL_RECEPIENTS="john.hour@team.telstra.com,Telstra_Anthenian@infosys.com,shinu.antony01@infosys.com,rajani.jagga@infosys.com,sumit.srivastava02@infosys.com,Manoj_Kumar51@infosys.com,Rao.Sanagapalli@team.telstra.com"

#Logger Function
function logger {
    echo "$(date) | $1" >> $LOG_FILE
}

#Function to set AlertMessage for the nearlyExpiring entities
function getAlertMessage() {
	ENTITY=$1
	ENTITY_ID=$2
	DATE=$3
	echo "$ENTITY with id - $ENTITY_ID is expiring on $DATE" >> $SOURCE_PATH/metaDataAlertFile_$(date +"%Y%m%d").txt
}

#Function to send alertMail
function sendMail() {
	SUBJECT="[OPOLO] OFFER/PROGRAM/TRIGGER Due to expiry Notification - $(date +"%Y%m%d") [ALERT!!]"
	MAIL_SERVER="mail.in.telstra.com.au"
	
	#sending alertMail
	logger "WARN  | Sending Alert Mail with nearlyExpiring entities"
	mailx -s "$SUBJECT" -S smtp="$MAIL_SERVER" "$MAIL_RECEPIENTS" < $SOURCE_PATH/metaDataAlertFile_$(date +"%Y%m%d").txt
	return $?
}

logger "INFO  | ######### Starting MetaData entity Expiry check"

#looping over each set of files
for eachEntity in $ENTITIES;
do
	logger "INFO  | Checking for $eachEntity file"

	#Config read for the corresponding entity
	FILE_PATTERN=$(echo $FILENAME_PATTERNS | awk -F"$eachEntity=" '{print $2}' | awk -F"," '{print $1}')
	END_DATE_LOC=$(echo $ENTITY_ENDDATE_POSITION | awk -F"$eachEntity=" '{print $2}' | awk -F"," '{print $1}')

	#picking up each files from SorucePath
	for FILE in $(ls $SOURCE_PATH/$FILE_PATTERN); 
	do
		#read each file and check for expiring entities
		while IFS= read -r line; 
		do 	
			ENTITY_END_DATE_PART=`echo "$line" | awk -v loc=$END_DATE_LOC -F'|' '{print $loc}' | awk -F" " '{print $1}'`
			
			#Comparing the EndDate with Expected ExpiryDate
			if [ "$DATE_OF_EXPIRY" == "$ENTITY_END_DATE_PART" ];
				then
					entityID=`echo "$line" | awk -F'|' '{print $1}'`
					getAlertMessage $eachEntity $entityID $ENTITY_END_DATE_PART
			fi
		done < $FILE
		logger "INFO  | Expired Entries for $eaachEntity written to file with Status $?. Total expiring entities = $(wc -l $SOURCE_PATH/metaDataAlertFile_$(date +"%Y%m%d").txt)
	done
done	

# Sending mail alert based on file presence
if [ -f "$SOURCE_PATH/metaDataAlertFile_$(date +"%Y%m%d").txt" ];
then
	sendMail
	logger "INFO  | Alert Mail sent with status $?"
fi

logger "INFO  | ######### Completed processing"
