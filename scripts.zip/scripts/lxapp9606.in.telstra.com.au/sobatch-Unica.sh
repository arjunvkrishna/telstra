#! /bin/sh

HANDLER_NAME='Batch Unica Handler'
PID_FILE_NAME=.batch_unica.pid
LOG4J_PROPERTIES_FILENAME=log4j-unica.properties
FLOW_JAR_NAME=sift-batch-unica-handler-1.0.0-SNAPSHOT.jar
SYSOUT_LOG_NAME=batch_unica_sysout.log

source /opt/knowesis/sift/orchestrator/batchHandlers/bin/sobatch-common.sh
