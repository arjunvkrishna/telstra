#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts/Bundle_Stitching_Monitoring
LOG_FILE=$MONITORING_PATH/Bundle_Stitching_`date +%Y%m%d`.log
FILE_CHECK_FILE=$MONITORING_PATH/BUNDLESTITCHFileCheck_`date +%F`.txt
STITCH_INPUT_PATH=/opt/knowesis/sift/orchestrator/sift-stitcher/data/input
FILE_DATE=$(date -d'1 days ago' "+%Y%m%d")
STITCH_INPUT_FILE=$STITCH_INPUT_PATH/*_cmpbalraw_${FILE_DATE}*dat
echo "`date '+%F %T'` | INFO | Starting Monitoring Script For Bundle Stitching Of `date +%F`"  >> $LOG_FILE

function sendEmailAlert ()
{
    emailSubject="SIFT EMAIL ALERT "\!\!\!" Bundle Stitching Monitoring SO1 - `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'Saikrishna_Doli@infosys.com' 'Shiju_R@infosys.com' 'Manoj_Kumar51@infosys.com' 'bhuvan.siddaramu@infosys.com')
#     toAddressArray=('Nirmal_Thekkekkota@infosys.com')
        echo $MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
}

while [ 1 ]
do

if [ -e $FILE_CHECK_FILE ]
then
FILE_FOUND=`cat $FILE_CHECK_FILE`
else
cd $STITCH_INPUT_PATH
FILE_COUNT=`ls -1 $STITCH_INPUT_FILE | wc -l`
        if [ $FILE_COUNT -gt 0 ]
        then
        FILE_FOUND='Y'
        echo "Y" >> $FILE_CHECK_FILE
        else
        FILE_FOUND='N'
        echo "`date '+%F %T'` | INFO | Awaiting Files in Input Directory For Bundle Stitching Of `date +%F`"  >> $LOG_FILE
        fi
fi


if [ "$FILE_FOUND" = "Y" ]
then
cd $STITCH_INPUT_PATH
FILE_COUNT=`ls -1 $STITCH_INPUT_FILE | wc -l`
        if [ $FILE_COUNT -gt 0 ];
        then
        currHour=`date "+%H"`
        if [ $currHour -gt 3 ]
        then
        echo "`date '+%F %T'` | WARN | Bundle Stitching For `date +%F` is Extending Beyond 4 AM."  >> $LOG_FILE
        MSG="Bundle Stitching For `date +%F` is Extending Beyond 4 AM. Files Present in /opt/knowesis/sift/orchestrator/sift-stitcher/data/output Will Be Pushed to Core at 4 AM and Remaining Files Will Be Missed!"
        sendEmailAlert
        fi
        echo "`date '+%F %T'` | INFO | Bundle Stitching For `date +%F` is in Progress."  >> $LOG_FILE
        elif [ $FILE_COUNT -eq 0 ]; then
        echo "`date '+%F %T'` | INFO | Bundle Stitching For `date +%F` Completed."  >> $LOG_FILE
        MSG="Bundle Stitching For `date +%F` Completed."
        sendEmailAlert
        exit
        fi
fi

if [ "$FILE_FOUND" = "N" ]
then
currHour=`date "+%H"`
        if [ $currHour -gt 3 ];
        then
        echo "`date '+%F %T'` | ERR | Balance Snapshot Input Files With Date Stamp $FILE_DATE For `date +%F` Did Not Reach Input Directory Till 4 AM,Exiting Monitoring Script." >> $LOG_FILE

        MSG="Balance Snapshot Input Files For `date +%F` Did Not Reach Input Directory Till 4 AM, Exiting Monitoring Script."
        sendEmailAlert
        exit
        fi
fi

currHour=`date "+%H"`
        if [ $currHour -eq 23 ];
        then
        echo "`date '+%F %T'` | ERR | Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script."  >> $LOG_FILE
        MSG="Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script For The Day. Tomorrow's Instance Will Capture Processing of Tomorrow's File."
        sendEmailAlert
        exit
        fi

sleep 1m
done

