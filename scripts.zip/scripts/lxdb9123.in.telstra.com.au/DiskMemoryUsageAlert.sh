#!/bin/sh
SERVERNAME=$(hostname)
DU=`df -h | grep '/data' -m 1 | awk '{print$4}'`
DISKUSAGE=`echo ${DU} | sed  -e 's/%//g'`
MU=`free -g | grep 'Mem:' | awk '{print$3*100/$2}'`
MEMORYUSAGE=`echo $MU | xargs printf "%.*f\n" 0`
#DISKUSAGE=70
#MEMORYUSAGE=100

if [ $DISKUSAGE -gt 80 ]
then
emailSubject="SIFT EMAIL ALERT "\!\!\!" $SERVERNAME -DISK USAGE ALERT"
toAddressArray=('Shabeena_M@infosys.com' 'Nirmal_Thekkekkota@infosys.com' 'Sowmya.T02@infosys.com')
echo "More than $DISKUSAGE Disk Space Consumed in $SERVERNAME, Last Checked at `date +"%Y-%m-%d %H:%M:%S"`" | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
echo "$DISKUSAGE Consumed in $SERVERNAME" | mailx -s "SIFTCORE IS DOWN" "0470656627@sms.in.telstra.com.au"
echo "$DISKUSAGE Consumed in $SERVERNAME" | mailx -s "SIFTCORE IS DOWN" "0466961887@sms.in.telstra.com.au"
echo "$DISKUSAGE Consumed in $SERVERNAME" | mailx -s "SIFTCORE IS DOWN" "919003230905@sms.in.telstra.com.au"
fi

if [ $MEMORYUSAGE -gt 90 ]
then
emailSubject="SIFT EMAIL ALERT "\!\!\!" $SERVERNAME -MEMORY USAGE ALERT"
toAddressArray=('Shabeena_M@infosys.com' 'Nirmal_Thekkekkota@infosys.com' 'Sowmya.T02@infosys.com')
echo "More than $MEMORYUSAGE RAM Consumed in $SERVERNAME, Last Checked at `date +"%Y-%m-%d %H:%M:%S"`" | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
echo "$MEMORYUSAGE Consumed in $SERVERNAME" | mailx -s "SIFTCORE IS DOWN" "0470656627@sms.in.telstra.com.au"
echo "$MEMORYUSAGE Consumed in $SERVERNAME" | mailx -s "SIFTCORE IS DOWN" "0466961887@sms.in.telstra.com.au"
echo "$MEMORYUSAGE Consumed in $SERVERNAME" | mailx -s "SIFTCORE IS DOWN" "919003230905@sms.in.telstra.com.au"
fi
