#!/bin/sh
 
source /home/siftuser/.bashrc 
SCRIPTS_PATH=/opt/knowesis/sift/portal/sfmcAPI

result=`ps -efl |grep -i 'sfmc-api-0.0.1' | grep -v grep | wc -l`
if [ $result -ge 1 ]
then
        echo "script is running"
else
        echo "script is not running. Initializing SFMC API Script."
        sh ${SCRIPTS_PATH}/startAPI.sh
fi

