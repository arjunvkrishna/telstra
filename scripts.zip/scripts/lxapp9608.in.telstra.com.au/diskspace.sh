dt=$(date +"%Y%m%d%H%M")
to="ajith@knowesis.com,odcsupport@knowesis.com,Manoj_Kumar51@infosys.com,sumit.srivastava02@infosys.com,rajani.jagga@infosys.com,shinu.antony01@infosys.com,Telstra_Athenian@infosys.com"

threshold=80
df -H | grep -vE '^Filesystem|tmpfs|cdrom|/dev/mapper/VG00-lv_root|/dev/sda1' | awk '{print $4" "$5}'| while read output;
do
   usep=$(echo $output | awk '{ print $1}' | cut -d '%' -f1)
  partition=$(echo $output | awk '{ print $2 }')
 if [ "$usep" -ge "$threshold" ] ; then
 echo "STATE_NOT_OK"
  echo "Running out of space \"$partition ($usep%)\" on $(hostname) as on $(date)" | mailx -s "SiftOrchestrator 3 diskspace to be checked" -S smtp=mail.in.telstra.com.au "$to"
 fi
done
