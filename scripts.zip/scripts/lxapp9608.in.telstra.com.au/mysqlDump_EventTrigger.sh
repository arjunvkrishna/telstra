#!/bin/bash

#########################################
#Config for the DBExport
#########################################

ARCHIVE_FOLDER=/opt/knowesis/sift/orchestrator/archive/event_transaction
DATABASE_HOME=/opt/knowesis/sift/orchestrator/mysql/data
username=root
password=password
#The following Directory should 777 permissions
SourcePATH=$DATABASE_HOME
SOCKET=/opt/knowesis/sift/orchestrator/mysql/mysql_5.7.18/socket
DatabaseName=transactions

exec 1>>$DATABASE_HOME/log/DBExport_`date "+%Y%m%d"`.log
exec 2>>$DATABASE_HOME/log/DBExport_`date "+%Y%m%d"`.err

DestinationIP=n105938@Inbound.edw.in.telstra.com.au
DestinationPATH=/pr1/data/CSA/prd/ent/inbound/sift/src/land

#DestinationIP=n105937@lxapp0019.in.telstra.com.au
#DestinationPATH=/etl_prod/source/RTM/ev_trgr_rec

date_old_human=`date --date="1 days ago" "+%Y%m%d"`
date_old=`date --date="$date_old_human" "+%s000"`
date_human=`date "+%Y%m%d"`
date_current=`date --date="$date_human" "+%s000"`

echo "==========================EVENT_TRIGGER=================================="
Header="MSISDN~~OFFER_CODE~~EVENT_ID~~FLOW_ID~~PARENT_EVENT_ID~~EVENT_SOURCE~~TOPUP_PROFILE_ID~~PROVISIONED_VALUE~~PROVISIONING_SYSTEM~~EVENT_TIMESTAMP~~NOTIFICATION_MESSAGE~~ACTION_RESPONSE~~EVENT_TYPE~~ACTION_TYPE~~NOTIFICATION_CHANNEL~~ACTION_STATUS~~IS_CONTROL~~IS_MULTIEVENT~~IS_MONITORED~~TREATMENT_CODE~~IS_SIMULATED"
filename="Event_Transactions"
TableName="EVENT_TRIGGER"
ColumnCondition="EVENT_TIMESTAMP >= $date_old AND EVENT_TIMESTAMP < $date_current"
echo $ColumnCondition
echo $Header > $SourcePATH/${filename}_${date_human}.csv
echo "Generating Dump of the Table $TableName at $SourcePATH Started at `date "+%Y%m%d%H%M%S"`";

cd /opt/knowesis/sift/orchestrator/mysql/mysql_5.7.18/bin/

if [ "$ColumnCondition" != "" ];then
./mysqldump -u $username --socket=$SOCKET --password=$password --skip-set-charset --tab=$SourcePATH  --fields-terminated-by="~~" $DatabaseName $TableName  --where "$ColumnCondition";
else 
./mysqldump -u $username --socket=$SOCKET --password=$password  --skip-set-charset --tab=$SourcePATH --fields-terminated-by="~~" $DatabaseName $TableName;
fi
cat $SourcePATH/$TableName.txt >> $SourcePATH/${filename}_${date_human}.csv
wc -l $SourcePATH/${filename}_${date_human}.csv > $SourcePATH/${filename}_${date_human}.ctl
rm $SourcePATH/$TableName.txt
echo "Generating Dump of the Table $TableName at $Path Finished at `date "+%Y%m%d%H%M%S"`";

#scp commands need to add & need to send to the backup directory;

count=`wc -l $SourcePATH/${filename}_${date_human}.csv | awk '{print $1}'`
extractTime=`date "+%H%M%S"`
baseFilename=${filename}_${date_human}

echo "$count|$date_human|$extractTime|$baseFilename|1|SIFT|0" > $SourcePATH/${filename}_${date_human}.ctl

echo "Copying files to remote server $DestinationIP" starts  at `date "+%Y%m%d%H%M%S"`

cd $SourcePATH
touch ${filename}_${date_human}.eot
sftp $DestinationIP << END
put ${filename}_${date_human}.ctl
put ${filename}_${date_human}.csv
quit
END

#scp $SourcePATH/$filename.csv  $DestinationIP:$DestinationPATH
if [ $? -eq 0 ]; then
        sftp $DestinationIP << END
                put ${filename}_${date_human}.eot
                quit
END
	echo "Copying files to remote server $DestinationIP" finished at `date "+%Y%m%d%H%M%S"`
else
	echo "Files could not be copied over to $DestinationIP"
fi

tar --remove-files -cvzf $ARCHIVE_FOLDER/${filename}_${date_human}.tar $SourcePATH/${filename}_${date_human}* -C $SourcePATH

