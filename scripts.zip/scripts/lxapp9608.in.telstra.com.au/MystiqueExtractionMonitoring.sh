#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts/Mystque_Monitoring
LOG_FILE=$MONITORING_PATH/Mystique_Extraction_`date +%Y%m%d`.log
FILE_CHECK_FILE=$MONITORING_PATH/MYSTFileCheck_`date +%F`.txt
MYS_INPUT_PATH=/data/mystique/INPUT_FILES/input
#MYS_INPUT_PATH=/home/siftuser/PSNM_Scripts/Mystque_Monitoring
DATE_OLD=`date --date="1 days ago" "+%Y%m%d"`
MYS_INPUT_FILE=$MYS_INPUT_PATH/msisdn_${DATE_OLD}*csv
echo "`date '+%F %T'` | INFO | Starting Monitoring Script For Mystique Extraction Of `date +%F`"  >> $LOG_FILE

function sendEmailAlert ()
{
    emailSubject="SIFT EMAIL ALERT "\!\!\!" Mystique Extraction Monitoring - `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'Sowmya.T02@infosys.com' 'Nirmal_Thekkekkota@infosys.com' 'manoj_kumar51@infosys.com' 'Saikrishna_Doli@infosys.com' 'Shiju_R@infosys.com' 'bhuvan.siddaramu@infosys.com')
#     toAddressArray=('Nirmal_Thekkekkota@infosys.com')
        echo $MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
}

while [ 1 ]
do

if [ -e $FILE_CHECK_FILE ]
then
FILE_FOUND=`cat $FILE_CHECK_FILE`
else
cd $MYS_INPUT_PATH
FILE_COUNT=`ls -1 $MYS_INPUT_FILE | wc -l`
        if [ $FILE_COUNT -gt 0 ]
        then
        FILE_FOUND='Y'
        echo "Y" >> $FILE_CHECK_FILE
        else
        FILE_FOUND='N'
        echo "`date '+%F %T'` | INFO | Awaiting Files in Input Directory For Mystique Extraction Of `date +%F`"  >> $LOG_FILE
        fi
fi


if [ "$FILE_FOUND" = "Y" ]
then
cd $MYS_INPUT_PATH
FILE_COUNT=`ls -1 $MYS_INPUT_FILE | wc -l`
        if [ $FILE_COUNT -gt 0 ];
        then
        currHour=`date "+%H"`
        if [ $currHour -gt 4 ]
        then
        echo "`date '+%F %T'` | WARN | Mystique Extraction For `date +%F` is Extending Beyond 5 AM."  >> $LOG_FILE
        MSG="Mystique Extraction For `date +%F` is Extending Beyond 5 AM. Do NeedFul !"
        sendEmailAlert
        fi
        echo "`date '+%F %T'` | INFO | Mystique Extraction For `date +%F` is in Progress."  >> $LOG_FILE
        elif [ $FILE_COUNT -eq 0 ]; then
        echo "`date '+%F %T'` | INFO | Mystique Extraction For `date +%F` Completed."  >> $LOG_FILE
        MSG="Mystique Extraction For `date +%F` Completed."
        sendEmailAlert
        exit
        fi
fi

if [ "$FILE_FOUND" = "N" ]
then
currHour=`date "+%H"`
        if [ $currHour -gt 4 ];
        then
        echo "`date '+%F %T'` | ERR | Mystique Input Files With Date Stamp $DATE_OLD For `date +%F` Did Not Reach Input Directory Till 5 AM,Exiting Monitoring Script."  >> $LOG_FILE
        MSG="Mystique Input Files For `date +%F` Did Not Reach Input Directory Till 5 AM, Exiting Monitoring Script."
        sendEmailAlert
        exit
        fi
fi

currHour=`date "+%H"`
        if [ $currHour -eq 23 ];
        then
        echo "`date '+%F %T'` | ERR | Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script."  >> $LOG_FILE
        MSG="Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script For The Day. Tomorrow's Instance Will Capture Processing of Tomorrow's File."
        sendEmailAlert
        exit
        fi

sleep 15m
done

