#!/bin/bash

#########################################
#Config for the DBExport
#########################################

ARCHIVE_FOLDER=/opt/knowesis/sift/orchestrator/archive/event_config
DATABASE_HOME=/opt/knowesis/sift/orchestrator/mysql/data
username=root
password=password
#The following Directory should 777 permissions
SourcePATH=$DATABASE_HOME
SOCKET=/opt/knowesis/sift/orchestrator/mysql/mysql_5.7.18/socket
DatabaseName=transactions
#Optional Column
#ColumnCondition="EVENT_TIMESTAMP >='$date_threshold'"

exec 1>>$DATABASE_HOME/log/DBExport_`date "+%Y%m%d"`.log
exec 2>>$DATABASE_HOME/log/DBExport_`date "+%Y%m%d"`.err

#EVENT_CONFIG_Header="MSISDN|OFFER_CODE|EVENT_ID|FLOW_ID|PARENT_EVENT_ID|EVENT_SOURCE|TOPUP_PROFILE_ID|PROVISIONED_VALUE|PROVISIONING_SYSTEM|EVENT_TIMESTAMP|NOTIFICATION_MESSAGE|ACTION_RESPONSE|EVENT_TYPE|ACTION_TYPE|NOTIFICATION_CHANNEL|ACTION_STATUS|IS_CONTROL|IS_MULTIEVENT|IS_MONITORED|TREATMENT_CODE|IS_SIMULATED"
DestinationIP=n105938@Inbound.edw.in.telstra.com.au
#lxapp0277.edw.in.telstra.com.au
DestinationPATH=/pr1/data/CSA/prd/ent/inbound/sift/src/land

date_old=`date --date="1 days ago" "+%s000"`
date_human=`date "+%Y%m%d"`

echo "==========================EVENT_CONFIG=================================="
Header="EVENT_ID~~EVENT_NAME~~EVENT_DESCRIPTION~~EVENT_CATEGORY~~STATUS~~CREATION_DATE~~LAST_UPATEDATE"
filename="Event_Config"
TableName="EVENT_CONFIG"
ColumnCondition=

cd /opt/knowesis/sift/orchestrator/mysql/mysql_5.7.18/bin/

echo $Header > $SourcePATH/${filename}_${date_human}.csv
#echo "Generating Dump of the Table $TableName at $SourcePATH Started at `date "+%Y%m%d%H%M%S"`";
if [ "$ColumnCondition" != "" ];then
./mysqldump -u $username --socket=$SOCKET --password=$password --skip-set-charset --tab=$SourcePATH  --fields-terminated-by="~~" $DatabaseName $TableName  --where "$ColumnCondition";
else 
./mysqldump -u $username --password=$password --socket=$SOCKET --skip-set-charset --tab=$SourcePATH --fields-terminated-by="~~" $DatabaseName $TableName;
fi
cat $SourcePATH/$TableName.txt >> $SourcePATH/${filename}_${date_human}.csv
rm $SourcePATH/$TableName.txt
echo "Generating Dump of the Table $TableName at $Path Finished at `date "+%Y%m%d%H%M%S"`";

count=`wc -l $SourcePATH/${filename}_${date_human}.csv | awk '{print $1}'`
extractTime=`date "+%H%M%S"`
baseFilename=${filename}_${date_human}

echo "$count|$date_human|$extractTime|$baseFilename|1|SIFT|0" > $SourcePATH/${filename}_${date_human}.ctl

echo "Copying files to remote server $DestinationIP" starts  at `date "+%Y%m%d%H%M%S"`
cd $SourcePATH
touch ${filename}_${date_human}.eot
sftp $DestinationIP << END
put ${filename}_${date_human}.ctl
put ${filename}_${date_human}.csv
quit
END
#scp $SourcePATH/$filename.csv  $DestinationIP:$DestinationPATH
if [ $? -eq 0 ]; then
	#ssh $DestinationIP "touch $DestinationPATH/$filename_${date_old_human}.eot"
	sftp $DestinationIP << END
		put ${filename}_${date_human}.eot
		quit
END
	echo "Copying files to remote server $DestinationIP" finished at `date "+%Y%m%d%H%M%S"`
else
	echo "File transfer failed $DestinationIP"
fi

tar --remove-files -cvzf $ARCHIVE_FOLDER/${filename}_${date_human}.tar $SourcePATH/${filename}_${date_human}* -C $DATABASE_HOME

