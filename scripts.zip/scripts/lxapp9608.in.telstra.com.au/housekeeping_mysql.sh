#!/bin/bash

username=root
password=password
DatabaseName=transactions
DATABASE_HOME=/opt/knowesis/sift/orchestrator/mysql/mysql_5.7.18
SOCKET=$DATABASE_HOME/socket

date_old_human=`date --date="30 days ago" "+%Y%m%d"`
date_old=`date --date="$date_old_human" "+%s000"`

cd $DATABASE_HOME/bin

./mysql --user="$username" --password="$password" --socket="$SOCKET" --database="$DatabaseName" --execute="DELETE FROM TAG_LIST WHERE EVENT_TIMESTAMP<'$date_old';DELETE FROM EVENT_TRIGGER WHERE EVENT_TIMESTAMP<'$date_old';DELETE FROM OFFER_DETAILS WHERE EVENT_TIMESTAMP<'$date_old'"
