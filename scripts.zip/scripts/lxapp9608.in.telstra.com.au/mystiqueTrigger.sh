#!/bin/sh

MYSTIQUE_OUTPUT_DIR=/data/mystique/OUTPUT_FILES
MYSTIQUE_LOGS_DIR=/opt/knowesis/sift/core/sift/scripts/LOGS_MYSTIQUE
exec 1>>$MYSTIQUE_LOGS_DIR/Mystique_`date "+%Y%m"`.log
exec 2>>$MYSTIQUE_LOGS_DIR/Mystique_`date "+%Y%m"`.err

DestinationIP=n100417@lxfile0023.in.telstra.com.au
DestinationPATH=/Athenian/Sift/reporting/

date_human=`date "+%Y%m%d"`

sed -i '/^$/d' $MYSTIQUE_OUTPUT_DIR/*${date_human}*

sequence=0
for file in $MYSTIQUE_OUTPUT_DIR/*${date_human}*; do
	count=`wc -l $file | awk '{print $1}'`
	echo "count=$count"
	extractTime=`date "+%H%M%S"`
	baseFilename=$(basename "$file")
	filename=${baseFilename%.*}
	sequence=${filename##*_}
	echo "$count|$date_human|$extractTime|$filename|$sequence|SIFT|0" > $MYSTIQUE_OUTPUT_DIR/${filename}.ctl
	scp $MYSTIQUE_OUTPUT_DIR/${filename}.ctl $DestinationIP:$DestinationPATH
	scp $file $DestinationIP:$DestinationPATH
	if [ $? -eq 0  ]; then
		eotFile=$MYSTIQUE_OUTPUT_DIR/${filename}.eot
		touch $eotFile
		scp $eotFile $DestinationIP:$DestinationPATH
		echo "`date "+%Y%m%d%H%M%S"` [INFO] $baseFilename uploaded to $DestinationIP finished"
	else
		echo "`date "+%Y%m%d%H%M%S"` [INFO] File transfer failed for $file"
	fi
	rm $MYSTIQUE_OUTPUT_DIR/${filename}.eot
	rm $MYSTIQUE_OUTPUT_DIR/${filename}.ctl
done

eobFile=$MYSTIQUE_OUTPUT_DIR/Sift_Extract_${date_human}.eob
countOfFiles=`find $MYSTIQUE_OUTPUT_DIR/ -maxdepth 1 -name "Sift_Extract*${date_human}*csv" | wc -l`
echo "$date_human|$countOfFiles" > $eobFile
scp $eobFile $DestinationIP:$DestinationPATH
rm $eobFile
echo "`date "+%Y%m%d%H%M%S"` [INFO] All the files have been transfered to Athenian"
