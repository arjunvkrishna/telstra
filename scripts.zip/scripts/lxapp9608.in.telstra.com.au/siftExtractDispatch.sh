#!/bin/bash

MYSTIQUE_OUTPUT_DIR=/data/mystique/OUTPUT_FILES
MYSTIQUE_ARCHIVE_DIR=/data/mystique/OUTPUT_FILES/archive

MYSTIQUE_LOGS_DIR=/opt/knowesis/sift/core/sift/scripts/LOGS_MYSTIQUE

exec 1>>$MYSTIQUE_OUTPUT_DIR/Mystique_`date "+%Y%m"`.log
exec 2>>$MYSTIQUE_OUTPUT_DIR/Mystique_`date "+%Y%m"`.err

DestinationIP=n105938@Inbound.edw.in.telstra.com.au
DestinationPATH=/pr1/data/CSA/prd/ent/inbound/sift/src/land

date_human=`date "+%Y%m%d"`

sequence=0
for file in $MYSTIQUE_OUTPUT_DIR/*${date_human}*; do
	count=`wc -l $file | awk '{print $1}'`
	echo "count=$count"
	extractTime=`date "+%H%M%S"`
	baseFilename=$(basename "$file")
	filename=${baseFilename%.*}
	sequence=${filename##*_}
	echo "$count|$date_human|$extractTime|$filename|$sequence|SIFT|0" > $MYSTIQUE_OUTPUT_DIR/${filename}.ctl
	sftp $DestinationIP << END
                        put $MYSTIQUE_OUTPUT_DIR/${filename}.ctl
			put $file
                        quit
END
	if [ $? -eq 0  ]; then
		eotFile=$MYSTIQUE_OUTPUT_DIR/${filename}.eot
		touch $eotFile
		sftp $DestinationIP << END
                        put $MYSTIQUE_OUTPUT_DIR/${filename}.eot
                        quit
END
		echo "`date "+%Y%m%d%H%M%S"` [INFO] $baseFilename uploaded to $DestinationIP" finished
	else
		echo "`date "+%Y%m%d%H%M%S"` [INFO] File transfer failed for $file"
	fi
done

tar --remove-files -cvzf $MYSTIQUE_ARCHIVE_DIR/Sift_Extract_${date_human}.tar $MYSTIQUE_OUTPUT_DIR/*${date_human}* -C $MYSTIQUE_OUTPUT_DIR
echo "`date "+%Y%m%d%H%M%S"` [INFO] All the files have been archived in $MYSTIQUE_ARCHIVE_DIR/Sift_Extract_${date_human}.tar"
