#!/bin/bash
#MYSTIQUE_INPUT_LANDING=/opt/knowesis/sift/orchestrator/RIA/test
#MYSTIQUE_INPUT=/opt/knowesis/sift/orchestrator/RIA/test/moved
MYSTIQUE_INPUT_LANDING=/data/mystique/INPUT_FILES
MYSTIQUE_INPUT=/data/mystique/INPUT_FILES/input
SO1_USER=siftuser
SO1_SERVER=lxapp9606.in.telstra.com.au
SO1_COPY_TEMP=/data/knowesis/sift/orchestrator/sift-stitcher/data/mystique_input
#date_old=`date "+%Y%m%d"`

exec 1>>$MYSTIQUE_INPUT_LANDING/log/MystiqueInput_`date "+%Y%m"`.log
exec 2>>$MYSTIQUE_INPUT_LANDING/log/MystiqueInput_`date "+%Y%m"`.log

date_old=`date --date="1 days ago" "+%Y%m%d"`

if [ -e $MYSTIQUE_INPUT_LANDING/msisdn_${date_old}*eot ]
then
        echo "`date` [INFO] | Copying Mystique Input Files to SO1 Server"
		scp $MYSTIQUE_INPUT_LANDING/msisdn_${date_old}*csv $SO1_USER@$SO1_SERVER:$SO1_COPY_TEMP
		echo "`date` [INFO] | eot found for date ${date_old} ... Moving files.. "
        mv $MYSTIQUE_INPUT_LANDING/msisdn_${date_old}*csv $MYSTIQUE_INPUT
        echo "`date` [INFO] |  Files moved ..removing eot for date ${date_old}"
        rm $MYSTIQUE_INPUT_LANDING/msisdn_${date_old}*eot
else
        echo "`date` [INFO] | eot not found for date ${date_old}"
fi
