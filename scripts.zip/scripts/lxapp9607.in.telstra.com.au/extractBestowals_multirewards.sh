#####################################################################
#####################################################################
# Script name: extractBestowals.sh
# Description: This script gets the MSISDNs details for bestowal events
#              as listed in the input file from all the logs for the 
#              mentioned date and generates one csv file per event. 
#              It also generates a csv file containing all the end to end counts"
# Date       : 9-May-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

#!/bin/sh

#Variables
logFilePath="/opt/knowesis/sift/orchestrator/logs/"
export LC_ALL=C

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
# Input Args : None
#####################################################################
function usage ()
{
    echo -e "\nusage: sh extractBestowals.sh [<DD-Mmm-YYYY>]"
    echo "where:"
    echo -e "\tDate is optional. If no date is given, it runs for current date. Format is DD-Mmm-YYYY (`date +%d-%b-%Y`)"
    echo ""
    echo -e "\tThis script gets the MSISDNs details for bestowal events as listed"
    echo -e "\tin the input file from all the logs for the mentioned date and generates one csv file per event." 
    echo -e "\tIt also generates a csv file containing all the end to end counts"
    exit
}

#####################################################################
# Function   : set_ValidateParams
# Description: This function will set and validate required params
#              -> set the date if passed on
#              -> creates output directories, if not present
#              -> set the log files, input files names and path
#              -> checks if the input file exists or not
# Input Args : Run date passed on as DD-mmm-YYYY
#####################################################################
function set_ValidateParams()
{
    if [ $# -eq 1 ]; then
        runDate=$(date -d "$1" +"%d-%b-%Y")
        if [[ -z "$runDate" ]];   then
             echo "Please supply the date in DD-Mmm-YYYY Format i.e.,"$(date +"%d-%b-%Y")
             exit
        fi
        echo "Date Supplied is "$runDate
    else
        runDate=$(date +"%d-%b-%Y")
        echo "No Date Supplied So counting the files for today i.e., "$runDate
    fi

    #Log file names
    fileDate=`date -d "$runDate" +%F`
    InteractLogFile="sift-interact-handler.log.$fileDate*"
    ApolloLogFile="sift-apollo-handler.log.$fileDate*"
    MainsLogFile="sift-mains-handler.log.$fileDate*"
    ResponsysLogFile="sift-responsys-handler.log.$fileDate*"

    InputFile="/home/siftuser/PSNM_Scripts/EventIds_List_Bestowals.txt"
    OutputBestowalsPath="/home/siftuser/PSNM_Scripts/Output_Bestowals/$fileDate/"
    OutputALLBestowalsCountsFile="$OutputBestowalsPath/AllCounts_Bestowals_$runDate.csv"

    # If condition to check for the Event Ids File Existance
    if [ ! -f "$InputFile" ]; then
        echo "Event File Not Found, Please create a Event File "$InputFile" and add the event names for which you wanto to verify the Bestowals"
       exit
    fi

    if [ ! -d $OutputBestowalsPath ]; then
        mkdir -p $OutputBestowalsPath
    fi

    # If loop is to check for the same output file exists,if exists it will remove
    if [ -f $OutputALLBestowalsCountsFile ]; then
        rm $OutputALLBestowalsCountsFile
    fi

    # Write Header
    echo "Event ID","Interact Request Counts","Interact Response Counts","Interact ContactGroup","Interact ControlGroup","Interact NoOffer","Apollo Cunts", "Mains/Responsys Counts" >> $OutputALLBestowalsCountsFile

}

#####################################################################
# Function   : deleteTempFiles
# Description: This function deletes the temp files
# Input Args : None
#####################################################################
function deleteTempFiles ()
{
    rm -f $tempInteractRequest
    rm -f $tempInteractResponse
    rm -f $tempApolloResponse
    rm -f $tempApolloStatus
    rm -f $tempMainsResponse
    rm -f $tempResponsysResponse
}

#####################################################################
# Function   : extract_bestowals
# Description: This function does the following
#              -> extracts the MSISDNs and other details for each of the
#                 event ID from Interact, Apollo, MAINS and Responsys logs 
#                 files and writes it to corresponding temp files
#              -> Concatenates these temp files to create one .csv file per
#                 event ID which has all the details and summary counts on top
#              -> Creates overall detailed counts file for all event IDs
# Input Args : runDate and Event ID
#####################################################################
function extract_bestowals()
{
    OutputBestowalsFile="$OutputBestowalsPath/Bestowals_"$i"_"$runDate".csv"
    tempInteractRequest="$OutputBestowalsPath/"$runDate"_tempInteractRequest.csv"
    tempInteractResponse="$OutputBestowalsPath/"$runDate"_tempInteractResponse.csv"
    tempApolloResponse="$OutputBestowalsPath/"$runDate"_tempApolloResponse.csv"
    tempApolloStatus="$OutputBestowalsPath/"$runDate"_tempApolloStatus.csv"
    tempMainsResponse="$OutputBestowalsPath/"$runDate"_tempMainsResponse.csv"
    tempResponsysResponse="$OutputBestowalsPath/"$runDate"_tempResponsysResponse.csv"

    # If loop is to check for the same output file exists,if exists it will remove and creates a new one
    if [ -f $OutputBestowalsFile ] ;then
        rm $OutputBestowalsFile
    fi
    
    #delete all temp files
    deleteTempFiles

    cd $logFilePath
    
    # Search patterns to find out the details and dump the output in temp files
    searchString="\"MULTI_EVENT_ID\":\"$i\""
    grep -r "$runDate" $InteractLogFile| grep ','$searchString',' | grep 'Incoming Msg' | awk -F"ServiceId" '{print $2}' | sed 's/"://g' | sed 's/}//g' > $tempInteractRequest
    InteractRequestCounts=`wc -l $tempInteractRequest | awk '{print $1}'`
    
    searchString="\"EventId\":\"$i\""
    grep -r "$runDate" $InteractLogFile | grep -i ','$searchString','  | grep 'Incoming PostEvent Msg' | awk -F"EventGroup" '{print $2}' | awk -F"," '{print $2,",",$3,",",$4}' | sed 's/"ServiceId"://g' > $tempInteractResponse

    searchString="EventId=$i"     
    grep -r "$runDate" $InteractLogFile | grep 'EventId=' | grep -w $i | grep 'InteractResponseRoute' | grep 'No Offer'|  awk -F"ServiceId=" '{print $2}' | sort -u  | awk -F"," '{print ",",$4,",",$1}' >> $tempInteractResponse
    InteractResponseCounts=`wc -l $tempInteractResponse | awk '{print $1}'`
    InteractContactGroupCounts=`grep "Contact" $tempInteractResponse | wc -l  | awk '{print $1}'`
    InteractControlGroupCounts=`grep "Control" $tempInteractResponse | wc -l  | awk '{print $1}'`
    InteractNoOfferCounts=`grep -v "Control" $tempInteractResponse | grep -v "Contact" | wc -l  | awk '{print $1}'`

    searchString="\"EventId\":\"$i\""
    grep -r "$runDate" $ApolloLogFile | grep -i ','$searchString','  | grep 'Incoming Msg' | awk -F"ServiceId" '{print $2}' | cut -d"," -f1 | sed 's/"://g'> $tempApolloResponse
    ApolloRequestCounts=`wc -l $tempApolloResponse | awk '{print $1}'`

    searchString="EventId:$i"
    grep -r "$runDate" $ApolloLogFile  | grep "ProvisionFinalResponseProcessor" | grep 'INFO' | grep -i ','$searchString',' | awk -F"ServiceId" '{print $2}' |  grep "One of the Multiple Rewards" | awk -F"," '{print $1,"-",$5}'| awk -F"-" '{print $1,",",$4,$5}' | sed 's/\://g' >> $tempApolloStatus
 
 
    if [ $ServiceType = "HH" ]; then

        searchString="\"EventId\":\"$i\""   
        grep -r "$runDate" $MainsLogFile | grep -i ','$searchString','  | grep 'Incoming Msg' | awk -F"ServiceId" '{print $2}' | cut -d"," -f1,3 | sed 's/"://g'  > $tempMainsResponse
        MainsResponseCounts=`wc -l $tempMainsResponse  | awk '{print $1}'`

    elif [ $ServiceType = "MBB" ]; then
  
        searchString="EventId:"$i""
        grep -r "$runDate" $ResponsysLogFile  | grep ','$searchString','  | grep 'INFO' | grep 'Responsys Mail Request Added in the Bath' | awk -F"," '{print $3}'  | cut -d":" -f2  > $tempResponsysResponse
        ResponsysResponseCounts=`wc -l $tempResponsysResponse | awk '{print $1}'`
    fi
    
    # Print the Summary counts on top
    echo "Interact Request Counts :,$InteractRequestCounts" >> $OutputBestowalsFile
    echo "Interact Response Counts:,$InteractResponseCounts" >> $OutputBestowalsFile
    echo "Interact No Offers Counts:,$InteractNoOfferCounts" >> $OutputBestowalsFile
    echo "Interact Control group Counts:,$InteractControlGroupCounts" >> $OutputBestowalsFile
    echo "Apollo Request Counts  :,$ApolloRequestCounts" >> $OutputBestowalsFile
    
    
    if [ $ServiceType = "HH" ]; then
        echo "Mains Response Counts   :,$MainsResponseCounts" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
 
        echo "Interact Requests, Interact Response-TopupProfile, Interact Response-Offertype, Interact Response-MSISDN, Apollo Request-MSISDN, Apollo Response-MSISDN, Apollo Response-Status, Mains Response" >> $OutputBestowalsFile

        # Concatenate all the temp files sepeared by comma
        paste -d "," $tempInteractRequest $tempInteractResponse $tempApolloResponse $tempApolloStatus $tempMainsResponse >> $OutputBestowalsFile

        echo "$i","$InteractRequestCounts","$InteractResponseCounts","$InteractContactGroupCounts","$InteractControlGroupCounts","$InteractNoOfferCounts","$ApolloRequestCounts", "$MainsResponseCounts" >> $OutputALLBestowalsCountsFile

    elif [ $ServiceType = "MBB" ]; then
        echo "Responsys Response Counts   :,$ResponsysResponseCounts" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
        echo "" >> $OutputBestowalsFile
        
        echo "Interact Requests, Interact Response-TopupProfile, Interact Response-Offertype, Interact Response-MSISDN, Apollo Request-MSISDN, Apollo Response-MSISDN, Apollo Response-Status, Responsys Response" >> $OutputBestowalsFile

        # Concatenate all the temp files sepeared by comma
        paste -d "," $tempInteractRequest $tempInteractResponse $tempApolloResponse $tempApolloStatus $tempResponsysResponse >> $OutputBestowalsFile

        echo "$i","$InteractRequestCounts","$InteractResponseCounts","$InteractContactGroupCounts","$InteractControlGroupCounts","$InteractNoOfferCounts","$ApolloRequestCounts", "$ResponsysResponseCounts" >> $OutputALLBestowalsCountsFile
    fi

    #Forcefully delete all temp files
    deleteTempFiles
}

#####################################################################
# Function   : main
# Description: 
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" -o $# -lt 1 -o $# -gt 2 ]
then
    usage
    exit 0
fi

# Set paramaters - file locations and paths and validate the input arguments
set_ValidateParams $1

# For loop to run recursively for all the events in the input file 
for i in `cat $InputFile`
do
    # Set the service ID as per the event
    echo $i | grep "HH" > /dev/null
    if [ $? -eq 0 ]; then
        ServiceType="HH"
    fi

    echo $i | grep "MBB" > /dev/null
    if [ $? -eq 0 ]; then
        ServiceType="MBB"
    fi

    extract_bestowals $runDate $i
done
 
