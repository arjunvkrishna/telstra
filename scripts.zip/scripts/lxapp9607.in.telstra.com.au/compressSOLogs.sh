#Parent Path to be Defined Here
archiveFolderPath=/opt/knowesis/sift/orchestrator/logs/
#Log will be written in this file
mkdir -p $archiveFolderPath"archival_logs"
exec >>  /opt/knowesis/sift/orchestrator/logs/archival_logs/archive_`date +%F`.log
echo "==================================================================="
#Function to Archive the SO Logs
echo "Logs Archival & Compress Process Has Started For Directory at `date "+%Y%m%d%H%M%S"`"
date_Folder=`date --date="2 days ago" +"%F"`
cd $archiveFolderPath
mkdir -p $date_Folder
mv *log.$date_Folder* $date_Folder"/"
folderPath=$archiveFolderPath$date_Folder
	if [ -d "$folderPath" ]
	then
		archive_Dir_Name=$folderPath".tar.gz"
		actual_Dir_Name=$folderPath
		export GZIP=-9
		tar cfz $archive_Dir_Name -P $actual_Dir_Name
		rm -rf $actual_Dir_Name
	fi
echo "Logs Archival & Compress Process Has Finished at `date "+%Y%m%d%H%M%S"`"
#cd audit
#audit_Date_Folder=`date --date="2 days ago" +"%Y%m%d"`
#echo "Audit Logs Compress Process Has Started For Directory at `date "+%Y%m%d%H%M%S"`"
#for i in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23
#	do
#	actual_Audit_Date_Folder=$audit_Date_Folder"-"$i
#	archive_Dir_Name=$archiveFolderPath"audit/"$actual_Audit_Date_Folder".tar.gz"
#	actual_Dir_Name=$archiveFolderPath"audit/"$actual_Audit_Date_Folder
#	if [ -d "$actual_Dir_Name" ]
#	then
#		tar cfz $archive_Dir_Name -P $actual_Dir_Name
#		rm -rf $actual_Dir_Name
#	fi
#done
#echo "Audit Logs Compress Process Has Finished at `date "+%Y%m%d%H%M%S"`"
echo "==================================================================="
