#!/bin/sh

function sendEmailAlert ()
{   
    emailSubject="SIFT EMAIL ALERT "\!\!\!" Consumer Count Check - `date +%F`"
toAddressArray=('Shabeena_M@infosys.com' 'Saikrishna_Doli@infosys.com' 'bhuvan.siddaramu@infosys.com')
tail -7 ${LOG_FILE} | head -6 | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0408574590@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0466961887@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919496152994@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919663679814@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0431812571@sms.in.telstra.com.au"
}


function checkActiveMQ ()
{
PATH=/opt/knowesis/sift/orchestrator/jdk1.8.0_45/bin:/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/siftuser/bin:/data/knowesis/sift/orchestrator/jdk1.8.0_45/bin
currHourConsumerCheckFile="/home/siftuser/PSNM_Scripts/HealthCheck/currHourConsumerCheck.log"
activemqPath="/opt/knowesis/sift/orchestrator/apache-activemq-5.14.2/bin"
rm -f $currHourConsumerCheckFile
echo "`date '+%F %T'` | INFO | Server: `uname -n` | ActiveMQ Stats " >> $currHourConsumerCheckFile
cd $activemqPath
./activemq dstat queues | sed -n '/Name/,$p' >> $currHourConsumerCheckFile

#Check Active MQ Status Before Checking Consumers, if dstat is Returning No Rows, Send Alert to Check Active MQ and Exit Script
FILECOUNT=`cat $currHourConsumerCheckFile | wc -l`
if [ $FILECOUNT -eq 1 ]; then
echo "Active MQ DSTAT Command Did Not Return Any Rows, Chances Are That Active MQ is Not Running." >> $LOG_FILE
EMAIL_CONTENT="$ServerName Active MQ DSTAT Command Did Not Return Any Rows, Check Active MQ."
MSG="$ServerName Active MQ DSTAT Command Did Not Return Any Rows, Check Active MQ."
sendEmailAlert
exit 1 
else
echo "Active MQ DSTAT Command Returns Rows, Active MQ Running" >> $LOG_FILE
fi
}


function checkConsumerCountSet1 ()
{
#Compare Actual and Expected For Not Null Actual Consumer Values
for QUEUE in $QUEUE_NAMES_WITH_10_CONSUMERS;
do
ACT_CONS_COUNT=`grep "$QUEUE" $currHourConsumerCheckFile | awk '{print$4}'`
if [ -z "$ACT_CONS_COUNT" ]
then
echo "$QUEUE Not Present in This Hour's ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $ACT_CONS_COUNT -ne $EXP_CONS_COUNT_SET1 ]
then
echo "Consumer Count of $QUEUE is Not Matching Expected Value of $EXP_CONS_COUNT_SET1, Actual:$ACT_CONS_COUNT" >> $LOG_FILE
EMAIL_CONTENT="$ServerName Consumer Count of $QUEUE is Not Matching Expected Value of $EXP_CONS_COUNT_SET1, Actual:$ACT_CONS_COUNT. Please Check!"
MSG="$ServerName Consumer Count of $QUEUE is Not Matching. Expected:$EXP_CONS_COUNT_SET1,Actual:$ACT_CONS_COUNT"
sendEmailAlert
else
echo "Consumer Count of $QUEUE is Matching Expected Value" >> $LOG_FILE
fi
fi
done
}

function checkConsumerCountSet2S01 ()
{
#Compare Actual and Expected For Not Null Actual Consumer Values
for QUEUE in $QUEUE_NAMES_WITH_1_CONSUMER_SO1;
do
ACT_CONS_COUNT=`grep "$QUEUE" $currHourConsumerCheckFile | awk '{print$4}'`
if [ -z "$ACT_CONS_COUNT" ]
then
echo "$QUEUE Not Present in This Hour's ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $ACT_CONS_COUNT -ne $EXP_CONS_COUNT_SET2 ]
then
echo "Consumer Count of $QUEUE is Not Matching Expected Value of $EXP_CONS_COUNT_SET2, Actual:$ACT_CONS_COUNT" >> $LOG_FILE
EMAIL_CONTENT="$ServerName Consumer Count of $QUEUE is Not Matching Expected Value of $EXP_CONS_COUNT_SET2, Actual:$ACT_CONS_COUNT. Please Check!"
MSG="$ServerName Consumer Count of $QUEUE is Not Matching. Expected:$EXP_CONS_COUNT_SET2,Actual:$ACT_CONS_COUNT"
sendEmailAlert
else
echo "Consumer Count of $QUEUE is Matching Expected Value" >> $LOG_FILE
fi
fi
done
}

function checkConsumerCountSet2S02 ()
{
#Compare Actual and Expected For Not Null Actual Consumer Values
for QUEUE in $QUEUE_NAMES_WITH_1_CONSUMER_SO2;
do
ACT_CONS_COUNT=`grep "$QUEUE" $currHourConsumerCheckFile | awk '{print$4}'`
if [ -z "$ACT_CONS_COUNT" ]
then
echo "$QUEUE Not Present in This Hour's ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $ACT_CONS_COUNT -ne $EXP_CONS_COUNT_SET2 ]
then
echo "Consumer Count of $QUEUE is Not Matching Expected Value of $EXP_CONS_COUNT_SET2, Actual:$ACT_CONS_COUNT" >> $LOG_FILE
EMAIL_CONTENT="$ServerName Consumer Count of $QUEUE is Not Matching Expected Value of $EXP_CONS_COUNT_SET2, Actual:$ACT_CONS_COUNT. Please Check!"
MSG="$ServerName Consumer Count of $QUEUE is Not Matching. Expected:$EXP_CONS_COUNT_SET2,Actual:$ACT_CONS_COUNT"
sendEmailAlert
else
echo "Consumer Count of $QUEUE is Matching Expected Value" >> $LOG_FILE
fi
fi
done
}

#####################################################################
# Function   : main
# Description: 
#####################################################################
SO1_hostname="lxapp9606"
SO2_hostname="lxapp9607"
EXP_CONS_COUNT_SET1=10
EXP_CONS_COUNT_SET2=1
QUEUE_NAMES_WITH_10_CONSUMERS="so.recordkeeper.in sift.batch.01 so-batch.apollo.provision.req.in so-batch.mains-sms-req-queue so-batch.interact.postevent.req.in so-batch.interact.offer.req.in so-batch.interact-nooffer.monitor.in sift-batch.monitor.req.in so-batch.email.responsys.in so-batch.email-responsys-api-req-in-queue so-batch.audit.queue sift.realtime.01 so.mains-sms-req-queue so.interact.postevent.req.in so.interact.offer.req.in so.interact-nooffer.monitor.in so.email.responsys.in so.email-responsys-api-req-in-queue so.audit.queue so.apollo.provision.req.in sift.monitor.req.in"
QUEUE_NAMES_WITH_1_CONSUMER_SO1="sift.admin.in sift.config.in sift.monitor.in sift.result.in"
QUEUE_NAMES_WITH_1_CONSUMER_SO2="sift.monitor.in"
LOG_FILE="/home/siftuser/PSNM_Scripts/HealthCheck/ConsumerCheckLog.`date +%F`.log"


if [ `uname -n` = "$SO1_hostname" ]; then
ServerName="S01"
echo "`date '+%F %T'` | INFO | Checking Consumer Counts of SO2 Active MQ Queues For Current Hour From ActiveMQ Hourly Status Logs Started" >> $LOG_FILE
checkActiveMQ
#currHourConsumerCheckFile="/home/siftuser/PSNM_Scripts/HealthCheck/currHourConsumerCheck.log"
checkConsumerCountSet1
checkConsumerCountSet2S01
echo "`date '+%F %T'` | INFO | Checking Consumer Counts of SO2 Active MQ Queues For Current Hour From ActiveMQ Hourly Status Logs Completed" >> $LOG_FILE
fi

if [ `uname -n` = "$SO2_hostname" ]; then
ServerName="S02"
echo "`date '+%F %T'` | INFO | Checking Consumer Counts of SO2 Active MQ Queues For Current Hour From ActiveMQ Hourly Status Logs Started" >> $LOG_FILE
checkActiveMQ
#currHourConsumerCheckFile="/home/siftuser/PSNM_Scripts/HealthCheck/currHourConsumerCheck.log"
checkConsumerCountSet1
checkConsumerCountSet2S02
echo "`date '+%F %T'` | INFO | Checking Consumer Counts of SO2 Active MQ Queues For Current Hour From ActiveMQ Hourly Status Logs Completed" >> $LOG_FILE
fi


