#####################################################################
#####################################################################
# Script name: siftOrchestratorStatus.sh
# Description: This script gets the overall status of Sift Orchestrator
#              ->ActiveMQ
#              ->Redis Server
#              -> Realtime Handlers
#              -> Batch Handlers
# Date       : 11-Mar-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

# Variables
realTimeHandlersPath="/opt/knowesis/sift/orchestrator/bin"
batchHandlersPath="/opt/knowesis/sift/orchestrator/batchHandlers/bin"
apolloReplicatorPath="/opt/knowesis/sift/orchestrator/sift-apollo-replicator/bin"
monitorReplicatorPath="/opt/knowesis/sift/orchestrator/sift-monitor-replicator/bin"
optinHandlerPath="/opt/knowesis/sift/orchestrator/optinHandler/bin"
MohandlerPath="/opt/knowesis/sift/orchestrator/optinHandler/bin"
RecordkeeperPath="/opt/knowesis/sift/orchestrator/recordkeeper/bin"

SO1_hostname="lxapp9606"
SO2_hostname="lxapp9607"
batchwindowStart="11"
batchwindowEnd="18"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo "usage: sh siftOrchestratorStatus.sh"
    echo "This script checks the overall status of Sift Orchestrator"
}




function sendEmailAlert ()
{
    emailSubject="SIFT EMAIL ALERT "\!\!\!" $content- `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'Sowmya.T02@infosys.com' 'Nirmal_Thekkekkota@infosys.com')
        echo $MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
        echo $MSG | mailx -s $MSG "0470656627@sms.in.telstra.com.au"
        echo $MSG | mailx -s $MSG "0466961887@sms.in.telstra.com.au"
        echo $MSG | mailx -s $MSG "919003230905@sms.in.telstra.com.au"
}


#####################################################################
# Function   : activemqStatus
# Description: This functions checks if Active MQ is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function activemqStatus ()
{
    # sift orchestrator activemq status
    status=$(netstat -na | grep :8161  | awk 'NR==1{printf "%s\n", $6}');
    if [ "$status" = "LISTEN" ];then
        echo "Active MQ status : Running" | tee -a $SOStatusFile
    else
        echo "Active MQ status : Not Running" | tee -a $SOStatusFile
          MSG="SO2 Active MQ Console is not Running"
          content="SO2 ActiveMQ Console is not running"
          sendEmailAlert    
fi
}

#####################################################################
# Function   : redisStatus
# Description: This functions checks if Redis Servers is running or not
#              and displays the status accordingly on the console and 
#              also writes it to log file
#####################################################################
function redisStatus ()
{
    status=$(netstat -na | grep ':6379 '  | awk 'NR==1{printf "%s\n", $6}');
    if [ "$status" = "LISTEN" ];then
        echo "Redis Server status : Running"  | tee -a $SOStatusFile
    else
        echo "Redis Server status : Not Running" | tee -a $SOStatusFile
    fi
}

#####################################################################
# Function   : realTimeHandlersStatus
# Description: This functions checks if all the realtime handlers are 
#              running or not and displays the status accordingly on 
#              the console and also writes it to log file 
#              It checks the below handlers
#              -> Core Handler
#              -> Interact Handler
#              -> Mains Handler 
#              -> Responsys Handler 
#              -> Apollo Provisioning Handler 
#              -> Audit Handler 
#              -> Web Console Handler 
#####################################################################
function realTimeHandlersStatus ()
{
    # Core handler status
    cd $realTimeHandlersPath
    corehandler_row=$(sh checkCoreHandler.sh | wc -l);
    if [ "$corehandler_row" = 2 ];then
        echo "Core handler status : Running" | tee -a $SOStatusFile
    else
        echo "Core handler status : Not Running" | tee -a $SOStatusFile
    fi

    #Interact handler status
    interacthandler_row=$(sh checkInteractHandler.sh | wc -l);
    if [ "$interacthandler_row" = 2 ]; then
       echo "Interact handler status : Running" | tee -a $SOStatusFile
else 
       echo "Interact handler status : Not Running" | tee -a $SOStatusFile
      MSG="SO2 Interact Handler is not Running"
      content="SO2 InteractHanlder is not running"
      sendEmailAlert

fi

    #Mains handler status
    mainshandler_row=$(sh checkMainsSMSHandler.sh | wc -l);
    if [ "$mainshandler_row" = 2 ];then
        echo "Mains handler status : Running" | tee -a $SOStatusFile
    else
        echo "Mains handler status : Not Running" | tee -a $SOStatusFile
    fi

    #Responsys handler status
    responsyshandler_row=$(sh checkResponsysHandler.sh | wc -l);
    if [ "$responsyshandler_row" = 2 ]; then
        echo "Responsys handler status : Running" | tee -a $SOStatusFile
    else
        echo "Responsys handler status : Not Running" | tee -a $SOStatusFile
    fi


    #Sift orchestrator Apollo Provision Handler status
    apollohandler_row=$(sh checkApolloProvisionHandler.sh | wc -l);
    if [ "$apollohandler_row" = 2 ]; then
        echo "Apollo handler status : Running" | tee -a $SOStatusFile
    else
        echo "Apollo handler status : Not Running" | tee -a $SOStatusFile
    fi


    #Sift orchestrator Web console Handler status
    webhandler_row=$(sh checkWebHandler.sh | wc -l);
    if [ "$webhandler_row" = 2 ]; then
        echo "Web console handler status : Running" | tee -a $SOStatusFile
    else
        echo "Web console handler status : Not Running" | tee -a $SOStatusFile
    fi
    
    #Sift orchestrator Audit Handler status
    audithandler_row=$(sh checkAuditHandler.sh | wc -l);
    if [ "$audithandler_row" = 2 ]; then
        echo "Audit handler status : Running" | tee -a $SOStatusFile
    else
        echo "Audit handler status : Not Running" | tee -a $SOStatusFile
    fi
	
		 #Sift orchestrator Optin Handler status
	  cd $optinHandlerPath

    optinHandler_row=$(ps -ef|grep so-apioptinhandler.sh | wc -l);
    if [ "$optinHandler_row" = 2 ]; then
        echo "Optin handler status : Running" | tee -a $SOStatusFile
    else
        echo "Optin handler status status : Not Running" | tee -a $SOStatusFile
    fi;
	
	 #Sift orchestrator Mohandler status
	 
	 cd $MohandlerPath

    MohandlerPath_row=$(ps -ef|grep so-mohandler.sh| wc -l);
    if [ "$MohandlerPath_row" = 2 ]; then
        echo "Mohandler status : Running" | tee -a $SOStatusFile
    else
        echo "Mohandler status : Not Running" | tee -a $SOStatusFile
    fi;
	
	 #Sift orchestrator RecordKeeper Handler status
	
		 cd $RecordkeeperPath

    RecordkeeperPath_row=$(sh so-recordkeeper.sh status | wc -l);
    if [ "$RecordkeeperPath_row" = 2 ]; then
        echo "Recordkeeper status : Running" | tee -a $SOStatusFile
    else
        echo "Recordkeeper status : Not Running" | tee -a $SOStatusFile
    fi;
}

#####################################################################
# Function   : batchHandlersStatus
# Description: This functions checks if all the batch handlers are 
#              running or not and displays the status accordingly on 
#              the console and also writes it to log file 
#              It checks the below handlers
#              -> Unica Handler
#              -> Interact Handler
#              -> Mains Handler 
#              -> Responsys Handler 
#              -> Apollo Replicator 
#              -> Monitor Replicator 
#              -> Audit Handler
#              -> Web Console Handler 
#####################################################################
function batchHandlersStatus ()
{
    current_hour=`date +%H`
    outOfWindow="FALSE"
    
    if [ "$current_hour" -lt "$batchwindowStart" ] || [ "$current_hour" -gt "$batchwindowEnd" ]; then
        batchHandlersError_msg="OUT OF CONTACT WINDOW (11AM to 6PM), BATCH HANDLERS SHOULD NOT RUN - Please check Crontab"
        outOfWindow="TRUE"
    fi

    # Sift orchestrator core handler status
    cd $batchHandlersPath
    batchUnicaHandler_row=$(sh sobatch-Unica.sh status | wc -l);
    if [ "$batchUnicaHandler_row" -ge 1 ];then
        echo "Batch Unica handler status : Running" | tee -a $SOStatusFile
        if [ "$outOfWindow" = "TRUE" ]; then
            echo "batchHandlersError_msg"  | tee -a $SOStatusFile
        fi
    else
        if [ $outOfWindow = "FALSE" ]; then
            echo "Batch Unica handler status : Not Running" | tee -a $SOStatusFile
        else
            echo "Batch Unica handler status : Will be Scheduled during batch window (11AM to 6PM)" | tee -a $SOStatusFile
        fi        
    fi

    #Sift orchestrator Interact handler status
    batchInteractHandler_row=$(sh sobatch-Interact.sh status | wc -l);
    if [ "$batchInteractHandler_row" -ge 1 ]; then
       echo "Batch Interact handler status : Running" | tee -a $SOStatusFile
    else 
       echo "Batch Interact handler status : Not Running" | tee -a $SOStatusFile
    fi

    #Sift orchestrator Mains handler status
    batchMainsHandler_row=$(sh sobatch-Mains.sh status | wc -l);
    if [ "$batchMainsHandler_row" -ge 1 ];then
        echo "Batch Mains handler status : Running" | tee -a $SOStatusFile
        if [ "$outOfWindow" = "TRUE" ]; then
            echo $batchHandlersError_msg | tee -a $SOStatusFile
        fi
    else
        if [ $outOfWindow = "FALSE" ]; then
            echo "Batch Mains handler status : Not Running" | tee -a $SOStatusFile
        else
            echo "Batch Mains handler status : Will be Scheduled during batch window (11AM to 6PM)" | tee -a $SOStatusFile
        fi
    fi

    #Sift orchestrator Responsys handler status
    batchResponsysHandler_row=$(sh sobatch-Responsys.sh status | wc -l);
    if [ "$batchResponsysHandler_row" -ge 1 ];then
        echo "Batch Responsys handler status : Running" | tee -a $SOStatusFile
        if [ "$outOfWindow" = "TRUE" ]; then
            echo $batchHandlersError_msg | tee -a $SOStatusFile
        fi
    else
        if [ $outOfWindow = "FALSE" ]; then
            echo "Batch Responsys handler status : Not Running" | tee -a $SOStatusFile
        else
            echo "Batch Responsys handler status : Will be Scheduled during batch window (11AM to 6PM)" | tee -a $SOStatusFile
        fi
    fi

    #Apollo Replicator Handler status
    cd $apolloReplicatorPath
    apolloReplicator_row=$(sh sobatch-ReplicateApollo.sh status | wc -l);
    if [ "$apolloReplicator_row" -ge 1 ]; then
        echo "Batch Apollo Replicator handler status : Running" | tee -a $SOStatusFile
    else
        echo "Batch Apollo Replicator handler status : Not Running" | tee -a $SOStatusFile
    fi

    #Sift orchestrator Web console Handler status
    cd $monitorReplicatorPath
    monitorReplicator_row=$(sh sobatch-ReplicateMonitor.sh status | wc -l);
    if [ "$monitorReplicator_row" -ge 1 ]; then
        echo "Batch Monitor Replicator handler status : Running" | tee -a $SOStatusFile
    else
        echo "Batch Monitor Replicator handler status : Not Running" | tee -a $SOStatusFile
    fi;
    
    #Sift orchestrator Audit Handler status
    cd $realTimeHandlersPath
    audithandler_row=$(sh checkAuditHandler.sh | wc -l);
    if [ "$audithandler_row" = 2 ]; then
        echo "Audit handler status : Running" | tee -a $SOStatusFile
    else
        echo "Audit handler status : Not Running" | tee -a $SOStatusFile
    fi;
    
    #Sift orchestrator Web console Handler status
    webhandler_row=$(sh checkWebHandler.sh | wc -l);
    if [ "$webhandler_row" = 2 ]; then
        echo "Web console handler status : Running" | tee -a $SOStatusFile
    else
        echo "Web console handler status : Not Running" | tee -a $SOStatusFile
    fi
	
}


#####################################################################
# Function   : main
# Description: 
#####################################################################

if [ `uname -n` = "$SO1_hostname" ]; then
    SOStatusFile="/home/siftuser/PSNM_Scripts/HealthCheck/SO1_Status.`date +%F`.log"
    echo "======================================================" | tee -a $SOStatusFile
    echo "`date '+%F %T'` | INFO | Server: `uname -n` | Sift Orchestrator status" | tee -a $SOStatusFile
    activemqStatus
    redisStatus
    batchHandlersStatus
    echo "======================================================" | tee -a $SOStatusFile
fi

if [ `uname -n` = "$SO2_hostname" ]; then
    SOStatusFile="/home/siftuser/PSNM_Scripts/HealthCheck/SO2_Status.`date +%F`.log"
    echo "======================================================" | tee -a $SOStatusFile
    echo "`date '+%F %T'` | INFO | Server: `uname -n` | Sift Orchestrator status" | tee -a $SOStatusFile
    activemqStatus
    redisStatus
    realTimeHandlersStatus
    echo "======================================================" | tee -a $SOStatusFile
fi

