#####################################################################
#####################################################################
# Script name: getSMSCountsMains.sh
# Description: This script gets the counts of requests sent to MAINS 
#              for each event ID as list in the input file.
#              It will also generate cvs files for each event containing
#              important information from the logs like - SessionID,
#              MSISDN,  Flow ID, Offer type
# Version History:
# 1.0 | 30-Mar-2016 | Infosys | Original Version
# 3.0 | 31-May-2018 | Infosys | Version For SIFT V3
#####################################################################
#####################################################################

#Variables
SO1_hostname="lxapp9606"
SO2_hostname="lxapp9607"
donePath="/data/knowesis/unica/uc-in/done/"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo -e "\nusage : sh getSMSCountsMains.sh [<DD-Mmm-YYYY>]"
    echo "where"
    echo -e "\tDate is optional. Format is DD-Mmm-YYYY (`date +%d-%b-%Y`)"
    echo "Description:"
    echo -e "\t\tThis script generates a CSV report containing the SMS counts"
    echo -e "\t\tfor all the events as listed in the input file."
    echo -e "\t\tIt will also generate cvs files for each event containing"
    echo -e "\t\timportant information from the logs like - SessionID,"
    echo -e "\t\tMSISDN, Flow ID, Offer type"
    exit
}

DATE_VALUE=`date --date="1 days ago" "+%Y-%m-%d"`
DATE_VALUE_1_DAY_AHEAD=`date --date="next day $DATE_VALUE" "+%Y-%m-%d"`
list=$(find /opt/knowesis/sift/orchestrator/so-batch-telstra/log -type f -name 'so-mainshandler.log' -size +0b -newermt $DATE_VALUE ! -newermt $DATE_VALUE_1_DAY_AHEAD);
echo $list
DATEVALUEREPORT=`date --date="1 days ago" "+%Y-%m-%d"`
REPORT="$DATEVALUEREPORT"-0000
cp $list /opt/knowesis/sift/orchestrator/so-batch-telstra/log/archive/so-mainshandler.log-$REPORT

#####################################################################
# Function   : prepareBatchEventList
# Description: 
#####################################################################
function prepareBatchEventList ()
{
   cd $donePath
   cat *.$rundate* | awk -F"," '{print $4}' | grep "HH" | grep -v "Event_Id" | sort -u > $InputFile
   # Copy to SO2 as well - Future functionality
   # scp $InputFile sifuser@$SO2_hostname:/home/siftuser/PSNM_Scripts/
}
#####################################################################
# Function   : set_ValidateParams
# Description: This function will set and validate required params
#              -> set the date if passed on
#              -> creates output directories, if not present
#              -> set the log files, input files names and path
#              -> checks if the input file exists or not
# Input Args : Run date passed on as DD-mmm-YYYY
#####################################################################
function set_ValidateParams()
{
    #If no arguement has passed, this script will run for current day
    if [ $# -eq 0 ] ;then
        runDate=$(date +"%d-%b-%Y")
        echo "No Date Supplied So counting the files for today i.e., "$runDate
    else
        runDate=$(date -d "$1" +"%d-%b-%Y")
        if [[ -z "$runDate" ]];   then
             echo "Please supply the date in DD-Mmm-YYYY Format i.e.,"$(date +"%d-%b-%Y")
             exit
        fi
        echo "Date Supplied is "$runDate
    fi

    fileDate=`date -d "$runDate" +%F`
    OutputFlowIDPath="/home/siftuser/PSNM_Scripts/flowIDS_Mains/$fileDate"
    OutputCountsPath="/home/siftuser/PSNM_Scripts/Output_MainsCounts"

    if [ ! -d $OutputFlowIDPath ]; then
        mkdir -p $OutputFlowIDPath
    fi
    
    if [ ! -d $OutputCountsPath ]; then
        mkdir -p $OutputCountsPath
    fi
    
    if [ `uname -n` = "$SO1_hostname" ]; then
        logFilePaths="/opt/knowesis/sift/orchestrator/so-telstra/log/archive /opt/knowesis/sift/orchestrator/so-batch-telstra/log/archive"
        logFile="so-mainshandler.log-$fileDate*"
        transactionType="Batch"
		FileNameSuffix="S01"
        InputFile="/home/siftuser/PSNM_Scripts/SO1_"$transactionType"_EventIds_List_Mains.txt"
        OutputSMSFile="$OutputCountsPath/MainsCounts_"$FileNameSuffix"_"$transactionType"_"$runDate".csv"
        #prepareBatchEventList
    fi
    
    if [ `uname -n` = "$SO2_hostname" ]; then
        logFilePaths="/opt/knowesis/sift/orchestrator/so-telstra/log/archive /opt/knowesis/sift/orchestrator/so-batch-telstra/log/archive"
        logFile="so-mainshandler.log-$fileDate*"
        transactionType="RealTime"
		FileNameSuffix="S02"
        InputFile="/home/siftuser/PSNM_Scripts/SO2_"$transactionType"_EventIds_List_Mains.txt"
        OutputSMSFile="$OutputCountsPath/MainsCounts_"$FileNameSuffix"_"$transactionType"_"$runDate".csv"
    fi

    if [ -f $OutputSMSFile ] ;then
        rm $OutputSMSFile
    fi

    # If condition to check for the Event Ids File Existance
    if [ ! -f "$InputFile" ]; then
        echo "Event File Not Found, Please create a Event File "$InputFile" and add the event names for which you wanto to generate the stats"
        exit
    fi
}

#####################################################################
# Function   : extract_flowIds
# Description: 
#####################################################################
function extract_flowIds()
{
    tempFile1="$OutputFlowIDPath/tempFile1.csv"
    tempFile2="$OutputFlowIDPath/tempFile2.csv"

    cd $dir
    logDate=`date -d "$runDate" "+%m/%d/%y"`
	logDatePattern="\[$logDate"
	
    # Search Query to find out the flowID
    searchString="\"EventId\":\"$i\""
    grep -r "$logDatePattern" --include="$logFile" --exclude-dir={audit,*/audit} . | grep 'Incoming Msg' | grep ','$searchString',' | \
    awk -F'\"sessionID\"' '{print $2}' |  cut -d"," -f1 > $tempFile1

    grep -r "$logDatePattern" --include="$logFile" --exclude-dir={audit,*/audit} . | grep 'Incoming Msg' | grep ','$searchString',' | \
    awk -F'\"OfferType\"' '{print $2}' | awk -F"," '{print $1,","$2,",",$3,",",$4}' > $tempFile2
    
    paste -d "," $tempFile1 $tempFile2 >> $OutputFlowIDFile

    retval=`cat $tempFile2 | awk -F"," '{print $2}' | sort -u | wc -l`
   
#    rm -f $tempFile1 $tempFile2
}

#####################################################################
# Function   : sendFilesSFTP
# Description: This function does the following
#              -> transfers the files to lxfile 0023
# Input Args : None
#####################################################################
function sendFilesSFTP ()
{
    AthenianFileServer="lxfile0023.in.telstra.com.au"
    AthenianUserId="n100417"
    AthenianPath="/Athenian/Sift/reporting/BAU_reporting"
    scp -p $OutputSMSFile $AthenianUserId@$AthenianFileServer:$AthenianPath
    scp_status=`echo $?`
    if [ $scp_status -ne 0 ]
    then
        echo "Failed to TRANSFER the file `basename $OutputSMSFile` to Athenian file Server" 
        exit 1
    fi
 
    echo "Sucessfully transferred the files `basename $OutputSMSFile` to Athenian file server" 
    exit 0
}


#####################################################################
# Function   : main
# Description: 
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" ]; then 
    usage
    exit 0
fi

# Set paramaters - file locations and paths and validate the input arguments    
set_ValidateParams $1

# For loop to run recursively for all the events in the input file

for i in `cat $InputFile`
do
OutputFlowIDFile="$OutputFlowIDPath/MainsFlows_"$transactionType"_"$i"_"$runDate".csv"
# If loop is to check for the same output file exists,if exists it will remove and creates a new one
    if [ -f $OutputFlowIDFile ] ;then
      rm $OutputFlowIDFile
    fi
MainsCounts=0
	for dir in $logFilePaths;
	do
    extract_flowIds $runDate $i $dir $OutputFlowIDFile
	MainsCounts=$((MainsCounts+retval))
	done
echo $i","$MainsCounts >> $OutputSMSFile
done

sendFilesSFTP

## Extract counts for batch messages also which might land up on SO2 - Future Functionality
#if [ `uname -n` = "$SO2_hostname" ]; then
#    InputFile="/home/siftuser/PSNM_Scripts/SO1_Batch_EventIds_List_Mains.txt"
#    transactionType="Batch"
#    OutputSMSFile="$OutputCountsPath/MainsCounts_"$transactionType"_"$runDate".csv"
#    for i in `cat $InputFile`
#    do
#        extract_flowIds $runDate $i
#    done
#fi
