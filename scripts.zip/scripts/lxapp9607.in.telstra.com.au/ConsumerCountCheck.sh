#!/bin/sh
PATH=/opt/knowesis/sift/orchestrator/jdk1.8.0_45/bin:/usr/lib64/qt-3.3/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/siftuser/bin:/data/knowesis/sift/orchestrator/jdk1.8.0_45/bin
currHourConsumerCheckFile="/home/siftuser/PSNM_Scripts/HealthCheck/currHourConsumerCheck.log"
activemqPath="/opt/knowesis/sift/orchestrator/apache-activemq-5.14.2/bin"
rm -f $currHourConsumerCheckFile
echo "`date '+%F %T'` | INFO | Server: `uname -n` | ActiveMQ Stats " >> $currHourConsumerCheckFile
cd $activemqPath
./activemq dstat queues | sed -n '/Name/,$p' | awk '($4!=0 || $2!=0) {print}' >> $currHourConsumerCheckFile
LOG_FILE="/home/siftuser/PSNM_Scripts/HealthCheck/ConsumerCheckLog.`date +%F`.log"

function sendEmailAlert ()
{   
    emailSubject="SIFT EMAIL ALERT "\!\!\!" SO2 Consumer Count Check - `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'Sowmya.T02@infosys.com' 'Nirmal_Thekkekkota@infosys.com')
	echo $MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
        echo $MSG | mailx -s $MSG "0470656627@sms.in.telstra.com.au"
        echo $MSG | mailx -s $MSG "0466961887@sms.in.telstra.com.au"
        echo $MSG | mailx -s $MSG "919003230905@sms.in.telstra.com.au"
}

#Check Active MQ Status Before Checking Consumers, if dstat is Returning No Rows, Send Alert to Check Active MQ and Exit Script
FILECOUNT=`cat $currHourConsumerCheckFile | wc -l`
if [ $FILECOUNT -eq 1 ]; then
echo "Active MQ DSTAT Command Did Not Return Any Rows, Chances Are That Active MQ is Not Running." >> $LOG_FILE
MSG="Active MQ DSTAT Command Did Not Return Any Rows, Check Active MQ."
sendEmailAlert
exit 1 
else
echo "Active MQ DSTAT Command Returns Rows, Active MQ Running" >> $LOG_FILE
fi

echo "`date '+%F %T'` | INFO | Checking Consumer Counts of SO2 Active MQ Queues For Current Hour From ActiveMQ Hourly Status Logs" >> $LOG_FILE

#Set Expected Consumer Counts
DEAD_MAINS_CONS=0
DEAD_RESPONSYS_CONS=0
SIFT_EVENT_CONS=10
SIFT_MONITOR_CONS=1
SIFT_MONIT_REQ_CONS=10
SIFT_REG_CONS=1
APOLLO_PROV_CONS=50
AUDIT_QUEUE_CONS=10
EMAIL_RESP_API_CONS=10
EMAIL_RESP_CONS=10
FAIL_APOLLO_CONS=0
INT_OFFER_CONS=10
INT_PE_CONS=10
MAINS_SMS_CONS=50
MON_NOOFFER_CONS=0
REC_KEEP_CONS=10

#Get Actual Consumer Values at Current Hour From Log File
ACT_DEAD_MAINS_CONS=`grep 'dead-mains' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_DEAD_RESPONSYS_CONS=`grep 'dead-responsys' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_SIFT_EVENT_CONS=`grep 'sift.event.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_SIFT_MONITOR_CONS=`grep 'sift.monitor.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_SIFT_MONIT_REQ_CONS=`grep 'sift.monitor.req.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_SIFT_REG_CONS=`grep 'sift.register.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_APOLLO_PROV_CONS=`grep 'so.apollo.provision.req.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_AUDIT_QUEUE_CONS=`grep 'so.audit.queue' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_EMAIL_RESP_API_CONS=`grep 'so.email-responsys-api-req-in-queue' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_EMAIL_RESP_CONS=`grep 'so.email.responsys.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_FAIL_APOLLO_CONS=`grep 'so.failed-apollo-request-q' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_INT_OFFER_CONS=`grep 'so.interact.offer.req.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_INT_PE_CONS=`grep 'so.interact.postevent.req.in' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_MAINS_SMS_CONS=`grep 'so.mains-sms-req-queue' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_MON_NOOFFER_CONS=`grep 'so.monitored-nooffer-queue' $currHourConsumerCheckFile | awk '{print$4}'`
ACT_REC_KEEP_CONS=`grep 'so.recordkeeper.in' $currHourConsumerCheckFile | awk '{print$4}'`

#Compare Actual and Expected For Not Null Actual Consumer Values

if [ -z "$ACT_DEAD_MAINS_CONS" ]
then
echo "dead-mains Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $DEAD_MAINS_CONS -ne $ACT_DEAD_MAINS_CONS ]
then
echo "Consumer Count of dead-mains Queue is Not Matching Expected Value, Actual:$ACT_DEAD_MAINS_CONS" >> $LOG_FILE
MSG="Consumer Count of dead-mains Queue is Not Matching Expected Value, Actual:$ACT_DEAD_MAINS_CONS"
sendEmailAlert
else
echo "Consumer Count of dead-mains Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_DEAD_RESPONSYS_CONS" ]
then
echo "dead-responsys Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $DEAD_RESPONSYS_CONS -ne $ACT_DEAD_RESPONSYS_CONS ]
then
echo "Consumer Count of dead-responsys Queue is Not Matching Expected Value, Actual:$ACT_DEAD_RESPONSYS_CONS" >> $LOG_FILE
MSG="Consumer Count of dead-responsys Queue is Not Matching Expected Value, Actual:$ACT_DEAD_RESPONSYS_CONS"
sendEmailAlert
else
echo "Consumer Count of dead-responsys Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_SIFT_EVENT_CONS" ]
then
echo "sift.event.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $SIFT_EVENT_CONS -ne $ACT_SIFT_EVENT_CONS ]
then
echo "Consumer Count of sift.event.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_EVENT_CONS" >> $LOG_FILE
MSG="Consumer Count of sift.event.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_EVENT_CONS"
sendEmailAlert
else
echo "Consumer Count of sift.event.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_SIFT_MONITOR_CONS" ]
then
echo "sift.monitor.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $SIFT_MONITOR_CONS -ne $ACT_SIFT_MONITOR_CONS ]
then
echo "Consumer Count of sift.monitor.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_MONITOR_CONS" >> $LOG_FILE
MSG="Consumer Count of sift.monitor.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_MONITOR_CONS"
sendEmailAlert
else
echo "Consumer Count of sift.monitor.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_SIFT_MONIT_REQ_CONS" ]
then
echo "sift.monitor.req.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $SIFT_MONIT_REQ_CONS -ne $ACT_SIFT_MONIT_REQ_CONS ]
then
echo "Consumer Count of sift.monitor.req.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_MONIT_REQ_CONS" >> $LOG_FILE
MSG="Consumer Count of sift.monitor.req.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_MONIT_REQ_CONS"
sendEmailAlert
else
echo "Consumer Count of sift.monitor.req.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_SIFT_REG_CONS" ]
then
echo "sift.register.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $SIFT_REG_CONS -ne $ACT_SIFT_REG_CONS ]
then
echo "Consumer Count of sift.register.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_REG_CONS" >> $LOG_FILE
MSG="Consumer Count of sift.register.in Queue is Not Matching Expected Value, Actual:$ACT_SIFT_REG_CONS"
sendEmailAlert
else
echo "Consumer Count of sift.register.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi


if [ -z "$ACT_APOLLO_PROV_CONS" ]
then
echo "so.apollo.provision.req.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $APOLLO_PROV_CONS -ne $ACT_APOLLO_PROV_CONS ]
then
echo "Consumer Count of so.apollo.provision.req.in Queue is Not Matching Expected Value, Actual:$ACT_APOLLO_PROV_CONS" >> $LOG_FILE
MSG="Consumer Count of so.apollo.provision.req.in Queue is Not Matching Expected Value, Actual:$ACT_APOLLO_PROV_CONS"
sendEmailAlert
else
echo "Consumer Count of so.apollo.provision.req.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_AUDIT_QUEUE_CONS" ]
then
echo "so.audit.queue Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $AUDIT_QUEUE_CONS -ne $ACT_AUDIT_QUEUE_CONS ]
then
echo "Consumer Count of so.audit.queue Queue is Not Matching Expected Value, Actual:$ACT_AUDIT_QUEUE_CONS" >> $LOG_FILE
MSG="Consumer Count of so.audit.queue Queue is Not Matching Expected Value, Actual:$ACT_AUDIT_QUEUE_CONS"
sendEmailAlert
else
echo "Consumer Count of so.audit.queue Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_EMAIL_RESP_API_CONS" ]
then
echo "so.email-responsys-api-req-in-queue Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $EMAIL_RESP_API_CONS -ne $ACT_EMAIL_RESP_API_CONS ]
then
echo "Consumer Count of so.email-responsys-api-req-in-queue Queue is Not Matching Expected Value, Actual:$ACT_EMAIL_RESP_API_CONS" >> $LOG_FILE
MSG="Consumer Count of so.email-responsys-api-req-in-queue Queue is Not Matching Expected Value, Actual:$ACT_EMAIL_RESP_API_CONS"
sendEmailAlert
else
echo "Consumer Count of so.email-responsys-api-req-in-queue Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_EMAIL_RESP_CONS" ]
then
echo "so.email.responsys.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $EMAIL_RESP_CONS -ne $ACT_EMAIL_RESP_CONS ]
then
echo "Consumer Count of so.email.responsys.in Queue is Not Matching Expected Value, Actual:$ACT_EMAIL_RESP_CONS" >> $LOG_FILE
MSG="Consumer Count of so.email.responsys.in Queue is Not Matching Expected Value, Actual:$ACT_EMAIL_RESP_CONS"
sendEmailAlert
else
echo "Consumer Count of so.email.responsys.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_FAIL_APOLLO_CONS" ]
then
echo "so.failed-apollo-request-q Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $FAIL_APOLLO_CONS -ne $ACT_FAIL_APOLLO_CONS ]
then
echo "Consumer Count of so.failed-apollo-request-q Queue is Not Matching Expected Value, Actual:$ACT_FAIL_APOLLO_CONS" >> $LOG_FILE
MSG="Consumer Count of so.failed-apollo-request-q Queue is Not Matching Expected Value, Actual:$ACT_FAIL_APOLLO_CONS"
sendEmailAlert
else
echo "Consumer Count of so.failed-apollo-request-q Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_INT_OFFER_CONS" ]
then
echo "so.interact.offer.req.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $INT_OFFER_CONS -ne $ACT_INT_OFFER_CONS ]
then
echo "Consumer Count of so.interact.offer.req.in Queue is Not Matching Expected Value, Actual:$ACT_INT_OFFER_CONS" >> $LOG_FILE
MSG="Consumer Count of so.interact.offer.req.in Queue is Not Matching Expected Value, Actual:$ACT_INT_OFFER_CONS"
sendEmailAlert
else
echo "Consumer Count of so.interact.offer.req.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_INT_PE_CONS" ]
then
echo "so.interact.postevent.req.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $INT_PE_CONS -ne $ACT_INT_PE_CONS ]
then
echo "Consumer Count of so.interact.postevent.req.in Queue is Not Matching Expected Value, Actual:$ACT_INT_PE_CONS" >> $LOG_FILE
MSG="Consumer Count of so.interact.postevent.req.in Queue is Not Matching Expected Value, Actual:$ACT_INT_PE_CONS"
sendEmailAlert
else
echo "Consumer Count of so.interact.postevent.req.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_MAINS_SMS_CONS" ]
then
echo "so.mains-sms-req-queue Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $MAINS_SMS_CONS -ne $ACT_MAINS_SMS_CONS ]
then
echo "Consumer Count of so.mains-sms-req-queue Queue is Not Matching Expected Value, Actual:$ACT_MAINS_SMS_CONS" >> $LOG_FILE
MSG="Consumer Count of so.mains-sms-req-queue Queue is Not Matching Expected Value, Actual:$ACT_MAINS_SMS_CONS"
sendEmailAlert
else
echo "Consumer Count of so.mains-sms-req-queue Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_MON_NOOFFER_CONS" ]
then
echo "so.monitored-nooffer-queue Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $MON_NOOFFER_CONS -ne $ACT_MON_NOOFFER_CONS ]
then
echo "Consumer Count of so.monitored-nooffer-queue Queue is Not Matching Expected Value, Actual:$ACT_MON_NOOFFER_CONS" >> $LOG_FILE
MSG="Consumer Count of so.monitored-nooffer-queue Queue is Not Matching Expected Value, Actual:$ACT_MON_NOOFFER_CONS"
sendEmailAlert
else
echo "Consumer Count of so.monitored-nooffer-queue Queue is Matching Expected Value" >> $LOG_FILE
fi
fi

if [ -z "$ACT_REC_KEEP_CONS" ]
then
echo "so.recordkeeper.in Queue Not Present in This Hours ActiveMQ Stats Logs" >> $LOG_FILE
else
if [ $REC_KEEP_CONS -ne $ACT_REC_KEEP_CONS ]
then
echo "Consumer Count of so.recordkeeper.in Queue is Not Matching Expected Value, Actual:$ACT_REC_KEEP_CONS" >> $LOG_FILE
MSG="Consumer Count of so.recordkeeper.in Queue is Not Matching Expected Value, Actual:$ACT_REC_KEEP_CONS"
sendEmailAlert
else
echo "Consumer Count of so.recordkeeper.in Queue is Matching Expected Value" >> $LOG_FILE
fi
fi



