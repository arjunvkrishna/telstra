#####################################################################
#####################################################################
# Script name: getEMAILCountsResponsys.sh
# Description:
# Date       : 30-Mar-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

#Variables
OutputFlowIDPath="/home/siftuser/PSNM_Scripts/flowIDS_Responsys"
OutputCountsPath="/home/siftuser/PSNM_Scripts/Output_ResponsysCounts"
SO1_hostname="lxapp9606"
SO2_hostname="lxapp9607"
donePath="/data/knowesis/unica/uc-in/done/"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo "usage: sh getEMAILCountsResponsys.sh [<DD-Mmm-YYYY>]"
    echo "This script generates a CSV report containing the Email counts for all the"
    echo "events as listed in the input file."
    echo "Date is optional. Format is DD-Mmm-YYYY (`date +%d-%b-%Y`)"
    exit
}

#####################################################################
# Function   : prepareBatchEventList
# Description: Displays the usage of the script
#####################################################################
function prepareBatchEventList ()
{
   cd $donePath
   cat *-$rundate* | awk -F"," '{print $4}' | grep "MBB" | grep -v "Event_Id" | sort -u > $InputFile
   # Copy to SO2 as well - Future Functionality
   scp $InputFile sifuser@$SO2_hostname:/home/siftuser/PSNM_Scripts/
}

#####################################################################
# Function   : set_ValidateParams
# Description: 
#####################################################################
function set_ValidateParams()
{
    #If no arguement has passed, this script will run for current day
    if [ $# -eq 0 ] ;then
        runDate=$(date +"%d-%b-%Y")
        echo "No Date Supplied So counting the files for today i.e., "$runDate
    else
        runDate=$(date -d "$1" +"%d-%b-%Y")
        if [[ -z "$runDate" ]];   then
             echo "Please supply the date in DD-Mmm-YYYY Format i.e.,"$(date +"%d-%b-%Y")
             exit
        fi
        echo "Date Supplied is "$runDate
    fi
	
	fileDate=`date -d "$runDate" +%F`
	
    if [ ! -d $OutputFlowIDPath ]; then
        mkdir -p $OutputFlowIDPath
    fi
    
    if [ ! -d $OutputCountsPath ]; then
        mkdir -p $OutputCountsPath
    fi

    if [ `uname -n` = "$SO1_hostname" ]; then
        logFilePaths="/opt/knowesis/sift/orchestrator/so-telstra/log/archive /opt/knowesis/sift/orchestrator/so-batch-telstra/log/archive"
        logFile="so-responsyshandler.log-$fileDate*"
        transactionType="RealTime"
		FileNameSuffix="S01"
        InputFile="/home/siftuser/PSNM_Scripts/SO1_"$transactionType"_EventIds_List_Responsys.txt"
        OutputEmailFile="$OutputCountsPath/ResponsysCounts_"$FileNameSuffix"_"$transactionType"_"$runDate".csv"
        #prepareBatchEventList
    fi
    
    if [ `uname -n` = "$SO2_hostname" ]; then
        logFilePaths="/opt/knowesis/sift/orchestrator/so-telstra/log/archive /opt/knowesis/sift/orchestrator/so-batch-telstra/log/archive"
        logFile="so-responsyshandler.log-$fileDate*"
        transactionType="RealTime"
		FileNameSuffix="S02"
   #     InputFile="SO2_RealTime_EventIds_List_Responsys.Test.txt"
         InputFile="/home/siftuser/PSNM_Scripts/SO2_"$transactionType"_EventIds_List_Responsys.txt"
         OutputEmailFile="$OutputCountsPath/ResponsysCounts_"$FileNameSuffix"_"$transactionType"_"$runDate".csv"
    fi
    
    if [ -f $OutputEmailFile ] ;then
        rm $OutputEmailFile
    fi

    # If condition to check for the Event Ids File Existance
    if [ ! -f "$InputFile" ]; then
        echo "Event File Not Found, Please create a Event File "$InputFile" and add the event names for which you wanto to generate the stats"
       exit
    fi
}

#####################################################################
# Function   : extract_flowIds
# Description: 
#####################################################################
function extract_flowIds()
{

tempFile1="$OutputFlowIDPath/tempFile1.csv"
    cd $dir
    logDate=`date -d "$runDate" "+%m/%d/%y"`
	logDatePattern="\[$logDate"
    
    # Search Query to find out the flowID
    searchString="EventId:"$i""
 #   if [ $transactionType = "RealTime" ]; then
         grep -r "$logDatePattern" --include="$logFile" --exclude-dir={audit,*/audit} . | grep ','$searchString',' | grep "Responsys Mail Request Added in the Bath" \
        | awk -F"," '{print $2,"," $3,","$4,",",$5}' > $tempFile1
 #   fi
    
 #   if [ $transactionType = "Batch" ]; then
 #       grep -r "$logDatePattern" --include="$logFile" --exclude-dir={audit,*/audit} . | grep ','$searchString',' | grep "Responsys Response -" \
 #       | awk -F"}" '{print $2,$3}' | awk -F"," '{print $21,$18,$10,$6,$23,$24,$35}' > $OutputFlowIDFile
 #   fi
    
    cat $tempFile1 >> $OutputFlowIDFile
    retval=$(cat $tempFile1 | sort -u |  wc -l)
    #sucess_count=$(cat $OutputFlowIDFile | sort -u | grep '"success":true' | wc -l)
    #failure_count=$(cat $OutputFlowIDFile | sort -u | grep '"success":false' | wc -l)
rm -f $tempFile1
}


#####################################################################
# Function   : sendFilesSFTP
# Description: This function does the following
#              -> transfers the files to lxfile 0023
# Input Args : None
#####################################################################
function sendFilesSFTP ()
{
    AthenianFileServer="lxfile0023.in.telstra.com.au"
    AthenianUserId="n100417"
    AthenianPath="/Athenian/Sift/reporting/BAU_reporting"
    scp -p $OutputEmailFile $AthenianUserId@$AthenianFileServer:$AthenianPath
    scp_status=`echo $?`
    if [ $scp_status -ne 0 ]
    then
        echo "Failed to TRANSFER the file `basename $OutputEmailFile` to Athenian file Server" 
        exit 1
    fi
 
    echo "Sucessfully transferred the files `basename $OutputEmailFile` to Athenian file server" 
    exit 0
}

#####################################################################
# Function   : main
# Description: 
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" ]; then
    usage
    exit 0
fi

# Set paramaters - file locations and paths and validate the input arguments
set_ValidateParams $1

# For loop to run recursively for all the events in the input file 
for i in `cat $InputFile`
do
    OutputFlowIDFile="$OutputFlowIDPath/"$i"_"$runDate"_Responsys_FlowIds.csv"
    # If loop is to check for the same output file exists,if exists it will remove and creates a new one
    if [ -f $OutputFlowIDFile ] ;then
      rm $OutputFlowIDFile
    fi
ResponsysCounts=0
	for dir in $logFilePaths;
	do
    extract_flowIds $runDate $i $dir $OutputFlowIDFile
	ResponsysCounts=$((ResponsysCounts+retval))
	done
    echo $i","$ResponsysCounts >> $OutputEmailFile
done

sendFilesSFTP

# Extract counts for batch messages also which might land up on SO2  - Future Functionality
#if [ `uname -n` = "$SO2_hostname" ]; then
#    InputFile="/home/siftuser/PSNM_Scripts/SO1_Batch_EventIds_List_Mains.txt"
#    transactionType="Batch"
#    OutputSMSFile="$OutputCountsPath/MainsCounts_"$transactionType"_"$runDate".csv"
#    for i in `cat $InputFile`
#    do
#        extract_flowIds $runDate $i
#    done
#fi


