#####################################################################
#####################################################################
# Script name: restartInteractHandler.sh
# Description: This script identifies if there are any Pending messages
#              in the SO Interact handlers and will restart the handlers
# Date       : 15-Apr-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

#!/bin/bash

# Variable and parameters
PendingRestartLogFile="/home/siftuser/PSNM_Scripts/HealthCheck/restartLog.`date +%F`.log"
QueueLogFile="/home/siftuser/PSNM_Scripts/HealthCheck/ActiveMqQueueLog.`date +%F`.log"
interactQueue="so.interact.*.req.in"
interactHandler_pid="/opt/knowesis/sift/orchestrator/bin/sift-unica-interact-handler.pid"
statusScript="/opt/knowesis/sift/orchestrator/bin/checkInteractHandler.sh"
stopScript="/opt/knowesis/sift/orchestrator/bin/stopInteractHandler.sh"
startScript="/opt/knowesis/sift/orchestrator/bin/startInteractHandler.sh"
activemqPath="/opt/knowesis/sift/orchestrator/apache-activemq-5.11.1/bin"


#####################################################################
# Function    : usage
# Description : 
#####################################################################
function usage ()
{
    echo "usage: sh restartInteractHandler.sh"
    echo "This script identifies if there are any Pending messages"
    echo "in the SO Interact handler and will restart the handler"
    exit
}

#####################################################################
# Function    : stopHandler
# Description : This function stops the Interact handler.
#               First it tries to gracefull stop the process using the
#               stop scripts and after 5 attemps if the process is still
#               running, then it will kill it
#####################################################################

function stopHandler ()
{
    # Try to stop the handler gracefully using the stop script
    for (( count=1; count<=5; count++ ))
    do 
        cd /opt/knowesis/sift/orchestrator/bin/
        interacthandler_status=$(sh $statusScript | wc -l)
        if [ "$interacthandler_status" = 2 ]; then
            processRunning="TRUE"
            sh $stopScript
            sleep 20
        else
            echo "`date '+%F %T'` | INFO | Stopped process using script - PID:`cat $interactHandler_pid`"  | tee -a $PendingRestartLogFile
            processRunning="FALSE"
            break
        fi
    done
    
    # If process does not stop after few attempts, kill it forcibly
    if [ "$processRunning" = "TRUE" ]; then
        #Process is still running , kill it manually
        kill -9 `cat $interactHandler_pid`
        interacthandler_status=$(sh $statusScript | wc -l)
        if [ "$interacthandler_status" = 1 ]; then
            echo "`date '+%F %T'` | INFO | Killed process forcibly - PID:`cat $interactHandler_pid`" | tee -a $PendingRestartLogFile
        fi
    fi
}

#####################################################################
# Function    : startHandler
# Description : This function starts the interact handler
#               It runs the start script in the background
#####################################################################
function startHandler ()
{
    nohup sh $startScript > Output.out 2> Error.err < /dev/null &
    sleep 5
    interacthandler_status=$(sh checkInteractHandler.sh | wc -l)
    if [ "$interacthandler_status" = 2 ]; then
        echo "`date '+%F %T'` | INFO | Process restarted successfully - PID:`cat $interactHandler_pid`" | tee -a $PendingRestartLogFile
    fi
}

#####################################################################
# Function    : checkStatus
# Description : This function checks the status of the pending messages
#               in the Interact queue after the restart
#####################################################################
function checkStatus ()
{ 
    cd $activemqPath
    for (( loop=1; loop<=3; loop++ ))
    do 
        echo "`date '+%F %T'` | INFO | Status After restart" | tee -a $PendingRestartLogFile
       ./activemq dstat queues | grep $interactQueue >> $PendingRestartLogFile
        sleep 120
    done
}

#####################################################################
# Function    : identifyPendingMsgs
# Description : This function identifies pending messages in the interact
#               queue based on the output of activemqMonitor
#####################################################################
function identifyPendingMsgs ()
{
    pattern="`date +%H`:00"
    start_line=`awk "/$pattern/ {print NR}" $QueueLogFile | head -1`
    end_line=`awk "/$pattern/ {print NR}" $QueueLogFile | tail -1`
    echo "==========================================================" | tee -a $PendingRestartLogFile
    echo "`date '+%F %T'` | INFO | Pending messages Status" | tee -a $PendingRestartLogFile
    sed -n "$start_line","$end_line"p $QueueLogFile | grep "$interactQueue" 

    if [ $? -eq 0 ]; then
        sed -n "$start_line","$end_line"p $QueueLogFile | grep "$interactQueue"  >> $PendingRestartLogFile
        echo "`date '+%F %T'` | WARN | Pending messages found in Interact queues" | tee -a $PendingRestartLogFile
        stopHandler
        startHandler
        checkStatus
        echo "==========================================================" | tee -a $PendingRestartLogFile
    else
        echo "`date '+%F %T'` | INFO | No Pending messages found, no restart required" | tee -a $PendingRestartLogFile
        echo "==========================================================" | tee -a $PendingRestartLogFile
    fi
    exit
}

#####################################################################
#main
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" -o $# -gt 0 ]
then
    usage
    exit 0
fi

identifyPendingMsgs


