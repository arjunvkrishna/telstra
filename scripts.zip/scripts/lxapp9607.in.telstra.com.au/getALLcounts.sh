#####################################################################
#####################################################################
# Script name: getALLcounts.sh
# Description: 
# Date       : 20-May-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

#!/bin/sh

#Variables
OutputALLcountsPath="/home/siftuser/PSNM_Scripts/Output_ALLCounts"
logFilePath="/opt/knowesis/sift/orchestrator/logs/"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
# Input Args : None
#####################################################################
function usage ()
{
    echo "usage: sh getALLcounts.sh [<DD-Mmm-YYYY>]"
    echo "where:"
    echo -e "\tDate is optional. If no date is given, it runs for current date. Format is DD-Mmm-YYYY (`date +%d-%b-%Y`)"
    echo ""
    echo -e "\tThis script gets the counts across all the systems for all"
    echo -e "\tthe non-bestowal events as mentioned in the input file"
    echo -e "\tfrom all the logs for the mentioned date." 
    echo -e "\tThe counts extracted are Interact request, Interact Response, Contact, Control group "
    echo -e "\tNo Offer and SMS/Responsys counts"
    exit
}

#####################################################################
# Function   : set_ValidateParams
# Description: This function will set and validate required params
#              -> set the date if passed on
#              -> creates output directories, if not present
#              -> set the log files, input files names and path
#              -> checks if the input file exists or not
# Input Args : Run date passed on as DD-mmm-YYYY
#####################################################################
function set_ValidateParams()
{
    if [ $# -eq 1 ]; then
        runDate=$(date -d "$1" +"%d-%b-%Y")
        if [[ -z "$runDate" ]];   then
             echo "Please supply the date in DD-Mmm-YYYY Format i.e.,"$(date +"%d-%b-%Y")
             exit
        fi
        echo "Date Supplied is "$runDate
    else
        runDate=$(date +"%d-%b-%Y")
        echo "No Date Supplied So counting the files for today i.e., "$runDate
    fi

    #Log file names
    fileDate=`date -d "$runDate" +%F`
    InteractLogFile="sift-interact-handler.log.$fileDate*"
    ApolloLogFile="sift-apollo-handler.log.$fileDate*"
    MainsLogFile="sift-mains-handler.log.$fileDate*"
    ResponsysLogFile="sift-responsys-handler.log.$fileDate*"

    InputFile="/home/siftuser/PSNM_Scripts/EventIds_List_ALLcounts.txt"
    OutputALLcountsFile="$OutputALLcountsPath/ALLCounts_$runDate.csv"
    
    # If condition to check for the Event Ids File Existance
    if [ ! -f "$InputFile" ]; then
        echo "Event File Not Found, Please create a Event File "$InputFile" and add the event names for which you want to generate the details"
        exit
    fi

    if [ ! -d $OutputALLcountsPath ]; then
        mkdir -p $OutputALLcountsPath
    fi
    
    # If loop is to check for the same output file exists,if exists it will remove
    if [ -f $OutputALLcountsFile ]; then
        rm $OutputALLcountsFile
    fi

    # Write Header
    echo "Event ID","Interact Request Counts","Interact Response Counts","Interact ContactGroup","Interact ControlGroup","Interact NoOffer","Mains/Responsys Counts" >> $OutputALLcountsFile
}

#####################################################################
# Function   : extract_ALLcounts
# Description: This function does the following
#              -> extracts the counts for Interact requests, Interact
#                 responses, Control group, Contact group, No Offer,
#                 Mains/Responsys counts from corresponding log files
# Input Args : runDate and Event ID
#####################################################################
function extract_ALLcounts()
{
    tempInteractResponse="$OutputALLcountsPath/"$runDate"_tempInteractResponse.csv"
    # delete if temp files exists
    if [ -f $tempInteractResponse ]; then
        rm $tempInteractResponse
    fi
    
    cd $logFilePath
    
    # Search patterns to find out the details and dump the output in temp files
    InteractRequestCounts=`LC_ALL=C grep -r "$runDate" $InteractLogFile | grep '"MULTI_EVENT_ID":"' | grep -w $i | grep "BatchMessageProcessor" | grep 'INFO' | grep 'Incoming Msg' | awk -F'"MULTI_EVENT_ID"' '{print $2}' |  awk -F"," '{print $1,$NF}' | grep $i | sort -u | wc -l`

    searchString="\"EventId\":\"$i\""
    LC_ALL=C grep -r "$runDate" $InteractLogFile | grep ','$searchString','  | grep 'Original Msg in PostEvent'|  grep 'INFO' | awk -F'\"OfferType\"' '{print $2}' | awk -F"," '{print $1,$2}'| sort -u > $tempInteractResponse
    
    searchString="EventId=$i"     
    LC_ALL=C grep -r "$runDate" $InteractLogFile | grep 'EventId=' | grep -w $i | grep 'InteractResponseRoute' | grep 'No Offer'|  grep 'INFO' | awk -F"ServiceId=" '{print $2}' | sort -u  | awk -F"," '{print ",",$4,",",$1}'  >> $tempInteractResponse

    InteractResponseCounts=`wc -l $tempInteractResponse | awk '{print $1}'`
    InteractContactGroupCounts=`LC_ALL=C grep "Contact" $tempInteractResponse | wc -l  | awk '{print $1}'`
    InteractControlGroupCounts=`LC_ALL=C grep "Control" $tempInteractResponse | wc -l  | awk '{print $1}'`
    InteractNoOfferCounts=`LC_ALL=C grep -v "Control" $tempInteractResponse | grep -v "Contact" | wc -l  | awk '{print $1}'`

    if [ $ServiceType = "HH" ]; then
        searchString="EventId:$i"
        MainsResponseCounts=`LC_ALL=C grep -r "$runDate" $MainsLogFile | grep ','$searchString',' | grep 'MAINS Request Successfuly Completed' | grep 'INFO' | awk -F"," '{print $3",",$4}' | sort -u | wc -l`
        
        # Print the counts 
        echo "$i","$InteractRequestCounts","$InteractResponseCounts","$InteractContactGroupCounts","$InteractControlGroupCounts","$InteractNoOfferCounts","$MainsResponseCounts" >> $OutputALLcountsFile
    elif [ $ServiceType = "MBB" ]; then
        searchString="EventId:"$i""
        ResponsysResponseCounts=`LC_ALL=C grep -r "$runDate" $ResponsysLogFile | grep ','$searchString','  | grep 'INFO' | grep 'Responsys Mail Request Added in the Bath' | awk -F"," '{print $3}'  |  sort -u | wc -l`  

        # Print the counts 
        echo "$i","$InteractRequestCounts","$InteractResponseCounts","$InteractContactGroupCounts","$InteractControlGroupCounts","$InteractNoOfferCounts","$ResponsysResponseCounts" >> $OutputALLcountsFile
    fi

    # delete if temp files exists
    if [ -f $tempInteractResponse ]; then
        rm $tempInteractResponse
    fi

}

#####################################################################
# Function   : main
# Description: 
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" -o $# -lt 1 -o $# -gt 2 ]
then
    usage
    exit 0
fi

# Set paramaters - file locations and paths and validate the input arguments
set_ValidateParams $1 $2

# For loop to run recursively for all the events in the input file 
for i in `cat $InputFile`
do
    echo $i | grep "HH" > /dev/null
    if [ $? -eq 0 ]; then
        ServiceType="HH"
    fi

    echo $i | grep "MBB" > /dev/null
    if [ $? -eq 0 ]; then
        ServiceType="MBB"
    fi

    extract_ALLcounts $runDate $i
done


