#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts
ARCHIVE_PATH=/data/ARCHIVE/BAR/2018-06-09/2018060913
SCRIPT_LOG=/home/siftuser/PSNM_Scripts/BARCOMP_FILENAMECHECK_`date +%Y%m%d`.log

cd $ARCHIVE_PATH
echo "`date '+%F %T'` | INFO |  Started" >> $SCRIPT_LOG
for FileType in `cat /home/siftuser/PSNM_Scripts/InputMSIDNS090618.txt`
do
find -name \*.gz -print0 | xargs -0 zgrep "$FileType" >> $SCRIPT_LOG
done
echo "`date '+%F %T'` | INFO |  Completed" >> $SCRIPT_LOG
