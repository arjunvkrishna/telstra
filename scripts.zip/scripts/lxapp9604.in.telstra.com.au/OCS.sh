#!/bin/sh

echo "======================================================================="
echo "OCS File Check has started at" $(date "+%b %d %Y %H:%M:%S")

CURRENT_DATE=$(date +%Y-%m-%d --date="1 hour ago")
HOUR_AGO_DATE=$(date +%Y%m%d%H --date="1 hour ago")
WORKING_DATE=$(date "+%d %b %Y %I %p" --date="1 hour ago")

# initialise array placeholder
FILE_MISSING=()
FILE_STATUS=()

echo "Checking files received at [$WORKING_DATE]"

# iterate all the OCS folders
for item in UDR MER BAR OLDR
do
	NAME_OUTPUT=$([ "$item" = "OLDR" ] && echo "LDR" || echo "$item")
	NAME_PATTERN="ocs_${NAME_OUTPUT,,}_*${HOUR_AGO_DATE}*"
	
	PROCESSED_PATH="/data/PROCESSED/$item/$CURRENT_DATE"
	PROCESSED_COUNT=$(ls 2>/dev/null $PROCESSED_PATH/$NAME_PATTERN | wc -l)

	ARCHIVE_PATH="/data/ARCHIVE/$item/$CURRENT_DATE"
	ARCHIVE_COUNT=$(ls 2>/dev/null $ARCHIVE_PATH/*/$NAME_PATTERN | wc -l)

	FILE_COUNT=$(expr $PROCESSED_COUNT + $ARCHIVE_COUNT)
	FILE_STATUS+=("$NAME_OUTPUT [$FILE_COUNT]")

	if [ "$FILE_COUNT" -eq 0 ]
	then
		FILE_MISSING+=("$NAME_OUTPUT")
	fi
done

echo "File Check Status: ${FILE_STATUS[*]}"

# send an alert notification if there are missing files
if [ "${#FILE_MISSING[*]}" -gt 0 ] 
then
	MAIL_RECIPIENT="TelstraSalesForcePersonalisationCloudsupport@team.telstra.com,Twinku.Thomas@team.telstra.com,sonal.winston@infosys.com,mohammedsuhayab.r@infosys.com,anjana.ramachandran@infosys.com,akshai.saju@infosys.com"
	MAIL_SUBJECT="[OPOLO] OCS File Check [ALERT!!]"
	MAIL_CONTENT="OCS Files [${FILE_MISSING[*]}] not received on $WORKING_DATE. Kindly check!"
	
	echo "$MAIL_CONTENT" | mailx -s "$MAIL_SUBJECT" -S smtp=mail.in.telstra.com.au "$MAIL_RECIPIENT"
	echo "$MAIL_CONTENT" >> OCS.log
        echo "Alert notification sent. OCS files [${FILE_MISSING[*]}] were not received."
fi

echo "OCS File Check has completed"
echo "======================================================================="
