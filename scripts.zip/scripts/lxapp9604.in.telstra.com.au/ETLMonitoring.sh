#####################################################################
#####################################################################
# Script name: ETLMonitoring.sh
# Description: This script monitors the ETL file arrival and also 
#              gathers the status of ETL file completion every hour
# Date       : 3-Mar-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

# Variables and Parameters
ETLPath="/data/ingest/PROFILE/"
ETLProcessingPath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/BATCH_TRIGGER/"
ETLCompletedPath="/data/PROCESSED/PROFILE/`date +%F`"
ETLFileNamePattern="SIFT_SERVICE_PROFILE_*.txt"
ETLFilePatternEOT="SIFT_SERVICE_PROFILE.eot"
ETLLogfile="/home/siftuser/PSNM_Scripts/HealthCheck/ETLStats_new.`date +%F`"
ETLtempfile="/home/siftuser/PSNM_Scripts/HealthCheck/ETLCount.txt"
ETLCutoffHour=18
ETLfileExists=FALSE
LogFile="/home/siftuser/PSNM_Scripts/HealthCheck/ETLStats_new.`date +%F`"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo "Usage: sh ETLMonitoring.sh"
    echo "This script is scheduled from Cron and runs every hour to"
    echo "track the status of ETL processing"
}


#####################################################################
# Function    : sendEmailAlert
# Description : 
#
#
#####################################################################


function sendEmailAlert ()
{
    hostname=`uname -n`
    emailSubject="SIFT EMAIL ALERT "\!\!\!" $hostname SERVER -SIFT ETL STATUS - `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'bhuvan.siddaramu@infosys.com' 'Saikrishna_Doli@infosys.com' 'Shiju_R@infosys.com' 'Manoj_Kumar51@infosys.com')
    cat $LogFile |tail -1| mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
   
}

#####################################################################
# Function    : checkFileArrival
# Description :
#####################################################################
function checkFileArrival ()
{
    fileCount=0
    # Check if the files have arrived or not based on the EOT file
    # Log a warning if file does not arrive  
    cd $ETLPath

    ls -l $ETLFileNamePattern > /dev/null 2>&1;
    if [ "$?" = "0" ] && [ -f $ETLFilePatternEOT ]; then
        arrivalTimestamp=`ls -l $ETLFilePatternEOT | tail -1 | awk '{print $6,$7,$8}'`
        echo "`date '+%F %T'` | INFO | ETL files have arrived on  $arrivalTimestamp" >> $ETLLogfile
        fileCount=`ls -l $ETLFileNamePattern | tail -1 | awk  '{print $9}' | cut -d "_" -f4 | sed 's/^0*//'`
        LastFileName=`ls -l $ETLFileNamePattern | tail -1 | awk  '{print $9}'`
        echo "`date '+%F %T'` | INFO | Total files recieved are $fileCount" >> $ETLLogfile
        echo "$fileCount" > $ETLtempfile
        ETLfileExists=TRUE
    fi

    if [ -f $ETLLogfile ]; then
        filesArrived=`grep "ETL files have arrived" $ETLLogfile | wc -l`
        if [ $filesArrived -gt 1 ]; then
            ETLfileExists=TRUE
            echo $ETLfileExists
        fi
    fi

    if [ "$ETLfileExists"  = "FALSE" ]; then
        echo "`date '+%F %T'` | WARN | ETL files have not yet arrived" >> $ETLLogfile
		sendEmailAlert
        while [ `date '+%M'` -lt 45 ]
        do
            sleep 300
        done
    fi   

    # ETL completion
    ls -ltr $ETLPath/$ETLFileNamePattern > /dev/null 2>&1
    fileExists_Input=$?
    ls -ltr $ETLProcessingPath/$ETLFileNamePattern > /dev/null 2>&1
    fileExists_Processing=$?
    ls -ltr $ETLCompletedPath/$LastFileName > /dev/null 2>&1
    fileExistsCompleted=$?
    ls -R $ETLCompletedPath | grep $LastFileName > /dev/null 2>&1
    fileExistsArchive=$?
    if [[ $fileExists_Input -eq 1 ]] && [[ $fileExists_Processing -eq 1 ]] && [[ fileExistsCompleted -eq 0  || $fileExistsArchive -eq 0 ]]
	then
        echo "`date '+%F %T'` | INFO | ETL file processing completed" >> $ETLLogfile
         sendEmailAlert 
    fi 
}

#####################################################################
# Function    : trackStatus
# Description :
#####################################################################
function trackStatus ()
{
    fileCount_Ready=0
    fileCount_Processing=0
    fileCount_Done=0
    fileTotalCount=`cat $ETLtempfile`
   
    cd $ETLPath
    fileCount_Ready=`ls -l $ETLFileNamePattern | wc -l`
    cd $ETLProcessingPath

    ls -ltr $ETLPath/$ETLFileNamePattern > /dev/null 2>&1
    fileExists_Input=$?
    ls -ltr $ETLProcessingPath/$ETLFileNamePattern > /dev/null 2>&1
    fileExists_Processing=$?
	
    if [ $fileExists_Processing -eq 0 ] || [ $fileExists_Input -eq 0 ] ; then
        echo "File present in processing dir"
        fileCount_Processing=`ls -l $ETLFileNamePattern | wc -l`
        fileCount_Done=`echo $(($((fileTotalCount)) - $((fileCount_Ready + fileCount_Processing))))`
        echo "============================================================" >> $ETLLogfile 
        echo "`date '+%F %T'` | INFO | Status as below" >> $ETLLogfile
        echo "No. of files waiting to be processed : $fileCount_Ready" >> $ETLLogfile
        echo "No. of files in progress : $fileCount_Processing" >> $ETLLogfile
        echo "No. of files processed : $fileCount_Done" >> $ETLLogfile
        echo "============================================================" >> $ETLLogfile 

        if [ `date +%H` -eq $ETLCutoffHour ]  &&  [ $fileCount_Done -ne $fileTotalCount ]; then
            echo "`date '+%F %T'` | WARN | ETL file processing is still going on" >> $ETLLogfile 
		sendEmailAlert
        fi
    else    
        ETLCompletedLog=`grep "ETL file processing completed" $ETLLogfile | wc -l`
        if [ $ETLCompletedLog -lt 1 ]; then
             echo "`date '+%F %T'` | INFO | ETL file processing completed" >> $ETLLogfile 
		sendEmailAlert
			 
        fi        
    fi

    exit 0
}

#####################################################################
#main
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" -o $# -ne 0 ]
then
    usage
    exit 0
fi

if [ "$ETLfileExists" = "FALSE" ]; then
   checkFileArrival 
fi

if [ "$ETLfileExists" = "TRUE" ]; then
    trackStatus
fi
