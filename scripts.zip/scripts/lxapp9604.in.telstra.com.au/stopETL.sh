PID=`ps -ef|grep -i SiftETL.jar|grep -v 'grep' |awk '{print $2}'`
if [ ${#PID} -ne 0 ]
then
kill $PID
echo "ETL utility stopped !!"
exit
fi
echo "ETL utility not running !!"

