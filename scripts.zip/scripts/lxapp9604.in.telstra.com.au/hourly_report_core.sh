
dt=$(date +"%Y%m%d%H")
OUTPUT=/home/siftuser/kw_utils/hourly_report_core_$dt.log
{
shopt -s expand_aliases
source /home/siftuser/.bashrc

#Jobs Status
/opt/knowesis/sift/core/sift/scripts/sift_native lsjobs;
/opt/knowesis/sift/core/sift/scripts/sift_native descjobs;
#CPU_Memory
date;
echo "SiftCore1"
top -n1b|head ;free -g
echo "Sift Core 2"
ssh lxapp9605 'top -n1b|head ;free -g'
echo "Sift Core 3"
ssh 10.116.255.5 'top -n1b|head ;free -g'
echo "SiftCore 4"
ssh 10.116.255.6 'top -n1b|head;free -g'

#Inout DIR
echo "Input DIR lag"
cd /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input
ls UDR|wc -l;ls MER|wc -l;ls BAR|wc -l;ls LDR|wc -l;ls LDR|wc -l;ls BTR|wc -l;ls BATCH_TRIGGER|wc -l;

#Panda Lag
echo "Panda Lag"
ssh lxapp9606 'sh /home/siftuser/kcommands/pandalagstotal.sh'
}>>$OUTPUT
