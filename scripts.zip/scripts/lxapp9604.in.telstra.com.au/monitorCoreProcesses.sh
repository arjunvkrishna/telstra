#!/bin/bash

SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts/
source ${SCRIPTS_PATH}/envSift.sh
persistAddress=${PERSIST_ADDRESS}
TMP_ALL_PROCESSES_FILE=/tmp/allcoreprocesses.tmp
UNIQUE_CORE_HOSTS=/tmp/alluniquecorehosts.tmp
PANDA_PROCESSES=com.knowesis.sift.core.operators.PandaSourceFactory

registryObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} Registry 2> /dev/null |awk -F"_____" '{print $2}'`

echo ${registryObj} > ${TMP_ALL_PROCESSES_FILE}
sed -i 's/,/\n/g' ${TMP_ALL_PROCESSES_FILE}

cat ${TMP_ALL_PROCESSES_FILE} | awk -F'_' '{print $1}' | sort -u > ${UNIQUE_CORE_HOSTS}

GREP_STATEMENT=" | grep -v grep"
for i in `cat ${UNIQUE_CORE_HOSTS}`
do 
	echo $i
	GREPS=`grep $i ${TMP_ALL_PROCESSES_FILE} | awk -F'_' '{print $2}'`
	for prcs in ${GREPS}
	do
		 GREP_STATEMENT="${GREP_STATEMENT} | grep -v ${prcs}"
	done
	
	THIS_HOST_PROCESS=`ssh ${i} "ps -ef | grep ${PANDA_PROCESSES} ${GREP_STATEMENT}" | awk '{print $2}'`
	for prs in ${THIS_HOST_PROCESS}
	do
		ssh ${i} "kill -9 ${prs}"
	done
	GREP_STATEMENT=" | grep -v grep"
done
