#!/bin/bash

exec >>  /opt/knowesis/sift/orchestrator/test/TestScript/logs/balanceAndServiceSnapshotDatapull_`date +%F`.log
echo "==================================================================="
echo "Starting to pull Balance and Service Snapshot Files at `date`"
SOURCE_USER_ID=n104283
SOURCE_IP=lxapp0019.in.telstra.com.au
SOURCE_FILE_DIRECTORY=/u01/EDW/src/np2/data/CSA/sit2.3/ent/outbound/send/p01/dataout/dsf/sift
SIFT_INPUT_FILE_ARCHIVE_DIRECTORY=/data/archive
SIFT_INPUT_FILE_DIRECTORY=/data/ingest/BUNDLE_SNAPSHOT
#This directory only used for zip the .dat and .ctl for Archive folder
SIFT_INPUT_FILE_TEMP_DIRECTORY=/opt/knowesis/sift/orchestrator/test/TestScript/temp
SIFT_INPUT_CHECK_PULLING_DIRECTORY=/opt/knowesis/sift/orchestrator/test/TestScript

if [ -f $SIFT_INPUT_CHECK_PULLING_DIRECTORY/balanceAndServiceSnapshotDatapull.ctl ]
then
        echo "Balance and Service Snapshot Pull already in progress."
        exit
else
        touch $SIFT_INPUT_CHECK_PULLING_DIRECTORY/balanceAndServiceSnapshotDatapull.ctl

fileDate=`date "+%Y%m%d"`
fileDate='20170622'

sevCount=$(echo ls -l | sftp "${SOURCE_USER_ID}@${SOURCE_IP}:$SOURCE_FILE_DIRECTORY" |grep -i "_cmpsevraw_"$fileDate"_" | grep -i ".eot" | wc -l)

balCount=$(echo ls -l | sftp "${SOURCE_USER_ID}@${SOURCE_IP}:$SOURCE_FILE_DIRECTORY" |grep -i "_cmpbalraw_"$fileDate"_" | grep -i ".eot" | wc -l)
#..................Service snapshot file fetching start...........................

if [ ${sevCount} -gt 0 ]
then

	fileListCleaned=$(echo ls -l | sftp "${SOURCE_USER_ID}@${SOURCE_IP}:$SOURCE_FILE_DIRECTORY" |grep -i "_cmpsevraw_"$fileDate"_")
	for file in `echo $fileListCleaned`
	do
		if [ `echo ${file} | grep ".dat"` ]
                then
                	echo "Coping the Service Snapshot file with .dat extension is $file"
			exactFileName=`echo ${file}|awk -F'/' '{print $NF}'`
			sftp -oBatchMode=no -b - ${SOURCE_USER_ID}@${SOURCE_IP} <<-!
			cd $SOURCE_FILE_DIRECTORY
			get ${file} ${SIFT_INPUT_FILE_TEMP_DIRECTORY}
			!
			tar cfz ${SIFT_INPUT_FILE_ARCHIVE_DIRECTORY}"/"${file}".tar.gz" -P ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file}
        		rm -rf ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file}
		elif [ `echo ${file} | grep ".ctl"` ]
                then
                        echo "Coping the Service Snapshot file with .ctl extension is $file" 
			exactFileName=`echo ${file}|awk -F'/' '{print $NF}'`
			sftp -oBatchMode=no -b - ${SOURCE_USER_ID}@${SOURCE_IP} <<-!
			cd $SOURCE_FILE_DIRECTORY
			get ${file} ${SIFT_INPUT_FILE_TEMP_DIRECTORY}
			!
        		tar cfz ${SIFT_INPUT_FILE_ARCHIVE_DIRECTORY}"/"${file}".tar.gz" -P ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file}
        		rm -rf ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file}
		fi
	done
else
echo "Service Snapshot file with .eot extension in the date $fileDate is not present."
fi
#..................Service snapshot file fetching end...........................

#..................Balance snapshot file fetching start...........................

if [ ${balCount} -gt 0 ]
then
	

	fileListCleaned=$(echo ls -l | sftp "${SOURCE_USER_ID}@${SOURCE_IP}:$SOURCE_FILE_DIRECTORY" |grep -i "_cmpbalraw_"$fileDate"_")
	for file in `echo $fileListCleaned`
	do
		if [ `echo ${file} | grep ".dat"` ]
                then
                	echo "Coping the Balance Snapshot file with .dat extension is $file"
			exactFileName=`echo ${file}|awk -F'/' '{print $NF}'`
			sftp -oBatchMode=no -b - ${SOURCE_USER_ID}@${SOURCE_IP} <<-!
			cd $SOURCE_FILE_DIRECTORY
			get ${file} ${SIFT_INPUT_FILE_TEMP_DIRECTORY}
			!
			tar cfz ${SIFT_INPUT_FILE_ARCHIVE_DIRECTORY}"/"${file}".tar.gz" -P ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file}
        		mv ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file} $SIFT_INPUT_FILE_DIRECTORY

		elif [ `echo ${file} | grep ".ctl"` ]
                then
                        echo "Coping the Balance Snapshot file with .ctl extension is $file"  
			sftp -oBatchMode=no -b - ${SOURCE_USER_ID}@${SOURCE_IP} <<-!
			cd $SOURCE_FILE_DIRECTORY
			get ${file} ${SIFT_INPUT_FILE_TEMP_DIRECTORY}
			!
			tar cfz ${SIFT_INPUT_FILE_ARCHIVE_DIRECTORY}"/"${file}".tar.gz" -P ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file}
        		rm -rf ${SIFT_INPUT_FILE_TEMP_DIRECTORY}"/"${file}
		fi
	done
else
echo "Balance Snapshot file with .eot extension in the date $fileDate is not present."
fi
#..................Balance snapshot file fetching end...........................
      
rm $SIFT_INPUT_CHECK_PULLING_DIRECTORY/balanceAndServiceSnapshotDatapull.ctl
echo "End to pull Balance and Service Snapshot Files at `date`"
echo "==================================================================="
fi
            
