#! /bin/bash

START_HOUR=$1
END_HOUR=$2
UDR_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/UDR
SCRIPT_PATH=/home/siftuser/PSNM_Scripts
OUTPUT_FILE=/home/siftuser/PSNM_Scripts/MonitorUDRTemp.txt
FINAL_OUTPUT_FILE=/home/siftuser/PSNM_Scripts/MonitorUDR_`date "+%Y%m%d"`_$START_HOUR_$END_HOUR.txt
#LOG_FILE=/home/siftuser/PSNM_Scripts/MonitorUDRTemp.log

#echo $START_HOUR >> $LOG_FILE
#echo $END_HOUR >> $LOG_FILE

rm $OUTPUT_FILE

while [ $START_HOUR -lt $END_HOUR ]
do
cd $UDR_INPUT_PATH
ls -1 *.gz >> $OUTPUT_FILE
sleep 20s 
START_HOUR=`date "+%H"`
#echo $START_HOUR >> $LOG_FILE
#echo "Starting Next Iteration" >> $LOG_FILE
done

cat $OUTPUT_FILE | sort | uniq >> $FINAL_OUTPUT_FILE
