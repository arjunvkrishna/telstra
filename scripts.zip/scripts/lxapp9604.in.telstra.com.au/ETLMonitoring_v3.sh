#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts/HealthCheck/
LOG_FILE=$MONITORING_PATH/ETL_FILE_Processing_`date +%Y%m%d`.log
FILE_CHECK_FILE=$MONITORING_PATH/ETLCount_`date +%F`.txt
SIFT_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/BATCH_TRIGGER

ETL_INPUT_FILE=$SIFT_INPUT_PATH/SIFT_SERVICE_PROFILE_`date +%Y%m%d`*.txt
echo "`date '+%F %T'` | INFO | Starting  Monitoring Script For ETL Processing Of `date +%F`"  >> $LOG_FILE

function sendEmailAlert ()
{
    emailSubject="SIFT EMAIL ALERT "\!\!\!" ETL Monitoring - `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'Nirmal_Thekkekkota@infosys.com')
        echo $MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
}

while [ 1 ]
do

if [ -e $FILE_CHECK_FILE ]
then
FILE_FOUND=`cat $FILE_CHECK_FILE`
else
cd $SIFT_INPUT_PATH
FILE_COUNT=`ls -1 $ETL_INPUT_FILE | wc -l`
        if [ $FILE_COUNT -gt 0 ]
        then
        FILE_FOUND='Y'
        echo "Y" >> $FILE_CHECK_FILE
        else
        FILE_FOUND='N'
        echo "`date '+%F %T'` | INFO | Awaiting File in SIFT Input Directory For ETL Processing Of `date +%F`"  >> $LOG_FILE
        fi
fi


if [ "$FILE_FOUND" = "Y" ]
then
cd $SIFT_INPUT_PATH
FILE_COUNT=`ls -1 $ETL_INPUT_FILE | wc -l`
        if [ $FILE_COUNT -gt 0 ];
        then
        currHour=`date "+%H"`
        if [ $currHour -gt 18 ]
        then
        echo "`date '+%F %T'` | WARN | ETL Score Processing For `date +%F` is Extending Beyond 6 PM."  >> $LOG_FILE
        MSG="ETL Processing For `date +%F` is Extending Beyond 6PM. Do NeedFul !"
        sendEmailAlert
        fi
        echo "`date '+%F %T'` | INFO | ETL Processing For `date +%F` is in Progress."  >> $LOG_FILE
        elif [ $FILE_COUNT -eq 0 ]; then
        echo "`date '+%F %T'` | INFO | ETL Score Processing For `date +%F` Completed."  >> $LOG_FILE
        MSG="ETL Processing For `date +%F` Completed."
        sendEmailAlert
        exit
        fi
fi

if [ "$FILE_FOUND" = "N" ]
then
currHour=`date "+%H"`
        if [ $currHour -gt 11 ];
        then
        echo "`date '+%F %T'` | ERR | ETL Files For `date +%F` Not Reached SIFT Input Directory"  >> $LOG_FILE
        MSG="ETL Files For `date +%F` Not Reached SIFT Input Directory."
		fi
fi

sleep 5m
done

