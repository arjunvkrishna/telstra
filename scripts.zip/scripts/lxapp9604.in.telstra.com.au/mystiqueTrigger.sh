#!/bin/sh

SCRIPT_PATH=/opt/knowesis/sift/core/sift/scripts/
MYSTIQUE_DIR=/data/mystique/
source $SCRIPT_PATH/envSift.sh;
USER=n100417
SERVER=lxfile0023.in.telstra.com.au
MOVED_FILE_PATH=/Athenian/Sift/reporting/
if [ ! -e  $SCRIPT_PATH/LOGS_MYSTIQUE ]
	then
	mkdir -p $SCRIPT_PATH/LOGS_MYSTIQUE
fi
exec >>  $SCRIPT_PATH/LOGS_MYSTIQUE/`date +%F`.log

  echo "



****************************************************************************************************" 
  echo "****************************************************************************************************" 
  echo "***********************  Mystique Started at `date`         *****************" 
  echo "****************************************************************************************************" 
  echo "****************************************************************************************************" 

if [ $# -eq 0 ]
        then
        currentDate=$(date +"%Y%m%d")
        echo "No Date Supplied So Extracting the Report for today i.e., "$currentDate
else
        currentDate=$(date -d "$1" +"%Y%m%d")
        if [[ -z "$currentDate" ]]
        then
        echo "Please supply the date in YYYYMMDD Format i.e.,"$(date +"%Y%m%d")
        exit
        fi
        echo "Date Supplied is "$currentDate
fi
_date=$currentDate
echo $_date
INPUT_FILE_PATH_DIR=$MYSTIQUE_DIR/INPUT_FILES
INPUT_ARCHIVE_PATH_DIR=$MYSTIQUE_DIR/INPUT_ARCHIVES
OUTPUT_FILE_PATH=$MYSTIQUE_DIR/OUTPUT_FILES
if [ ! -e ${OUTPUT_FILE_PATH} ]
        then
        mkdir -p -m 777 ${OUTPUT_FILE_PATH}
fi
ERROR_LOG_PATH=$OUTPUT_FILE_PATH/ERROR_LOG
if [ ! -e ${ERROR_LOG_PATH} ]
        then
        mkdir -p -m 777 ${ERROR_LOG_PATH}
fi
ACTUAL_PERSIST_PATH=`echo $PERSIST_ADDRESS|awk -F "," '{print $1}'`
pattern=msisdn
count=0
for i in `ls ${INPUT_FILE_PATH_DIR}|grep $pattern`
do
 let count++ 
 INPUT_FILE=$INPUT_FILE_PATH_DIR/$i
echo $INPUT_FILE
  java -jar ${SCRIPT_PATH}/TelstraMystique.jar $ACTUAL_PERSIST_PATH $INPUT_FILE $OUTPUT_FILE_PATH/Sift_Extract_${_date}_${count}.csv $_date ${ERROR_LOG_PATH}/Sift_Extract_${_date}_error.csv 1000
  INPUT_FILE_TO_SCP=$OUTPUT_FILE_PATH/Sift_Extract_${_date}_${count}.csv
  echo $INPUT_FILE_TO_SCP
  echo $MOVED_FILE_PATH
  scp -q ${INPUT_FILE_TO_SCP} ${USER}@${SERVER}:${MOVED_FILE_PATH}
  if [ $? -ne 0 ]
   then
    echo "file tranfer failed for ${INPUT_FILE_TO_SCP}"
   else
  echo "****************************************************************************************************" 
  echo "Execution finished for $INPUT_FILE_TO_SCP. 
Output generated at $OUTPUT_FILE_PATH  and error file is created in $OUTPUT_FILE_PATH/ERROR_LOG folder"
  echo "****************************************************************************************************" 
  fi 
    mv ${INPUT_FILE} ${INPUT_ARCHIVE_PATH_DIR}
done

