#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts/HealthCheck/ModelScore_Monitoring
LOG_FILE=$MONITORING_PATH/FilePull_Log_`date +%Y%m%d`.log
SIFT_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input
BUNDLE_INPUT_PATH=$SIFT_INPUT_PATH/BUNDLE_SNAPSHOT
MODEL_INPUT_PATH=$SIFT_INPUT_PATH/MODEL_SCORE
echo "`date '+%F %T'` | INFO | Starting Script to Stop Processing Of Bundle and Model Score Processing For `date +%F`"  >> $LOG_FILE

cd $MODEL_INPUT_PATH
MODEL_COUNT=`ls -1 RIA_SIFT_MOD_SCR*.csv | wc -l`
if [ $MODEL_COUNT -gt 0 ]
then
rm -f RIA_SIFT_MOD_SCR*.csv
echo "`date '+%F %T'` | INFO | Removed  $MODEL_COUNT Model Score File From SIFT INPUT"  >> $LOG_FILE
else
echo "`date '+%F %T'` | INFO | No Model Score File Present In SIFT INPUT"  >> $LOG_FILE
fi


cd $BUNDLE_INPUT_PATH
BUNDLE_COUNT=`ls -1 BAL_BUNDLE*.csv | wc -l`
if [ $BUNDLE_COUNT -gt 0 ]
then
rm -f BAL_BUNDLE*.csv
echo "`date '+%F %T'` | INFO | Removed $BUNDLE_COUNT Bundle Files From SIFT INPUT"  >> $LOG_FILE
else
echo "`date '+%F %T'` | INFO | No Bundle Files Present In SIFT INPUT"  >> $LOG_FILE
fi

echo "`date '+%F %T'` | INFO | Script to Stop Processing Of Bundle and Model Score Processing For `date +%F` Completed" >> $LOG_FILE

