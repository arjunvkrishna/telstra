#!/bin/sh

SCRIPT_PATH=`echo $0|sed 's/housekeepProcessedData.sh//g'`
source $SCRIPT_PATH/envSift.sh;

#source ~/.bashrc

function sendEmailAlert ()
{
    hostname=`uname -n`
    emailSubject="SIFT EMAIL ALERT "\!\!\!" $hostname SERVER - ORPHEUS EMPTY FILES NOTIFICATION - `date +%F`"
    toAddressArray=('bhuvan.siddaramu@infosys.com' 'Manoj_Kumar51@infosys.com' 'Shiju_R@infosys.com' 'Saikrishna_Doli@infosys.com')
    cat $LOG_PATH/Log_RecordCount_$i | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"

}

function record_count_check()
{
	if [ $i == 'PROFILE' ] || [ $i == 'OCS_ACTIVATION' ] || [ $i == 'MOB_ACTIVITY' ] || [ $i == 'MODEL_SCORE' ]
	then
	continue
	fi

#	LOG_PATH=${HOUSEKEEPING_ARCHIVE_PATH}/logs
#	Time=`date "+%Y%m%d%H"`
	if [ -f $LOG_PATH/Log_RecordCount_$i ]
	then
	rm -rf $LOG_PATH/Log_RecordCount_$i
	fi
	
        touch $LOG_PATH/Log_RecordCount_$i
	
	cd $HOUSEKEEPING_ARCHIVE_PATH/$1/$Time
	
        FileCount=`ls -1 *.gz | wc -l`
	if [ $FileCount -eq 0 ]
	then
	echo "No " $i " Files in Archive Folder For Last Hour, Please Check" >> $LOG_PATH/Log_RecordCount_$i
        sendEmailAlert
	fi

	EmptyFileCounter=0
	
	for filename in `ls -1 *.gz`
	do
	RecCount=`zcat $filename | wc -l`
	RecCountFinal=$(($RecCount-2))
	echo "$filename:$RecCountFinal" >> $LOG_PATH/Log_RecordCount_$i
	if [ $RecCountFinal -eq 0 ]
	then
	EmptyFileCounter=$(($EmptyFileCounter+1))
	fi
	done
	
	if [ $EmptyFileCounter -gt 7 ]
	then
	echo "More Than 5 Empty " $i " Files in Archive Folder, For Last Hour, Please Check" >> $LOG_PATH/Log_RecordCount_$i
	sendEmailAlert
        else
        echo "Record Count Check For " $i "OK" >> $LOG_PATH/Log_RecordCount_$i
        fi
}

function Archive_process()
{
                LOG_PATH=${HOUSEKEEPING_ARCHIVE_PATH}/logs
                if [ ! -d ${HOUSEKEEPING_ARCHIVE_PATH}/logs ]
                then
                        mkdir -p ${HOUSEKEEPING_ARCHIVE_PATH}/logs/
                fi
                touch $LOG_PATH/log_$3_`date "+%Y%m%d-%H"`.log
                exec > $LOG_PATH/log_$3_`date "+%Y%m%d-%H"`.log
                #Moving the Files
                echo "Moving of $1 files starts at `date "+%Y%m%d%H%M%S"`"
                Time=`date "+%Y%m%d%H"`
                mkdir -p $HOUSEKEEPING_ARCHIVE_PATH/$1/$Time
                #Much fastest way to move as compared to the find but much expensive
                        #cd  $2/$1
                        #ls|xargs mv -t  $HOUSEKEEPING_ARCHIVE_PATH/${3}/$1/$Time;
                find $2/$1 -maxdepth 1 -type f -amin +5 -exec mv {} $HOUSEKEEPING_ARCHIVE_PATH/$1/$Time \;
                echo "Moving of files ends at `date "+%Y%m%d%H%M%S"`"
				
				record_count_check $1
}

#for i in CDR LDR PROFILE SNAPSHOT
for i in PROFILE BAR UDR MER OLDR BTR OCS_ACTIVATION MOB_ACTIVITY MODEL_SCORE  
do
        Archive_process $i/`date +%F` $HOUSEKEEPING_PROCESSED_PATH $i &

done

