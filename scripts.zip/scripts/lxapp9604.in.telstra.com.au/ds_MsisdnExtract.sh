#!/bin/bash
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# title 		:ds_MsisdnExtract.sh
# description 		:This script sends the msisdn List to DataSource Path
# author 		:SIFT Team
# version 		:1.0.0
# usage 		:bash ds_MsisdnExtract.sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Folder Paths
SOURCE_PATH=/opt/knowesis/sift/scripts/tmp/MsisdnExtract_BACKUP
DESTINATION_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/ETL_TRIGGER

#File Configs
SOURCE_FILE_NAME=msisdn_list.txt
DESTINATION_FILE_NAME=SIFT_ETL_TRIGGER_$(date +"%Y%m%d").txt

#split config
SPLIT_COUNT=500000

#Log Configs
LOG_DIR=/opt/knowesis/sift/scripts/log
LOG_FILE=$LOG_DIR/ds_MsisdnExtract_$(date +"%Y%m").log

#Logger Function
function logger {
    echo "$(date) | $1" >> $LOG_FILE
}

#checks if the file present in Source_Path ( msisdn_list.txt )
if [ -f $SOURCE_PATH/$SOURCE_FILE_NAME ];
then
    logger "INFO  | Source File found, starting to process."	
    #splitting the msisdnList file to respective count.
    base_name=${DESTINATION_FILE_NAME%.*}_
    split -d -a 2 -l ${SPLIT_COUNT} $(echo ${SOURCE_PATH}/${SOURCE_FILE_NAME} | awk -F'.' '{print $1}').txt ${DESTINATION_PATH}/${base_name}
    if [ $? -eq 0 ];
    then
        logger "INFO  | Split command successfully executed"
    else
        logger "ERROR | Splitting failed with Status : $?"
    fi
     
    #for each of the split files mv (rename) the files over to the destination path
    for splitFiles in $(find $DESTINATION_PATH -type f -name "${base_name}*");
    do
        mv ${splitFiles} ${splitFiles}.txt
        logger "INFO  | Pushed ${splitFiles}.txt to DS Path"
    done
else
	logger "ERROR | Msisdn list not found in Path : ${SOURCE_FILE_NAME}"
fi
