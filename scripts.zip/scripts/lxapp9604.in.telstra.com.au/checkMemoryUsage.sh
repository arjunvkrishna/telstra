echo "Disk Usage"
THISHOSTNAME=$(hostname)
df -h | grep '/data' -m 1 |  awk '{print "ServerName\tLocation\tSize\tUsed\tAvail\tUse%";} {print '\"$THISHOSTNAME\"',"\t","/data","\t",$1,"\t",$2,"\t",$3,"\t",$4;}'

echo "RAM Usage"
free -g | awk 'NR==2{printf "%s\t%s\t%s\t%s\t%s\t\n%s\t%sGB\t%sGB\t%sGB\t%.2f%\n", "ServerName","TotalMemory","UsedMemory","FreeMemory","Use%",'\"$THISHOSTNAME\"',$2,$3,$2-$3,$3*100/$2 }'
