#!/bin/sh
# Do Not Run This Script Between 01:00 and 03:00. Scheduled Run of This Script Would Start at 00:00 and would run at an Interval of 3 Hours.
MONITORING_PATH=/home/siftuser/PSNM_Scripts/HealthCheck/NetworkPing_Monitoring
NTWRK_PING_MONTR_LOG=$MONITORING_PATH/NetworkPing_Monitoring_`date +"%Y%m%d"`.log
NTWRK_PING_FILE_TODAY=rti_networkping_`date +"%Y%m%d"`*_*.dat
NTWRK_PING_FILE_YEST=rti_networkping_`date -d '1 day ago' +"%Y%m%d"`*_*.dat
ARCHIVE_PATH_TODAY=/data/ARCHIVE/MOB_ACTIVITY/`date +"%Y-%m-%d"`
ARCHIVE_PATH_YEST=/data/ARCHIVE/MOB_ACTIVITY/`date -d '1 day ago' +"%Y-%m-%d"`
YESTERDAY_DATE=`date -d '1 day ago' +"%Y%m%d"`
TODAY_DATE=`date +"%Y%m%d"`
CURRENTDATEHOUR=`date +"%Y%m%d%H"`
CURRENTDATE=`echo $CURRENTDATEHOUR | cut -c1-8`
CURRENTHOUR=`echo $CURRENTDATEHOUR | cut -c9-10`
FILE_PRESENT_COUNT=0
echo "Checking Network Ping Files in Archive Directories at `date +"%Y-%m-%d %T"`" >> $NTWRK_PING_MONTR_LOG
echo "Current Date and Hour: $CURRENTDATEHOUR"  >> $NTWRK_PING_MONTR_LOG

if [ "$CURRENTHOUR" == "00" ]
then
	for HourCode in 23 22 21
	do
	DIRECTORY=`echo $YESTERDAY_DATE$HourCode`
	cd $ARCHIVE_PATH_YEST/$DIRECTORY
	COUNT=`ls $NTWRK_PING_FILE_YEST | wc -l`
		if [ $COUNT -gt 0 ]
		then
		FILE_PRESENT_COUNT=`expr $FILE_PRESENT_COUNT + 1`
		echo "Files For $YESTERDAY_DATE Available in $ARCHIVE_PATH_YEST/$DIRECTORY" >> $NTWRK_PING_MONTR_LOG
		else
		echo "Files For $YESTERDAY_DATE Not Available in $ARCHIVE_PATH_YEST/$DIRECTORY" >> $NTWRK_PING_MONTR_LOG
		fi
	done

	if [ $FILE_PRESENT_COUNT -eq 0 ]
	then
	echo "No File For $YESTERDAY_DATE Available in $ARCHIVE_PATH_YEST in Last 3 Hours" >> $NTWRK_PING_MONTR_LOG
	NOTIFY_MSG=`echo "No File For $YESTERDAY_DATE Available in $ARCHIVE_PATH_YEST in Last 3 Hours"`
	emailSubject="SIFT EMAIL ALERT "\!\!\!" NETWORK PING NOTIFICATION - `date +%F`"
	toAddressArray=('Shabeena_M@infosys.com' 'Saikrishna_Doli@infosys.com' 'Shiju_R@infosys.com' 'Manoj_Kumar51@infosys.com' 'bhuvan.siddaramu@infosys.com' 'Naveen.Kumar@team.telstra.com' 'Monzurul.Hasan@team.telstra.com')
	echo $NOTIFY_MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
	fi	

elif [ "$CURRENTHOUR" != "00" ] && [ "$CURRENTHOUR" != "01" ] && [ "$CURRENTHOUR" != "02" ]
then
PREVHOUR1_TEMP=`expr $CURRENTHOUR - 1`
PREVHOUR2_TEMP=`expr $CURRENTHOUR - 2`
PREVHOUR3_TEMP=`expr $CURRENTHOUR - 3`
PREVHOUR1=`printf "%02d\n" $PREVHOUR1_TEMP`
PREVHOUR2=`printf "%02d\n" $PREVHOUR2_TEMP`
PREVHOUR3=`printf "%02d\n" $PREVHOUR3_TEMP`

for HourCode in $PREVHOUR1 $PREVHOUR2 $PREVHOUR3
	do
	DIRECTORY=`echo $TODAY_DATE$HourCode`
	cd $ARCHIVE_PATH_TODAY/$DIRECTORY
	COUNT=`ls $NTWRK_PING_FILE_TODAY | wc -l`
		if [ $COUNT -gt 0 ]
		then
		FILE_PRESENT_COUNT=`expr $FILE_PRESENT_COUNT + 1`
		echo "Files For $TODAY_DATE Available in $ARCHIVE_PATH_TODAY/$DIRECTORY" >> $NTWRK_PING_MONTR_LOG
		else
		echo "Files For $TODAY_DATE Not Available in $ARCHIVE_PATH_TODAY/$DIRECTORY" >> $NTWRK_PING_MONTR_LOG
		fi
	done

if [ $FILE_PRESENT_COUNT -eq 0 ]
then
	echo "No File For $TODAY_DATE Available in $ARCHIVE_PATH_TODAY in Last 3 Hours" >> $NTWRK_PING_MONTR_LOG
	NOTIFY_MSG=`echo "No File For $TODAY_DATE Available in $ARCHIVE_PATH_TODAY in Last 3 Hours"`
	emailSubject="SIFT EMAIL ALERT "\!\!\!" NETWORK PING NOTIFICATION - `date +%F`"
	toAddressArray=('Shabeena_M@infosys.com' 'manoj_kumar51@infosys.com' 'Nirmal_Thekkekkota@infosys.com' 'Shiju_R@infosys.com' 'bhuvan.siddaramu@infosys.com' 'Monzurul.Hasan@team.telstra.com')
	echo $NOTIFY_MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
fi

else
echo "Cannot Run the Check on This Hour As It May Yield Unexpected Errors, Kindly See Comments in the Script to Know When the Script Can be Run" >> $NTWRK_PING_MONTR_LOG
fi
echo "Check Completed at `date +"%Y-%m-%d %T"`" >> $NTWRK_PING_MONTR_LOG
