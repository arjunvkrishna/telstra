#!/bin/bash

set -e
trap 'catch $? $LINENO' EXIT

catch() {
  case "$1" in
    1)
      echo "$(date) | ERROR | $JOB_NAME | trapped $1 on line number $2" >> $LOG_FILE
      echo "$(date) | ERROR | $JOB_NAME | eot file not found" >> $LOG_FILE
      rm $LOCK_FILE
      rm $DONE_FILE
      echo "$(date) | INFO  | $JOB_NAME | Lock file deleted with status $?" >> $LOG_FILE
      ;;
    2)
      echo "$(date) | ERROR | $JOB_NAME | trapped $1 on line number $2" >> $LOG_FILE
      echo "$(date) | ERROR | $JOB_NAME | Script is currently running for the Job $1, Exiting now.!"  >> $LOG_FILE
      ;;
    0)
      echo "$(date) | INFO  | $JOB_NAME | Script completed successfully on line $2" >> $LOG_FILE
      rm $LOCK_FILE
      echo "$(date) | INFO  | $JOB_NAME | Lock file deleted with status $?" >> $LOG_FILE
      rm $DONE_FILE_YESTERDAY
      echo "$(date) | INFO  | $JOB_NAME | Yesterday's done file deleted with status $?" >> $LOG_FILE
      touch $DONE_FILE
      echo "$(date) | INFO  | $JOB_NAME | Done file created with status $?" >> $LOG_FILE
      ;;
    3)
      echo "$(date) | ERROR | $JOB_NAME | Script has already run successfully $2" >> $LOG_FILE
      rm $LOCK_FILE
      echo "$(date) | INFO  | $JOB_NAME | Lock file deleted with status $?" >> $LOG_FILE
      ;; 
    *)
      echo "$(date) | ERROR | $JOB_NAME | trapped $1 on line number $2" >> $LOG_FILE
      rm $LOCK_FILE
      echo "$(date) | INFO  | $JOB_NAME | Lock file deleted with status $?" >> $LOG_FILE
      ;;
  esac
}


JOB_NAME=$1
SCRIPT_HOME=$(dirname $(cd `dirname $0` && pwd))
CONFIG_FILE=$SCRIPT_HOME/conf/$(basename $BASH_SOURCE .sh).config
DATE_LOG=$(date +"%Y%m")
DATE_TODAY=$(date +"%Y%m%d")
DATE_YESTERDAY=$(date +"%Y%m%d" -d "1 day ago")
LOG_FILE=$SCRIPT_HOME/log/$(basename $BASH_SOURCE .sh)_$DATE_LOG.log
LOCK_FILE=$SCRIPT_HOME/lock/$(basename $BASH_SOURCE .sh).$JOB_NAME.lock
TEMP_DIR=$SCRIPT_HOME/temp
DONE_FILE=$SCRIPT_HOME/lock/$(basename $BASH_SOURCE .sh).$JOB_NAME.$DATE_TODAY.done
DONE_FILE_YESTERDAY=$SCRIPT_HOME/lock/$(basename $BASH_SOURCE .sh).$JOB_NAME.$DATE_YESTERDAY.done

#logger function info
function logger_info {
  echo "$(date) | INFO  | $JOB_NAME | $1" >> $LOG_FILE
}

#logger function error
function logger_error {
  echo "$(date) | ERROR | $JOB_NAME | $1" >> $LOG_FILE
}

#logger function warn
function logger_warn {
  echo "$(date) | WARN  | $JOB_NAME | $1" >> $LOG_FILE
}

# 1. INPUT_DIRECTORY
# 2. INPUT_FILE_PATTERN
# 3. EOT_FILE
# 4. FILTER_COLUMN - 1
# 5. FILTER_VALUE -
# 5. OUTPUT_DIRECTORY
# 6. OUTPUT_FILE_PATTERN
# 7. COLUMN_TO_EXTRACT
# 8. INPUT_FILE_DELIMITER
#sample config
#HENDRIX_BUNDLE=
INPUT_DIRECTORY=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $2}')
INPUT_FILE_PATTERN=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $3}')
INPUT_FNAME=$(eval echo $INPUT_FILE_PATTERN)
INPUT_FILE=$INPUT_DIRECTORY/$INPUT_FNAME
EOT_FILE=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $4}')
FILTER_COLUMN=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $5}')
FILTER_VALUE=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $6}')
OUTPUT_DIRECTORY=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $7}')
OUTPUT_FILE_PATTERN=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $8}')
OUTPUT_FNAME=$(eval echo $OUTPUT_FILE_PATTERN)
OUTPUT_FILE=$OUTPUT_DIRECTORY/$OUTPUT_FNAME
OUTPUT_FILE_TMP=$OUTPUT_DIRECTORY/$OUTPUT_FNAME.tmp
COLUMN_TO_EXTRACT=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $9}')
INPUT_FILE_DELIMITER=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $10}')

#Check if the script is already running, if yes exit.
if [ -f $LOCK_FILE ]
then
  exit 2
fi

#Creating lock file
touch $LOCK_FILE
logger "INFO  | Lock File generated with status $?"



if [ "$#" -ne 1 ]; then
  logger_error "exactly one argument required! Provide JOB_NAME as the only argument"
  exit 1
fi

# function to check for EOE Completion file
function checkForEot {
  if [ ! -z $EOT_FILE ];
  then
    #eoe FileName
    eotFile=${1%%.*}.$EOT_FILE
    logger_info "Checking for the eot File."

    if [ -f $DONE_FILE ]
    then
      exit 3
    fi

    if [ ! -f $eotFile ];
    then
      exit 1
    fi
    
    logger_info "eot File Found. Starting to process files.! "
  fi
}

function filter {
  for file in $INPUT_DIRECTORY/$INPUT_FNAME;
  do
    logger_info "processing $file"
    checkForEot $file
    awk -v a="$FILTER_COLUMN" -v b="$FILTER_VALUE" -v c="$COLUMN_TO_EXTRACT" -F"$INPUT_FILE_DELIMITER" '{if($a == b){print $c}}' $file >> $OUTPUT_FILE_TMP
    logger_info "filteration completed with status $?"
  done
  mv $OUTPUT_FILE_TMP $OUTPUT_FILE
  logger_info "Final output file generted with status $?"
}

filter
