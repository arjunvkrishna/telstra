#!/bin/sh

SCRIPT_DIR=/opt/knowesis/sift/core/sift/scripts
SIFT_HOME=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data
#SIFT_HOME=/opt/sift/pworkspace/SiFT_Source_data/data
USER=n100417
SERVER=lxfile0023.in.telstra.com.au
MOVED_FILE_PATH=/Athenian/Sift/reporting/Event_Sink_Files

#USER=siftuser
#SERVER=lxapp7732
#MOVED_FILE_PATH=/home/siftuser/EVENT_SINK



if [ ! -e ${SCRIPT_DIR}/Competition_LOGS ]
        then
        mkdir -p -m 777 ${SCRIPT_DIR}/SinkFilesFTP_LOGS
fi

exec >> ${SCRIPT_DIR}/SinkFilesFTP_LOGS/EventSink_`date +%F`.log

echo "[INFO]  `date` | Starting FTP"
if [ $# -eq 0 ]
	then
	DATE_VALUE=`date --date="1 days ago" "+%Y%m%d"`
        echo "[INFO]  `date` | Date specified = NA, extracting for $DATE_VALUE"
else
	DATE_VALUE=`date --date="1 days ago $1" "+%Y%m%d"`
	echo "[INFO]  `date` | Date specified = $1, extracting for $DATE_VALUE"
fi

offset=`date +%:z|awk -F "+" '{print $2}'`:00
echo "[INFO] `date` | offset : $offset"
timestamp=`date +%s --date="$DATE_VALUE $offset"`
echo "[INFO]  `date` | timestamp : $timestamp"
cd $SIFT_HOME
DATE_DIR=${MOVED_FILE_PATH}/${DATE_VALUE}
ssh  ${USER}@${SERVER} "mkdir -p $DATE_DIR"

fileCount=1
for fileName in Event_Sink_FS1-*${timestamp}*;
do
  echo "[INFO]  `date` | Copying $fileName"
  scp -q $fileName ${USER}@${SERVER}:${DATE_DIR}/Event_Sink_${DATE_VALUE}_${fileCount}.csv
  fileCount=$((fileCount + 1))
  if [ $? -ne 0 ]
   then
    echo "[ERROR] `date` | File tranfer failed for $fileName"
  fi
done


for fileName in **/*Event_Sink_FS1-*${timestamp}*;
do
  echo "[INFO] `date` | Copying $fileName"
  scp -q $fileName ${USER}@${SERVER}:${DATE_DIR}/Event_Sink_${DATE_VALUE}_${fileCount}.csv
  fileCount=$((fileCount + 1))
  if [ $? -ne 0 ]
   then
    echo "[ERROR] `date` | File tranfer failed for $fileName"
  fi
done

echo "[INFO]  `date` | FTP completed"
echo ""


#SIFT_HOME=/opt/sift/pworkspace/SiFT_Source_data/data
#EVENT_SINK_FILE_DIR=/opt/sift/pworkspace/SiFT_Source_data/data
