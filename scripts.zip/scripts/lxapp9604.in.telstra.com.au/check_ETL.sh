#!/bin/sh

source /home/siftuser/.bashrc
SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts
source ${SCRIPTS_PATH}/envSift.sh

to="odcsupport@knowesis.com,Manoj_Kumar51@infosys.com,sumit.srivastava02@infosys.com,Twinku.Thomas@team.telstra.com,shinu.antony01@infosys.com,telstra_athenian@infosys.com,ajith@knowesis.com, 1391cbfc.knowesis.com@apac.teams.ms"
WORKING_DIR=/opt/knowesis/sift/core/sift/scripts/ETLExtract
OUTPUT_DIR=/opt/knowesis/sift/core/sift/scripts/ETLExtract/input
CURRENT_DATE=`date '+%Y%m%d'`
LOG_NAME="app-info.log"
LOG_FILE=${WORKING_DIR}/logs/checkETLStatus.log
nThreadRatio=30

restartFunc(){
    echo "Restart ETL service !!!" >> ${LOG_FILE}
    cp ${WORKING_DIR}/logs/${LOG_NAME} ${WORKING_DIR}/logs/${LOG_NAME}_${CURRENT_DATE}_issue
    cp ${WORKING_DIR}/nohup.out ${WORKING_DIR}/nohup_${CURRENT_DATE}_issue.out
    
    result=`ps -efl |grep SiftETL.jar | grep -v grep | wc -l`
    if [ $result -ge 1 ]
    then
        echo "Stop old ETL"
        kill -9 `ps -ef|grep -i SiftETL.jar | grep -v 'grep' | awk '{print $2}'`
    fi

    sh ${WORKING_DIR}/startETL.sh

}

alertFunc(){
    echo "Send the email topic ${1} !!!" >> ${LOG_FILE}
    echo "${CURRENT_DATE} - ${1}" | mailx -s "[OPOLO] Sift ETL Jobs [ALERT]" -S smtp=mail.in.telstra.com.au "$to"
    
}

if [ $# -gt 0 ]
then
    MODE=$1
else
    MODE="Status"
fi

if [ ${MODE} = "Thread" ]
then

    #=== Check thread count ===
    nThread=`grep currentDay ${WORKING_DIR}/logs/${LOG_NAME} | wc -l | awk '{print $1}'`
    echo "Thread count ${nThread} => nThreadRatio = ${nThreadRatio}"

    if [ ${nThread} -ge ${nThreadRatio} ]
    then
        echo "Thread count ${nThread} more than Thread ratio ${nThreadRatio} need to restart !" >> ${LOG_FILE}
        #alertFunc "Thread alert !!!"
        restartFunc
    fi
else

    #=== check processing ===
    isProcessing=`grep "Processing file name" ${WORKING_DIR}/logs/${LOG_NAME} | wc -l | awk '{print $1}'` 
    if [ ${isProcessing} -ge 1 ]
    then
        echo "ETL is processing" >> ${LOG_FILE}
        sleep 6
        isFileGenerate=`ls -lrt ${OUTPUT_DIR}/ | grep ${CURRENT_DATE} | wc -l | awk '{print $1}'`
        if [ ${isFileGenerate} -eq 0 ]
        then
            echo "But output file not generate, Need to check and restart !" >> ${LOG_FILE}
            alertFunc "Output file not generate. Kindly check"
            #restartFunc
        fi
    else
        echo "ETL not processing, Need to check and restart !" >> ${LOG_FILE}
        alertFunc "ETL not process. Kindly check"
       # restartFunc
    fi
fi

