#!/bin/sh
if [ $# -eq 0 ]
	then
	DATE_VALUE=$(date +"%F")
	echo "No Date Supplied So counting the files for today i.e., "$DATE_VALUE
else
	DATE_VALUE=$(date -d "$1" +"%F")
	if [[ -z "$DATE_VALUE" ]]
        then
        echo "Please supply the date in YYYY-MM-DD Format i.e.,"$(date +"%F")
        exit
        fi
	echo "Date Supplied is "$DATE_VALUE
fi
#timestamp=`date +%s --date="${currentDate} 10:00:00"`
DATE_VALUE_1_DAY_AHEAD=`date --date="next day $DATE_VALUE" "+%Y-%m-%d"`
SIFT_HOME=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Messages
DIRS="$SIFT_HOME/FS_BATCH $SIFT_HOME/FS_REALTIME $SIFT_HOME/FS_SIMULATION"

# If condition to check for the Event Ids File Existance
if [ ! -f "/home/siftuser/PSNM_Scripts/EventIds_List_For_Counts.txt" ]; then
    echo "Event File Not Found, Please create a Event File EventIds_List_For_Counts.txt and add the event names for which you wanto to generate the stats"
    exit
fi
#inputDateTimeStamp=$(date -d $currentDate +%s)
#today_Date=`date +%s --date="$date 00:00:00"`
#if [ "$inputDateTimeStamp" -lt "$today_Date" ]; then
#sinkFilesPath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/"$currentDate"/Event_Sink_FS1-*"${timestamp}"*.csv"
#fileCount=`ls /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/$currentDate"/"Event_Sink_FS1-*${timestamp}*.csv|wc -l`
#else
#sinkFilesPath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*"${timestamp}"*.csv"
#fileCount=`ls /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*${timestamp}*.csv|wc -l`
#fi
#fileCount=`ls $sinkFilesPath|wc -l`
#if [ $fileCount -eq 0 ]
#then
#	echo "No event Files for "$currentDate
#	exit
#fi
# Event COunts Output will be stored in this folder
mkdir -p /home/siftuser/PSNM_Scripts/Output_EventCounts
#echo "Event_Id Count for "$DATE_VALUE" is"
rm -f /home/siftuser/PSNM_Scripts/Output_EventCounts/EventCounts_$DATE_VALUE.csv
exec > /home/siftuser/PSNM_Scripts/Output_EventCounts/EventCounts_$DATE_VALUE.csv
# For loop to run recursively for all the events in EventIds_List_For_Counts.txt
for i in `cat /home/siftuser/PSNM_Scripts/EventIds_List_For_Counts.txt`
do
count=0
        for dir in $DIRS;
        do
                DirLevelCount=$(find $dir -type f -name 'Event_Sink_*.csv' -size +0b -newermt $DATE_VALUE ! -newermt $DATE_VALUE_1_DAY_AHEAD -exec grep -r '"'$i'"' {} \+ | wc -l)
                count=$((count+DirLevelCount))
        done
echo $i","$count
done
#####################################################################
# Function   : sendFilesSFTP
# Description: This function does the following
#              -> transfers the files to lxfile 0023
# Input Args : None
#####################################################################
function sendFilesSFTP ()
{
    AthenianFileServer="lxfile0023.in.telstra.com.au"
    AthenianUserId="n100417"
    AthenianPath="/Athenian/Sift/reporting/BAU_reporting"
    EventCountFile="/home/siftuser/PSNM_Scripts/Output_EventCounts/EventCounts_$DATE_VALUE.csv"
    scp -p $EventCountFile $AthenianUserId@$AthenianFileServer:$AthenianPath
    scp_status=`echo $?`
    if [ $scp_status -ne 0 ]
    then
        echo "Failed to TRANSFER the file `basename $EventCountFile` to Athenian file Server" 
        exit 1
    fi
 
    echo "Sucessfully transferred the files `basename $EventCountFile` to Athenian file server" 
    exit 0
}

sendFilesSFTP



