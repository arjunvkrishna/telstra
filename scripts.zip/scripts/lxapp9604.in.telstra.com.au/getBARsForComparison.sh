#!/bin/sh
YESTERDAY_DATE_F1=`date -d '1 day ago' +"%Y%m%d"`
TODAY_DATE_F1=`date "+%Y%m%d"`
YESTERDAY_DATE_F2=`date -d '1 day ago' +"%Y-%m-%d"`
TODAY_DATE_F2=`date "+%Y-%m-%d"`
BAR_ARCHIVE_PATH=/data/ARCHIVE/BAR
PSNM_BAR_COMPARE_FOLDER=/home/siftuser/PSNM_Scripts/PSNM_BAR_COMP

for HourCode in `seq 3 23`
do
HOUR=`printf "%02d\n" $HourCode`
DIRECTORY=`echo $YESTERDAY_DATE_F1$HOUR`
cd ${BAR_ARCHIVE_PATH}/${YESTERDAY_DATE_F2}/${DIRECTORY}
zcat *.gz | awk -F, '$2=="3000" && $25 ~ /Voucher|CREDITCARD|DIRECTDEBIT|Failed Recharge|Recharge|BPAY/ && $27>0 && $24=="Recharge"{print$5,$4}' >> ${PSNM_BAR_COMPARE_FOLDER}/BAR_EXTRACT_${TODAY_DATE_F1}.txt
done

for HourCode in `seq 0 1`
do
HOUR=`printf "%02d\n" $HourCode`
DIRECTORY=`echo $TODAY_DATE_F1$HOUR`
cd ${BAR_ARCHIVE_PATH}/${TODAY_DATE_F2}/${DIRECTORY}
zcat *.gz | awk -F, '$2=="3000" && $25 ~ /Voucher|CREDITCARD|DIRECTDEBIT|Failed Recharge|Recharge|BPAY/ && $27>0 && $24=="Recharge"{print$5,$4}' >> ${PSNM_BAR_COMPARE_FOLDER}/BAR_EXTRACT_${TODAY_DATE_F1}.txt
done

sed -i -e 's/ /,/g' ${PSNM_BAR_COMPARE_FOLDER}/BAR_EXTRACT_${TODAY_DATE_F1}.txt
sed -i -e 's/T//g' ${PSNM_BAR_COMPARE_FOLDER}/BAR_EXTRACT_${TODAY_DATE_F1}.txt
sed -i -e 's/+1100//g' ${PSNM_BAR_COMPARE_FOLDER}/BAR_EXTRACT_${TODAY_DATE_F1}.txt
scp -p ${PSNM_BAR_COMPARE_FOLDER}/BAR_EXTRACT_${TODAY_DATE_F1}.txt siftuser@lxapp9608:/home/siftuser/PSNM_Scripts/PSNM_BAR_COMP


ssh siftuser@lxapp9608<<SSHSESSION 2>&1
cd /home/siftuser/PSNM_Scripts
sh nohup PsnmBARComparison.sh &
exit
SSHSESSION
