if [ $# -eq 1 ]
then
dirToBeDeleted=$1
else
echo "No Arguement Supplied, Please Give ARCHIVE/PROCESSED as one arguement"
exit
fi
if [ "$dirToBeDeleted" != "ARCHIVE" ] && [ "$dirToBeDeleted" != "PROCESSED" ]
then
echo "Please Give ARCHIVE/PROCESSED as arguement"
exit
fi
#Parent Path to be Defined Here
deleteFolderPath=/data/$1/
#Log will be written in this file
mkdir -p /data/$1/logs
exec >>  /data/$1/logs/cleanup_$1_`date +%F`.log
echo "==================================================================="
echo "Cleanup Process Has Started For "$1" Directory"
#Function to Delete the Folders which are older than 30 days
function cleanup_files ()
{
   cd $deleteFolderPath
   allDirs=$(ls -trh $deleteFolderPath$2)
      for eachDir in ${allDirs}
      do
      eachDir_Date=$(date -d $eachDir +%s)
      cutOff_Date=`date --date="10 days ago" +"%s"`
         if [ "$eachDir_Date" -lt "$cutOff_Date" ]; then
         fulldeleteFolderPath=$deleteFolderPath$2"/"$eachDir
         echo "cleaning the "$2 $1" data for "$fulldeleteFolderPath    
         rm -rf $fulldeleteFolderPath
         fi
      done
}
# For loop to deftine what all the folders to be cleanup
#for i in CDR LDR PROFILE SNAPSHOT MOB_ACTIVITY MODEL_SCORE
for i in CDR LDR PROFILE SNAPSHOT MOB_ACTIVITY MODEL_SCORE BAR BTR LDR MER OCS_ACTIVATION OLDR UDR
do
       cleanup_files $dirToBeDeleted $i
done
echo "Cleanup Process Has Finished"
echo "==================================================================="

