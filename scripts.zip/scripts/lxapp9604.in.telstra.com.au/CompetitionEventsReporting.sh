#!/bin/sh
SCRIPT_DIR=/opt/knowesis/sift/core/sift/scripts/
OUTPUT_DIR_PATH=/data/competition_reporting/OUTPUT_FILES/
SIFT_HOME=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data
META_DIR=/data/competition_reporting/metadata/
USER=n100417
SERVER=lxfile0023.in.telstra.com.au
MOVED_FILE_PATH=/Athenian/Sift/reporting/
if [ ! -e ${SCRIPT_DIR}/Competition_LOGS ]
        then
        mkdir -p -m 777 ${SCRIPT_DIR}/Competition_LOGS
fi


exec >> ${SCRIPT_DIR}/Competition_LOGS/Extract_`date +%F`.log

echo "
*********************************************************************************"
echo "*******    Starting Event Extraction on `date`   *********"
echo "*********************************************************************************"
if [ $# -eq 0 ]
	then
	echo "No extract date specified. Continuing with current date."
	DATE_VALUE=`date +"%F"`
else
	DATE_VALUE=$1
	echo "Extracting data for $DATE_VALUE"
fi


OUTPUT_DIR=${OUTPUT_DIR_PATH}/Competition/${DATE_VALUE}

if [ ! -e ${OUTPUT_DIR} ]
	then
	mkdir -p -m 777 ${OUTPUT_DIR}
fi

_date=${DATE_VALUE}
timestamp=`date +%s --date="${_date} 11:00:00"`

eventFileName=${OUTPUT_DIR}/Sift_Competition_TriggerHistory_`date +%Y%m%d`_0000.csv
if [ -f $eventFileName ]
then
	rm $eventFileName
fi

for i in `cat $META_DIR/EventIds.txt`
do
echo "Extracting the Trigger Data for Event "$i
cd $SIFT_HOME
grep -r '"'$i'"' --include="Event_Sink_FS1-*${timestamp}*.csv" . | awk -F "csv:" '{print $2}' |awk -F "," '{print $1 "," $2 "," $4 "," $5 "," $6 "," $9 "," $11 "," $13 "," $15 "," $17 "," $19  "," $21 "," $23 "," $25 "," $27 }'|sed 's/\"//g' >> $eventFileName

chmod -R 777 $eventFileName


done
  scp -q $eventFileName ${USER}@${SERVER}:${MOVED_FILE_PATH}
  if [ $? -ne 0 ]
   then
    echo "file tranfer failed for $eventFileName"
   else

echo "*********************************************************************************"
echo "*******    Event Extraction finished at `date`   *********"
echo "*********************************************************************************
"
fi
