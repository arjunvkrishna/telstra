#!/bin/sh

echo "======================================================================="
echo "CMP File Check has started at" $(date "+%b %d %Y %H:%M:%S")

CURRENT_DATE=$(date +%Y-%m-%d --date="1 hour ago")
HOUR_AGO_DATE=$(date +%Y%m%d%H --date="1 hour ago")
WORKING_DATE=$(date "+%d %b %Y %I %p" --date="1 hour ago")

# initialise array variables
FILE_MISSING=()
FILE_STATUS=()

echo "Checking files received at [$WORKING_DATE]"

# iterate all the CMP folders
for item in HUDR HMER HBAR HLDR
do
	if [ "$item" == "HUDR" ]
	then
		NAME_PATTERN="cm1eud${HOUR_AGO_DATE}*"
	
	elif [ "$item" == "HMER" ]
	then
		NAME_PATTERN="cm1eme${HOUR_AGO_DATE}*"
	
	elif [ "$item" == "HBAR" ]
	then
		NAME_PATTERN="cm1emb${HOUR_AGO_DATE}*"
	
	elif [ "$item" == "HLDR" ]
	then
		NAME_PATTERN="cm1eld${HOUR_AGO_DATE}*"
	fi
	
	PROCESSED_PATH="/data/PROCESSED/$item/$CURRENT_DATE"
	PROCESSED_COUNT=$(ls 2>/dev/null $PROCESSED_PATH/$NAME_PATTERN | wc -l)

	ARCHIVE_PATH="/data/ARCHIVE/$item/$CURRENT_DATE"
	ARCHIVE_COUNT=$(ls 2>/dev/null $ARCHIVE_PATH/*/$NAME_PATTERN | wc -l)

	FILE_COUNT=$(expr $PROCESSED_COUNT + $ARCHIVE_COUNT)
	FILE_STATUS+=("$item [$FILE_COUNT]")

	if [ "$FILE_COUNT" -eq 0 ]
	then
		FILE_MISSING+=("$item")
	fi
done

echo "File Check Status: ${FILE_STATUS[*]}"

# send an alert notification if there are missing files
if [ "${#FILE_MISSING[*]}" -gt 0 ] 
then
	MAIL_RECIPIENT="TelstraSalesForcePersonalisationCloudsupport@team.telstra.com,sonal.winston@infosys.com,mohammedsuhayab.r@infosys.com,anjana.ramachandran@infosys.com,akshai.saju@infosys.com"
	MAIL_SUBJECT="[OPOLO] CMP File Check [ALERT!!]"
	MAIL_CONTENT="CMP Files [${FILE_MISSING[*]}] not received on $WORKING_DATE. Kindly check!"
	
	echo "$MAIL_CONTENT" | mailx -s "$MAIL_SUBJECT" -S smtp=mail.in.telstra.com.au "$MAIL_RECIPIENT"
	echo "$MAIL_CONTENT" >> CMP.log
        echo "Alert notification sent. CMP files [${FILE_MISSING[*]}] were not received."
fi

echo "CMP File Check has completed"
echo "======================================================================="
