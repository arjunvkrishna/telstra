#!/bin/sh

exec >>  /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusEXPdatapull_`date +%F`.log
echo "==================================================================="
echo "Starting to pull Orpheus Files at `date`"
#ORPHEUS_USER_ID=siftuser
ORPHEUS_USER_ID=sift
ORPHEUS_IP=10.108.198.76
#ORPHEUS_SOURCE_FILE_DIRECTORY=/opt/unico/store/sift/event/bar/archive/
ORPHEUS_SOURCE_FILE_DIRECTORY=/opt/unico/store/sift/event/exp/output
ORPHEUS_SOURCE_FILE_ARCHIVE_DIRECTORY=/opt/unico/store/sift/event/exp/archive/stream1
SIFT_INPUT_DIRECTORY=/data/ingest/ORPHEUS
SSH_KEY_PATH=/home/siftuser/ssh_keys/prodsiftcore1

dateTime=`date`
echo "Starting EXP File Pull @ $dateTime" 

if [ -f /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusEXPdatapull.ctl ]
then
	echo "EXP Pull already in progress."
	exit
else
	touch /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusEXPdatapull.ctl
	fileDate=`date +%d%m%Y --date="yesterday"`

	#for file in `ssh -i ${SSH_KEY_PATH} ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "ls ${ORPHEUS_SOURCE_FILE_DIRECTORY}/stream*/*ocs_bar*"`
	for file in `ssh ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "ls ${ORPHEUS_SOURCE_FILE_DIRECTORY}/stream*/*ocs_exp*"`
	do
		echo "Copying Files from Orpheus ${file}" 
		exactFileName=`echo ${file}|awk -F'/' '{print $NF}'`
		#scp -i ${SSH_KEY_PATH} ${ORPHEUS_USER_ID}@${ORPHEUS_IP}:${file} ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart
		scp ${ORPHEUS_USER_ID}@${ORPHEUS_IP}:${file} ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart
		mv ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart ${SIFT_INPUT_DIRECTORY}/${exactFileName}
		if [ $? -eq 0 ]; then
			ssh ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "mv ${file}  ${ORPHEUS_SOURCE_FILE_ARCHIVE_DIRECTORY}/${exactFileName}.done"
			echo "Its a File"
		else
			echo "Not A File"
		fi
	done
	dateTime=`date`
	echo "EXP File Pull Completed @ $dateTime"
	rm /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusEXPdatapull.ctl
	echo "==================================================================="
fi
