to="odcsupport@knowesis.com,Manoj_Kumar51@infosys.com,sumit.srivastava02@infosys.com,rajani.jagga@infosys.com,shinu.antony01@infosys.com,telstra_athenian@infosys.com,ajith@knowesis.com"


PID=`ps -ef|grep -i /opt/knowesis/sift/core/sift/scripts/ETLExtract/SiftETL.jar|grep -v 'grep' |wc -l`
if [ ${PID} -eq 0 ]
then
   echo "ETL Exctract is down $(date). Kindly check!" | mailx -s "[OPOLO] Sift Core ETL Exctract [ALERT!!]" -S smtp=mail.in.telstra.com.au "$to"
fi
