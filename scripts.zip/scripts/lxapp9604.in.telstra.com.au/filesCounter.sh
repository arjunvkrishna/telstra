#!/bin/sh

declare -a DATASOURCES=("BUNDLE_SNAPSHOT" "BAR" "MODEL_SCORE" "MOB_ACTIVITY" "BATCH_TRIGGER" "UDR" "OLDR" "MER" "BTR")
SCRIPTS_PATH=/opt/knowesis/sift/core/sift/scripts
INPUT_BASE_DIR=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input
for i in ${DATASOURCES[@]}
do
	echo ${INPUT_BASE_DIR}/${i}: `ls ${INPUT_BASE_DIR}/${i}| wc -l` 
done
echo `date`
