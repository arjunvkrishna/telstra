#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts
SIFT_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input
SCRIPT_LOG=/home/siftuser/PSNM_Scripts/InputFolderCheckLog_`date +%Y%m%d`.log

echo "`date '+%F %T'` | INFO | File Count Checks For Various File Type in Input Folder Started" >> $SCRIPT_LOG
for FileType in BAR MER OLDR BTR UDR MOB_ACTIVITY BATCH_TRIGGER
do
LOG_FILE=$MONITORING_PATH/Input_Folder_File_Check_${FileType}_`date +%Y%m%d`.log
DATETIME=`date '+%F %T'`
cd $SIFT_INPUT_PATH/$FileType
ls -1 *.* | sed "s/^/$DATETIME,/"  >> $LOG_FILE
done
echo "`date '+%F %T'` | INFO | File Count Checks For Various File Type in Input Folder Completed" >> $SCRIPT_LOG

