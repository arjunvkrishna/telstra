#####################################################################
#####################################################################
# Script name: CouchbaseAvailability
# Description: 
# Date       : 13-Nov-2017
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

#####################################################################
# Function   : serverAvailability
# Description: 
#####################################################################
function serverAvailability ()
{
    echo "Application Servers Availability" >> $healthCheckReport
    echo "Component,HostName,Status, Comments" >> $healthCheckReport
    for i in "${all_hostnames[@]}"
    do
        if [ "$i" = "lxapp9603.in.telstra.com.au" ]; then
            component="SIFT Portal"
        elif [ "$i" = "lxapp9604.in.telstra.com.au" ]; then
            component="SIFT core 1"
        elif [ "$i" = "lxapp9605.in.telstra.com.au" ]; then
            component="SIFT core 2"
        elif [ "$i" = "lxapp9702.dc.corp.telstra.com" ]; then
            component="SIFT core 3"
        elif [ "$i" = "lxapp9703.dc.corp.telstra.com" ]; then
            component="SIFT core 4"
        elif [ "$i" = "lxdb9123.in.telstra.com.au" ]; then
            component="SIFT Persist 1"
        elif [ "$i" = "lxdb9124.in.telstra.com.au" ]; then
            component="SIFT Persist 2"
elif [ "$i" = "lxdb9177.in.telstra.com.au" ]; then
            component="SIFT Persist 3"
        elif [ "$i" = "lxapp9606.in.telstra.com.au" ]; then
            component="SO 1"
        elif [ "$i" = "lxapp9607.in.telstra.com.au" ]; then
            component="SO 2"
        elif [ "$i" = "lxapp9608.in.telstra.com.au" ]; then
            component="SO 3"
        fi

        ping -c 1 $i
        if [ $? -eq 0 ]; then 
            echo "$component, $i, AVAILABLE" >> $healthCheckReport
        else
            echo "$component, $i, Not Available, Not able to ping/connect"
        fi
    done

    echo "" >> $healthCheck
}


