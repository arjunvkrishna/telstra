#!/usr/bin/ksh

export MAILTO="Nirmal_Thekkekkota@infosys.com"
export CONTENT="health.html"
export SUBJECT="Subject"
(
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat $CONTENT
) | /usr/sbin/sendmail $MAILTO
