#!/bin/sh

source /home/siftuser/.bashrc

#export ALL_HOSTS=lxapp9604.in.telstra.com.au,lxapp9605.in.telstra.com.au,10.116.255.5,10.116.255.6
#export PERSIST_ADDRESS='http://lxdb9123.in.telstra.com.au:8091/pools,http://lxdb9124.in.telstra.com.au:8091/pools'
export ALL_HOSTS=lxapp9604.in.telstra.com.au,lxapp9605.in.telstra.com.au,10.116.255.5,10.116.255.6
export PERSIST_ADDRESS='http://lxdb9123.in.telstra.com.au:8091/pools,http://lxdb9124.in.telstra.com.au:8091/pools'
export SIFT_HOME=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data
export SIFT_CONFIG=/opt/knowesis/sift/core/sift/PandaData
export SIFT_LIBS=/opt/knowesis/sift/core/sift/libs
export RECOVERY_STATUS_PATH=/tmp

HOUSEKEEPING_PROCESSED_PATH=/data/PROCESSED
HOUSEKEEPING_ARCHIVE_PATH=/data/ARCHIVE

cacheSize=300000
log4jXMLPath=${SIFT_INSTALL_PATH}/core/lib/log4j.xml
classPath=${SIFT_INSTALL_PATH}/core/lib/Stardust-1.0.0.jar:${SIFT_INSTALL_PATH}/core/lib/*
persistClient=couchbase
persistPassword=None

xARGS="-XX:+UseG1GC -XX:MaxGCPauseMillis=20 -XX:InitiatingHeapOccupancyPercent=35 -XX:G1HeapRegionSize=16M -XX:MinMetaspaceFreeRatio=50 -XX:MaxMetaspaceFreeRatio=80"
pandaClassName=com.knowesis.sift.core.operators.PandaSourceFactory
pandaMinHeapSize=10g
pandaMaxHeapSize=120g
hostName=127.0.0.1
seekToBeginningFlag=false
maxPollRecords=80
PandaSleepTime=0

dataSourceClassName=com.knowesis.sift.dataSourceFactory.SourceFactory
sourceName=DNC
DataSourceSleepTime=0
DSMinHeapSize=500m
DSMaxHeapSize=4g

registryKeeperClassName=com.knowesis.sift.core.operators.RegistryKeeper
configCfgClassName=com.knowesis.sift.utilities.FetchConfigDocs

sourceToDeployPath=${SIFT_INSTALL_PATH}/core/sift/scripts/sourcesToDeploy

processRestartTimeInSeconds=30
processRestartNumTimes=3
processRestartStatsFile=${SIFT_INSTALL_PATH}/core/sift/scripts/restartStats
SIFT_MANAGER_PID_FILE=${SIFT_INSTALL_PATH}/core/sift/scripts/.SiftCommandRunning


######################### Logging properties ##############################
elasticSearchUrl=http://lxapp9603.in.telstra.com.au:9200/_bulk
elasticSearchCoreLogsIndex=pandalogs
elasticSearchDSLogsIndex=siftds
elasticSearchBadRecIndex=siftbadrecords
elasticSearchFileReportIndex=siftfilereport
logLevel=error
logType=file
logPath=/opt/knowesis/sift/core/logs/corelogs

####################### DS Handler properties ##############################
KAFKA_HOST_URL=lxapp9606.in.telstra.com.au:9092,lxapp9607.in.telstra.com.au:9092,lxapp9608.in.telstra.com.au:9092
DS_HANDLER_TOPIC=sift.admin.in
DS_HANDLER_CONSUMER_GROUP=DSHandler
SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts
SIFT_SCRIPT=${SCRIPTS_PATH}/sift_native
DS_HANDLER_LOG=/opt/knowesis/sift/core/siftlogs/dslogs



######################### Monitoring properties #############################
mgmtHostFile=${SCRIPTS_PATH}/mgmt.host
maxHostFailuresAllowed=1
monitoringLogPath=/opt/knowesis/sift/core/logs/monitoringlogs
