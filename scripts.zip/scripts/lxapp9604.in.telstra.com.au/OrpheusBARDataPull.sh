#!/bin/sh

exec >>  /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBARdatapull_`date +%F`.log
echo "==================================================================="
echo "Starting to pull Orpheus Files at `date`"
#ORPHEUS_USER_ID=siftuser
ORPHEUS_USER_ID=sift
ORPHEUS_IP=10.108.198.76
#ORPHEUS_SOURCE_FILE_DIRECTORY=/opt/unico/store/sift/event/bar/archive/
ORPHEUS_SOURCE_FILE_DIRECTORY=/opt/unico/store/sift/event/bar/output
SIFT_INPUT_DIRECTORY=/data/ingest/ORPHEUS
SSH_KEY_PATH=/home/siftuser/ssh_keys/prodsiftcore1

dateTime=`date`
echo "Starting BAR File Pull @ $dateTime" 

if [ -f /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBARdatapull.ctl ]
then
	echo "BAR Pull already in progress."
	exit
else
	touch /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBARdatapull.ctl
	fileDate=`date +%d%m%Y --date="yesterday"`

	#for file in `ssh -i ${SSH_KEY_PATH} ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "ls ${ORPHEUS_SOURCE_FILE_DIRECTORY}/stream*/*ocs_bar*"`
	for file in `ssh ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "ls ${ORPHEUS_SOURCE_FILE_DIRECTORY}/stream*/*ocs_bar*"`
	do
		echo "Copying Files from Orpheus ${file}" 
		exactFileName=`echo ${file}|awk -F'/' '{print $NF}'`
		#scp -i ${SSH_KEY_PATH} ${ORPHEUS_USER_ID}@${ORPHEUS_IP}:${file} ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart
		scp ${ORPHEUS_USER_ID}@${ORPHEUS_IP}:${file} ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart
		mv ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart ${SIFT_INPUT_DIRECTORY}/${exactFileName}
		if [ $? -eq 0 ]; then
			ssh ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "rm ${file}"
			echo "Its a File"
		else
			echo "Not A File"
		fi
	done
	dateTime=`date`
	echo "BAR File Pull Compleeted @ $dateTime"
	rm /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBARdatapull.ctl
	echo "==================================================================="
fi
