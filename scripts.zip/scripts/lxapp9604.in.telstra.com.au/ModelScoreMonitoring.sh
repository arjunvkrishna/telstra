#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts/HealthCheck/ModelScore_Monitoring
LOG_FILE=$MONITORING_PATH/Model_Score_Processing_`date +%Y%m%d`.log
FILE_CHECK_FILE=$MONITORING_PATH/MSFileCheck_`date +%F`.txt
SIFT_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/MODEL_SCORE
#SIFT_INPUT_PATH=/home/siftuser/PSNM_Scripts/HealthCheck/ModelScore_Monitoring/test
MS_INPUT_FILE=$SIFT_INPUT_PATH/RIA_SIFT_MOD_SCR_`date +%Y%m%d`*.csv
echo "`date '+%F %T'` | INFO | Starting Monitoring Script For Model Score Processing Of `date +%F`"  >> $LOG_FILE

function sendEmailAlert ()
{
    emailSubject="SIFT EMAIL ALERT "\!\!\!" Model Score Monitoring - `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'bhuvan.siddaramu@infosys.com' 'Manoj_Kumar51@infosys.com' 'Shiju_R@infosys.com' 'Saikrishna_Doli@infosys.com')
#     toAddressArray=('Nirmal_Thekkekkota@infosys.com')
        echo $MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
}

while [ 1 ]
do

if [ -e $FILE_CHECK_FILE ]
then
FILE_FOUND=`cat $FILE_CHECK_FILE`
else
cd $SIFT_INPUT_PATH
FILE_COUNT=`ls -1 $MS_INPUT_FILE | wc -l`
	if [ $FILE_COUNT -gt 0 ]
	then
	FILE_FOUND='Y'
	echo "Y" >> $FILE_CHECK_FILE
	else
	FILE_FOUND='N'
	echo "`date '+%F %T'` | INFO | Awaiting File in SIFT Input Directory For Model Score Processing Of `date +%F`"  >> $LOG_FILE
	fi
fi


if [ "$FILE_FOUND" = "Y" ]
then
cd $SIFT_INPUT_PATH
FILE_COUNT=`ls -1 $MS_INPUT_FILE | wc -l`
	if [ $FILE_COUNT -gt 0 ];
	then
	currHour=`date "+%H"`
	if [ $currHour -gt 10 ]
	then
	echo "`date '+%F %T'` | WARN | Model Score Processing For `date +%F` is Extending Beyond 11 AM."  >> $LOG_FILE
	MSG="Model Score Processing For `date +%F` is Extending Beyond 11 AM. Do NeedFul !"
	sendEmailAlert
	fi
	echo "`date '+%F %T'` | INFO | Model Score Processing For `date +%F` is in Progress."  >> $LOG_FILE
	elif [ $FILE_COUNT -eq 0 ]; then
	echo "`date '+%F %T'` | INFO | Model Score Processing For `date +%F` Completed."  >> $LOG_FILE
	MSG="Model Score Processing For `date +%F` Completed."
	sendEmailAlert
	exit
	fi
fi

if [ "$FILE_FOUND" = "N" ]
then
currHour=`date "+%H"`
	if [ $currHour -gt 7 ];
	then
	echo "`date '+%F %T'` | ERR | Model Score File For `date +%F` Not Reached SIFT Input Directory Till 8 AM, Exiting Monitoring Script."  >> $LOG_FILE
	MSG="Model Score File For `date +%F` Not Reached SIFT Input Directory Till 8 AM, Exiting Monitoring Script."
	sendEmailAlert
	exit
	fi
fi

currHour=`date "+%H"`
	if [ $currHour -eq 23 ];
	then
        echo "`date '+%F %T'` | ERR | Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script."  >> $LOG_FILE	
        MSG="Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script For The Day. Tomorrow's Instance Will Capture Processing of Tomorrow's File."
        sendEmailAlert
        exit
	fi

sleep 5m
done
