#!/bin/bash

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# title :housekeepHendrixProcessedData.sh
# description :This script for archive hendrix DS
# author :SIFT Team
# version :1.0.0
# usage :bash housekeepHendrixProcessedData.sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

SCRIPT_PATH=`echo $0|sed 's/housekeepHendrixProcessedData.sh//g'`

#Sourcing envSift.sh
source ${SCRIPT_PATH}envSift.sh

#Log configs
LOG_DIR=$HOUSEKEEPING_ARCHIVE_PATH/logs

#date config
Time=`date "+%Y%m%d%H"`

#if log directory not present, then create
if [ ! -d ${LOG_DIR} ]
then
	mkdir -p ${LOG_DIR}
fi

#Logger Function
log()
{
	echo "$(date) | $1" >> $LOG_FILE
}

#archive function
Archive_process()
{
	LOG_FILE=$LOG_DIR/log_$3_`date "+%Y%m%d-%H"`.log
	mkdir -p $HOUSEKEEPING_ARCHIVE_PATH/$1/$Time
	find $2/$1 -maxdepth 1 -type f -amin +1 -exec mv {} $HOUSEKEEPING_ARCHIVE_PATH/$1/$Time \;
	if [ $? -eq 0 ];
	then
		log "INFO |  archive completed for $i dated on ${Time} with Status : $?"
	else
		log "ERROR | archiving failed with Status : $?"
	fi
}

#looping over DS(HMER,HBAR,HUDR,HLDR) for archive
for i in HMER HBAR HUDR HLDR
do
	Archive_process $i/`date +%F` $HOUSEKEEPING_PROCESSED_PATH $i &
done
