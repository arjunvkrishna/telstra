outputfilePath="/data/PSNM/expiryDateIssue"

#verify dates
if [ $# -eq 2 ]; then
    startDate=$1
    endDate=$2
    if ! date -d "$startDate" 2>&1 > /dev/null ; 
        then echo "first date is invalid" ; exit 1
    fi
    if ! date -d "$endDate" 2>&1 > /dev/null ; 
        then echo "second date is invalid" ; exit 1
    fi

    if [ "$startDate" -ge "$endDate" ]; then
        echo "Start date cannot be after end date"; exit 1
    fi
fi

if [ $# -eq 1 ]; then
    startDate=$1
    endDate=$1
    if ! date -d "$startDate" 2>&1 > /dev/null ; 
        then echo "first date is invalid" ; exit 1
    fi
fi

if [ ! -d $outputfilePath ]; then
     mkdir -p $outputfilePath
fi

#set next Date
nextDate=$startDate

#loop over all dates
while [ "$nextDate" -le "$endDate" ] 
do 
    currentDate=$(date -d "$nextDate" +%F)
    ETLfilePath="/data/ARCHIVE/PROFILE/"$currentDate"/"
    resultFile="$outputfilePath/ETL_extract_"$currentDate".csv"
    zgrep -a "HH" $ETLfilePath/* | awk -F"|" '{print $1,",",$75}' | awk -F":" '{print $2}' > $resultFile
    echo "ETL extract for $resultFile"
    nextDate=$(date -d "$currentDate + 1 day" +%Y%m%d)  
    echo $nextDate
done
