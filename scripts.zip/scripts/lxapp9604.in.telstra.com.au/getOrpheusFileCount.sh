#####################################################################
#####################################################################
# Script name: getOrpheusFileCount.sh
# Description:
# Date       : 21-Apr-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

#Data Pull Logs Directory
dataPullLogDir="/opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs"

#####################################################################
# Function   : validate_params
# Description: This function validates the date passed on and if no
#              argument is passed, it sets the date to today's date
#####################################################################


#####################################################################
# Function   : count_files
# Description: This function counts for each of the Orpheus files
#              using the log files
#####################################################################
function count_files()
{
    if [ $(date -d "$1" +"%F") ]
        then
        logFileName="orpheus"$i"datapull_"$currentDate".log"
        cd $dataPullLogDir
        if [ -f "$logFileName" ]
                then
                fileCount=$(grep -i "ocs_$i_"$i $logFileName | wc -l)
                echo $i" File Count in "$logFileName " is "$fileCount
        else
                echo "No $i Files present for "$currentDate
        fi
    else
        echo "Please Give the date in YYYY-MM-DD Format"
        exit
    fi
}


#####################################################################
# Function   : main
# Description: 
#####################################################################

  #If no arguement has passed, this script will run for current day
    if [ $# -eq 0 ]; then
        currentDate=$(date +"%F")
        echo "No Date Supplied So counting the files for today i.e., "$currentDate
    else
        currentDate=$(date -d "$1" +"%F")
        echo "Date Supplied is "$currentDate
    fi

for i in BAR UDR MER LDR BTR EXP
do
    count_files $currentDate $i
done

