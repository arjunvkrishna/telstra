#!/bin/sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# title         : HendrixInputSplitter.sh
# description   : Hendrix Input Splitter Script.
# author        : SIFT Team
# version       : 1.0.0
# usage         : sh HendrixInputSplitter.sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Input Path configs
InputFilePathHUDR=/opt/knowesis/input/CMPIN/UDR
InputFilePathHBAR=/opt/knowesis/input/CMPIN/BAR
InputFilePathHMER=/opt/knowesis/input/CMPIN/MER
InputFilePathHLDR=/opt/knowesis/input/CMPIN/LDR
#Output Path Configs
OutputFilePathHUDR=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/HUDR
OutputFilePathHBAR=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/HBAR
OutputFilePathHLDR=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/HLDR
OutputFilePathHMER=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/HMER
#Processed Path
ProcessedCDRFilePath=/data/PROCESSED

while [ 1 ]
do
        if [ ! -d ${ProcessedCDRFilePath}/HLDR/`date +%F` ]
        then
                mkdir -p ${ProcessedCDRFilePath}/HLDR/`date +%F`
        fi
        if [ ! -d ${ProcessedCDRFilePath}/HBAR/`date +%F` ]
        then
                mkdir -p ${ProcessedCDRFilePath}/HBAR/`date +%F`
        fi
        if [ ! -d ${ProcessedCDRFilePath}/HUDR/`date +%F` ]
        then
                mkdir -p ${ProcessedCDRFilePath}/HUDR/`date +%F`
        fi
        if [ ! -d ${ProcessedCDRFilePath}/HMER/`date +%F` ]
        then
                mkdir -p ${ProcessedCDRFilePath}/HMER/`date +%F`
        fi

        listCountHUDR=`ls ${InputFilePathHUDR} |grep ".gz$"|grep -i cm1eud|wc -l`
        if [ ${listCountHUDR} -gt 0 ]
        then
                list=`ls ${InputFilePathHUDR} |grep ".gz$"|grep -i cm1eud`
                for file in `echo ${list}`
                do
                        chmod 777 ${InputFilePathHUDR}/${file}
                        cp ${InputFilePathHUDR}/${file} ${OutputFilePathHUDR}
                        mv ${InputFilePathHUDR}/${file} ${ProcessedCDRFilePath}/HUDR/`date +%F`/
                done
        fi

        listCountHBAR=`ls ${InputFilePathHBAR} |grep ".gz$"|grep -i cm1emb|wc -l`
        if [ ${listCountHBAR} -gt 0 ]
        then
                list=`ls ${InputFilePathHBAR} |grep ".gz$"|grep -i cm1emb`
                for file in `echo ${list}`
                do
                        chmod 777 ${InputFilePathHBAR}/${file}
                        cp ${InputFilePathHBAR}/${file} ${OutputFilePathHBAR}
                        mv ${InputFilePathHBAR}/${file} ${ProcessedCDRFilePath}/HBAR/`date +%F`/
                done
        fi

        listCountHMER=`ls ${InputFilePathHMER} |grep ".gz$"|grep -i cm1eme|wc -l`
        if [ ${listCountHMER} -gt 0 ]
        then
                list=`ls ${InputFilePathHMER} |grep ".gz$"|grep -i cm1eme`
                for file in `echo ${list}`
                do
                        chmod 777 ${InputFilePathHMER}/${file}
                        cp ${InputFilePathHMER}/${file} ${OutputFilePathHMER}
                        mv ${InputFilePathHMER}/${file} ${ProcessedCDRFilePath}/HMER/`date +%F`/
                done
        fi

        listCountHLDR=`ls ${InputFilePathHLDR} |grep ".gz$"|grep -i cm1eld|wc -l`
        if [ ${listCountHLDR} -gt 0 ]
        then
                list=`ls ${InputFilePathHLDR} |grep ".gz$"|grep -i cm1eld`
                for file in `echo ${list}`
                do
                        chmod 777 ${InputFilePathHLDR}/${file}
                        cp ${InputFilePathHLDR}/${file} ${OutputFilePathHLDR}
                        mv ${InputFilePathHLDR}/${file} ${ProcessedCDRFilePath}/HLDR/`date +%F`/
                done
        fi

        sleep 2
done
