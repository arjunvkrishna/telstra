#!/bin/sh
if [ $# -eq 0 ]
	then
	currentDate=$(date +"%F")
	echo "No Date Supplied So counting the files for today i.e., "$currentDate
else
	currentDate=$(date -d "$1" +"%F")
	if [[ -z "$currentDate" ]]
        then
        echo "Please supply the date in YYYY-MM-DD Format i.e.,"$(date +"%F")
        exit
        fi
	echo "Date Supplied is "$currentDate
fi
#date=`date -d "9 days ago" +%F`
timestamp=`date +%s --date="${currentDate} 11:00:00"`
# If condition to check for the Event Ids File Existance
if [ ! -f "EventIds_List_For_Counts.txt" ]; then
    echo "Event File Not Found, Please create a Event File EventIds_List_For_Counts.txt and add the event names for which you wanto to generate the stats"
    exit
fi
inputDateTimeStamp=$(date -d $currentDate +%s)
today_Date=`date +%s --date="$date 00:00:00"`
if [ "$inputDateTimeStamp" -lt "$today_Date" ]; then
sinkFilesPath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/"$currentDate"/Event_Sink_FS1-*"${timestamp}"*.csv"
#fileCount=`ls /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/$currentDate"/"Event_Sink_FS1-*${timestamp}*.csv|wc -l`
else
sinkFilesPath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*"${timestamp}"*.csv"
#fileCount=`ls /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*${timestamp}*.csv|wc -l`
fi
fileCount=`ls $sinkFilesPath|wc -l`
if [ $fileCount -eq 0 ]
then
	echo "No event Files for "$currentDate
#	exit
fi
echo "Event_Id Count for "$currentDate" is"
# For loop to run recursively for all the events in EventIds_List_For_Counts.txt
for i in `cat EventIds_List_For_Counts.txt`
do
#count=$(grep '"'$i'"' /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*${timestamp}*.csv | wc -l)
cd /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/
count=$(grep -r '"'$i'"' --include="Event_Sink_FS1-*${timestamp}*.csv" --exclude-dir={all_old_event_files} . | wc -l)
echo $i" "$count
done

