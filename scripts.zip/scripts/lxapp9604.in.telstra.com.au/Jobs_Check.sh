
to="odcsupport@knowesis.com,rajani.jagga@infosys.com,telstra_athenian@infosys.com,ajith@knowesis.com,dfca2433.knowesis.com@apac.teams.ms, 1391cbfc.knowesis.com@apac.teams.ms,TelstraSalesForcePersonalisationCloudsupport@team.telstra.com,akshai.saju@infosys.com,anjana.ramachandran@infosys.com,mohammedsuhayab.r@infosys.com,bandi.sony@infosys.com,hari.bugatha@infosys.com"


shopt -s expand_aliases
source /home/siftuser/.bashrc

tot_jobs=21
lines=2

c1=`sift descjobs | wc -l`
c2=`sift descjobs | grep -v UP | wc -l`

LOG_FILE=/home/siftuser/kw_utils/corejobsHealth.log


if [ $c1 -ne $tot_jobs ] || [ $c2 -ne $lines ] ; then
echo "UNHEALTHY at $(date)">>$LOG_FILE
echo "Core Jobs Status in UNHEALTHY at $(date). Kindly check!" | mailx -s "[OPOLO] Sift Core Jobs Unhealthy [ALERT!!]" -S smtp=mail.in.telstra.com.au "$to"
else
echo "HEALTHY at $(date)">$LOG_FILE
fi
