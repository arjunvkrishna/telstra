#!/bin/sh

SCRIPT_DIR=/opt/knowesis/sift/core/sift/scripts
SIFT_HOME=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data

DestinationIP=n105938@Inbound.edw.in.telstra.com.au
DestinationPATH=/pr1/data/CSA/prd/ent/inbound/sift/src/land
date_human=`date "+%Y%m%d"`
if [ ! -e ${SCRIPT_DIR}/EventSink_LOGS ]
	then
        mkdir -p -m 777 ${SCRIPT_DIR}/EventSink_LOGS
fi

exec 1>> ${SCRIPT_DIR}/EventSink_LOGS/EventSink_`date +%Y%m`.log
exec 2>> ${SCRIPT_DIR}/EventSink_LOGS/EventSink_`date +%Y%m`.err

echo "[INFO]  `date` | Starting SFTP"
if [ $# -eq 0 ]
	then
	DATE_VALUE=`date --date="1 days ago" "+%Y%m%d"`
        echo "[INFO]  `date` | Date specified = NA, extracting for $DATE_VALUE"
else
	DATE_VALUE=`date --date="1 days ago $1" "+%Y%m%d"`
	echo "[INFO]  `date` | Date specified = $1, extracting for $DATE_VALUE"
fi

offset=`date +%:z|awk -F "+" '{print $2}'`:00
echo "[INFO] `date` | offset : $offset"
timestamp=`date +%s --date="$DATE_VALUE $offset"`
echo "[INFO]  `date` | timestamp : $timestamp"
cd $SIFT_HOME

sequence=1
for file in Event_Sink_FS1-*${timestamp}*;
do
  	count=`wc -l $file | awk '{print $1}'`
        extractTime=`date "+%H%M%S"`
	filename=Event_Sink_${date_human}_$sequence
        echo "$count|$date_human|$extractTime|$filename|$sequence|SIFT|0" > ${filename}.ctl
  echo "[INFO]  `date` | Uploading $filename"
        sftp $DestinationIP << END
                        put ${filename}.ctl
                        put $file ${filename}.csv
                        quit
END
        if [ $? -eq 0  ]; then
                eotFile=${filename}.eot
                touch $eotFile
                sftp $DestinationIP << END
                        put $eotFile
                        quit
END
                echo "[INFO] `date` | $filename uploaded to $DestinationIP" finished
        else
                echo "[INFO] `date` | File transfer failed for $filename"
        fi

  sequence=$((sequence + 1))
done


for file in **/*Event_Sink_FS1-*${timestamp}*;
do
  echo "[INFO] `date` | Copying $file"
  extractTime=`date "+%H%M%S"`
  count=`wc -l $file | awk '{print $1}'`
  filename=Event_Sink_${date_human}_$sequence
  echo "$count|$date_human|$extractTime|$filename|$sequence|SIFT|0" > ${filename}.ctl
 echo "[INFO]  `date` | Uploading $filename"
        sftp $DestinationIP << END
                        put ${filename}.ctl
                        put $file ${filename}.csv
                        quit
END
        if [ $? -eq 0  ]; then
                eotFile=${filename}.eot
                touch $eotFile
                sftp $DestinationIP << END
                        put $eotFile
                        quit
END
                echo "[INFO] `date` | $filename uploaded to $DestinationIP" finished
        else
                echo "[INFO] `date` | File transfer failed for $filename"
        fi
  sequence=$((sequence + 1))
done

echo "[INFO]  `date` | SFTP completed"
echo ""

rm *.eot
rm *.ctl
#SIFT_HOME=/opt/sift/pworkspace/SiFT_Source_data/data
#EVENT_SINK_FILE_DIR=/opt/sift/pworkspace/SiFT_Source_data/data
