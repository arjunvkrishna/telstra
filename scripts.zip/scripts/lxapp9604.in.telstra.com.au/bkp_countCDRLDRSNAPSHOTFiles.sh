#Data Pull Logs Directory
dataPullLogDir="/data/knowesis/sift/core/sift/scripts/ApolloPullLogs"
#If no arguement has passed, this script will run for current day
if [ $# -eq 0 ]
then
currentDate=$(date +"%F")
echo "No Date Supplied So counting the files for today i.e., "$currentDate
else
currentDate=$(date -d "$1" +"%F")
echo "Date Supplied is "$currentDate
fi
#Function for Counting the files for each File Type
function count_files()
{
if [ $(date -d "$1" +"%F") ]
        then
        logFileName="apollo"$2"datapull_"$currentDate".log"
        cd $dataPullLogDir
        if [ -f "$logFileName" ]
                then
                fileCount=$(grep "Apollo_"$2 $logFileName | wc -l)
                echo $2" File Count in "$logFileName " is "$fileCount
        else
                echo "No Files present for "$currentDate
        fi
else
        echo "Please Give the date in YYYY-MM-DD Format"
        exit
fi
}
for i in CDR LDR
#for i in CDR LDR Accounts Customers
do
        count_files $currentDate $i
done
