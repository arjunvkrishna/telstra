#!/bin/sh

SCRIPT_PATH=`pwd`
source $SCRIPT_PATH/envSift.sh;
java -jar /data/knowesis/sift/core/sift/libs/OneTimeHistoryLoader_20151029_RechargeCounts.jar  $PERSIST_ADDRESS $1
