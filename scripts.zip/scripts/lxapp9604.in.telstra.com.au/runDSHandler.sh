#!/bin/bash

SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts/
source ${SCRIPTS_PATH}/envSift.sh
persistAddress=${PERSIST_ADDRESS}

handlerProcessCount=`ps -elf | grep -i DataSourceHandler.jar | grep -v grep |wc -l`
if [ $handlerProcessCount -ne 0 ]
then
	ps -elf | grep -i DataSourceHandler.jar | grep -v grep | kill `awk '{print $4}'`
fi

nohup java -jar ${SIFT_INSTALL_PATH}/core/lib/datasource/DataSourceHandler.jar ${KAFKA_HOST_URL} ${DS_HANDLER_TOPIC} ${DS_HANDLER_CONSUMER_GROUP} ${SIFT_SCRIPT} &
