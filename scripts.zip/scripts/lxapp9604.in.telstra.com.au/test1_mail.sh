#!/bin/ksh

(
echo "To: :shabeena_m@infosys.com"
echo "Subject: Job Status"
echo "Content-Type: text/html"
echo
cat /home/siftuser/PSNM_Scripts/health.html
echo
) |mailx -S smtp=mail.in.telstra.com.au  "Shabeena_M@infosys.com" 
