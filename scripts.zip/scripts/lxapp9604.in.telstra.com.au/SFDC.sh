dt=$(date +"%Y%m%d%H%M")
to="Vivian.Wang@team.telstra.com,Rao.Sanagapalli@team.telstra.com,Pavan.Rao@team.telstra.com,odcsupport@knowesis.com,Manoj_Kumar51@infosys.com,sumit.srivastava02@infosys.com,Twinku.Thomas@team.telstra.com,shinu.antony01@infosys.com,sangeeta@knowesis.com,1391cbfc.knowesis.com@apac.teams.ms,Telstra_Athenian@infosys.com,sonal.winston@infosys.com,akshai.saju@infosys.com,anjana.ramachandran@infosys.com,mohammedsuhayab.r@infosys.com"

DS_NAME=SFDC
LOG_PATH=/home/siftuser/kw_utils
FILE_PATH=/data/processed
output=$( ls /data/processed/SF_BD_V_Account*`date +%Y%m%d`*)
#echo $output
if [ -z "$output" ]
then
echo "NOT_OKAY">$LOG_PATH/$DS_NAME_$dt.log
echo "SFDC Files not received (`date`). Kindly check!" | mailx -s "[OPOLO] SFDC Files Check [ALERT!!]" -S smtp=mail.in.telstra.com.au "$to"
else
echo "OKAY">$LOG_PATH/$DS_NAME_$dt.log
fi
