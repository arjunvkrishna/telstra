#!/bin/sh
 
source /home/siftuser/.bashrc 
SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts/
source ${SCRIPTS_PATH}/envSift.sh

result=`ps -efl |grep  SiftETL.jar | grep -v grep | wc -l`
if [ $result -ge 1 ]
then
        echo "script is running"
else
        echo "script is not running. Initializing ETL Script."
        sh ${SCRIPTS_PATH}/ETLExtract/startETL.sh
fi

