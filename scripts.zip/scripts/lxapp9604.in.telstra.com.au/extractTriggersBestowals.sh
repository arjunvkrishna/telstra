#####################################################################
#####################################################################
# Script name: extractTriggersBestowals.sh
# Description:
# Date       : 9-May-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################

#!/bin/sh

InputFile="/home/siftuser/PSNM_Scripts/EventIds_List_Bestowals.txt"
OutputBestowalsPath="/home/siftuser/PSNM_Scripts/Output_Bestowals"
SinkFilePath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/"

#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo "usage: sh extractTriggersBestowals.sh [<DD-Mmm-YYYY>]"
    echo "This script gets the MSISDNs details for bestowal events"
    echo "as mentioned in the input file from all the sink files for the mentioned date."
    exit
}

#####################################################################
# Function   : set_ValidateParams
# Description: 
#####################################################################
function set_ValidateParams()
{
    #If no arguement has passed, this script will run for current day
    if [ $# -eq 0 ] ;then
        runDate=$(date +"%d-%b-%Y")
        echo "No Date Supplied So counting the files for today i.e., "$runDate
    else
        runDate=$(date -d "$1" +"%d-%b-%Y")
        if [[ -z "$runDate" ]];   then
             echo "Please supply the date in DD-Mmm-YYYY Format i.e.,"$(date +"%d-%b-%Y")
             exit
        fi
        echo "Date Supplied is "$runDate
    fi

    if [ ! -d $OutputBestowalsPath ]; then
        mkdir -p $OutputBestowalsPath
    fi
 
    timestamp=`date +%s --date="${runDate} 11:00:00"`
    # If condition to check for the Event Ids File Existance
    if [ ! -f "$InputFile" ]; then
        echo "Event File Not Found, Please create a Event File $InputFile and add the event names for which you wanto to generate the stats"
        exit
    fi
}


#####################################################################
# Function   : extract_bestowals
# Description: 
#####################################################################
function extract_bestowals ()
{
    OutputBestowalsFile="$OutputBestowalsPath/Triggers_Bestowals_"$i"_"$runDate".csv"
    
    # If loop is to check for the same output file exists,if exists it will remove and creates a new one
    if [ -f $OutputBestowalsFile ] ;then
         rm $OutputBestowalsFile
    fi

    cd $SinkFilePath
    grep -r '"'$i'"' --include="Event_Sink_FS1-*${timestamp}*.csv" --exclude-dir={all_old_event_files} . | awk -F"," '{print $2}' > $OutputBestowalsFile
}


#####################################################################
# Function   : main
# Description: 
#####################################################################
if [ "$*" = "-?" -o "$*" = "-h" ]; then
    usage
    exit 0
fi

# Set paramaters - file locations and paths and validate the input arguments
set_ValidateParams $1

# For loop to run recursively for all the events in the input file 
for i in `cat $InputFile`
do
    extract_bestowals $runDate $i
done
 

