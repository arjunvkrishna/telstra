#!/bin/sh

exec >>  /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBTRdatapull_`date +%F`.log
echo "==================================================================="
echo "Starting to pull Orpheus Files at `date`"
ORPHEUS_USER_ID=sift
ORPHEUS_IP=10.108.198.76
ORPHEUS_SOURCE_FILE_DIRECTORY=/opt/unico/store/sift/event/btr/output
SIFT_INPUT_DIRECTORY=/data/ingest/ORPHEUS
SSH_KEY_PATH=/home/siftuser/ssh_keys/prodsiftcore1

dateTime=`date`
echo "Starting BTR File Pull @ $dateTime" 

if [ -f /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBTRdatapull.ctl ]
then
	echo "BTR Pull already in progress."
	exit
else
	touch /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBTRdatapull.ctl
	fileDate=`date +%d%m%Y --date="yesterday"`

	for file in `ssh ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "ls ${ORPHEUS_SOURCE_FILE_DIRECTORY}/stream*/*ocs_btr*"`
	do
		echo "Copying Files from Orpheus ${file}" 
		exactFileName=`echo ${file}|awk -F'/' '{print $NF}'`
		scp ${ORPHEUS_USER_ID}@${ORPHEUS_IP}:${file} ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart
		mv ${SIFT_INPUT_DIRECTORY}/${exactFileName}.filepart ${SIFT_INPUT_DIRECTORY}/${exactFileName}
		if [ $? -eq 0 ]; then
			ssh ${ORPHEUS_USER_ID}@${ORPHEUS_IP} "rm ${file}"
			echo "Its a File"
		else
			echo "Not A File"
		fi
	done
	dateTime=`date`
	echo "BTR File Pull Compleeted @ $dateTime"
	rm /opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs/orpheusBTRdatapull.ctl
	echo "==================================================================="
fi
