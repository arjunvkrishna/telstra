#!/bin/sh

SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts/
source ${SCRIPTS_PATH}/envSift.sh

result=`ps -efl | grep DataSourceHandler.jar | grep -v grep | wc -l`
if [ $result -ge 1 ]
then
	echo "script is running"
else
        echo "script is not running. Initializing DS Handler."
        ${SCRIPTS_PATH}/runDSHandler.sh
fi
