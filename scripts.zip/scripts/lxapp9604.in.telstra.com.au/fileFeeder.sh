#!/bin/bash

SCRIPT_HOME=$(dirname $(cd `dirname $0` && pwd))
DATE_LOG=$(date +"%Y%m")
LOG_FILE=$SCRIPT_HOME/log/$(basename $BASH_SOURCE .sh)_$DATE_LOG.log
JOB_NAME=DISASTER_BONUS

#where the file should be picked up from
SOURCE_DIRECTORY=/data/darin
SOURCE_FILENAME=strategic_prepaid_disasterbonus_$(date --date="1 days ago" +"%Y%m%d").txt
TEMP_FILE=$SOURCE_DIRECTORY/tmp

#backup / housekeeping config
BACKUP_DIRECTORY=/data/processed
FILE_RETENTION_PERIOD=3

#where should the file be moved
DESTINATION_DIRECTORY=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/DISASTER_BONUS/

#extension of eot file, if you leave it blank the script will not look for any eot file. If you configure a value, then the script will pick up the file regardless of the age of the file
CHECK_FOR_EOT=

#minimum age of the file, sometimes when there is no eot, it is best to look for a file older than a certain time. The value should be configured as follows: +2 means 2 mins, +10 means 10 mins so an and so forth. If you do not configure a value then no age check will be applied
MIN_AGE=+5
FILE_DELIMITER=|
SORTING_COLUMN=1

#logger function info
function logger_info {
    echo "$(date) | INFO  | $JOB_NAME | $1" >> $LOG_FILE
}

#logger function error
function logger_error {
    echo "$(date) | ERROR | $JOB_NAME | $1" >> $LOG_FILE
}

#logger function warn
function logger_warn {
    echo "$(date) | WARN  | $JOB_NAME | $1" >> $LOG_FILE
}

#function for housekeeping
function housekeeping {
    find $BACKUP_DIRECTORY -maxdepth 1 -type f -name $SOURCE_FILENAME -mtime +${FILE_RETENTION_PERIOD} -delete;
}

if [ ! -f "$SOURCE_DIRECTORY/$SOURCE_FILENAME" ];
then
    housekeeping
    logger_error "No disaster file found, housekeeping completed with status : $?. The script will exit now."
    exit 1
else
    logger_info "Disaster File found, proceeding further."
    #check if the CHECK_FOR_EOT is configured
    if [ ! -z $CHECK_FOR_EOT ]
    then
        eoePattern=${SOURCE_FILENAME%%.*}.$CHECK_FOR_EOT
        eoeFile=$SOURCE_PATH/$eoePattern
        logger_info "Checking for the eot File."
        if [ ! -f $eoeFile ];
        then
            logger_error "no eot file found, the script will exit now"
            exit 1
        else
            cp $SOURCE_DIRECTORY/$SOURCE_FILENAME $BACKUP_DIRECTORY
            logger_info "raw file backup completed with status : $?"
            logger_info "going to sort"
            sort -u -t '|' -k 1,1 $SOURCE_DIRECTORY/$SOURCE_FILENAME > $TEMP_FILE
            logger_info "sorting done with status : $?"
            mv $TEMP_FILE $SOURCE_DIRECTORY/$SOURCE_FILENAME
            mv $SOURCE_DIRECTORY/$SOURCE_FILENAME $DESTINATION_DIRECTORY
            logger_info "moved $SOURCE_DIRECTORY/$SOURCE_FILENAME to $DESTINATION_DIRECTORY with status : $?"
            housekeeping
            logger_info "housekeeping completed with status : $?"
            exit 0
        fi
    fi
    #check for age of the file
    if [ ! -z $MIN_AGE ]
    then
        logger_info "Checking age of the file"
        if [ ! $(find $file -mmin $MIN_AGE) ]
        then
            logger_error "The actual file is not older than the configured $MIN_AGE, the script will exit now"
            exit 1
        else
            cp $SOURCE_DIRECTORY/$SOURCE_FILENAME $BACKUP_DIRECTORY
            logger_info "raw file backup completed with status : $?"
            logger_info "going to sort"
            sort -u -t '|' -k 1,1 $SOURCE_DIRECTORY/$SOURCE_FILENAME > $TEMP_FILE
            logger_info "sorting done with status : $?"
            mv $TEMP_FILE $SOURCE_DIRECTORY/$SOURCE_FILENAME
            mv $SOURCE_DIRECTORY/$SOURCE_FILENAME $DESTINATION_DIRECTORY
            logger_info "moved $SOURCE_DIRECTORY/$SOURCE_FILENAME to $DESTINATION_DIRECTORY with status : $?"
            housekeeping
            logger_info "housekeeping completed with status : $?"
            exit 0
        fi
    fi
fi