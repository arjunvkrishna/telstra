#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts/HealthCheck/Bundle_Monitoring
LOG_FILE=$MONITORING_PATH/Input_Folder_File_Check_`date +%Y%m%d%H`.log
SIFT_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input

echo "`date '+%F %T'` | INFO | File Count Checks For Various File Type in Input Folder Started" >> $LOG_FILE
echo "" >> $LOG_FILE
for FileType in BAR MER OLDR BTR UDR BUNDLE_SNAPSHOT MOB_ACTIVITY MODEL_SCORE
do
echo "`date '+%F %T'` | INFO | Checking For File Type: $FileType" >> $LOG_FILE
echo "" >> $LOG_FILE
cd $SIFT_INPUT_PATH/$FileType
ls -l  >> $LOG_FILE
echo "`date '+%F %T'` | INFO | File Count Check For $FileType Completed, File Count = `ls -1 | wc -l`" >> $LOG_FILE
echo "" >> $LOG_FILE
done
echo "`date '+%F %T'` | INFO | File Count Checks For Various File Type in Input Folder Completed" >> $LOG_FILE

emailSubject="SIFT EMAIL ALERT "\!\!\!" Input Folder File Check - `date +%F`, Hour - `date +%H` "
toAddressArray=('Shabeena_M@infosys.com' 'Sowmya.T02@infosys.com' 'Nirmal_Thekkekkota@infosys.com')
#toAddressArray=('Nirmal_Thekkekkota@infosys.com')
cat $LOG_FILE  | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"


