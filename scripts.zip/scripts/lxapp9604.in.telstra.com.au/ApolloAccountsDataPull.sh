#!/bin/sh

exec >>  /opt/knowesis/sift/core/sift/scripts/ApolloPullLogs/apolloAccountsdatapull_`date +%F`.log
echo "==================================================================="
echo "Starting to pull Apollo Files at `date`"
APOLLO_USER_ID=sift
APOLLO_IP=asapnrmgt1-b.ain.nexus.telstra.com.au
APOLLO_SOURCE_FILE_DIRECTORY=/ETL/OUTPUT/intelestage
SIFT_INPUT_DIRECTORY=/data/ingest/APOLLO
SSH_KEY_PATH=/home/siftuser/ssh_keys/prodsiftcore1

dateTime=`date`
echo "Starting Accounts File Pull @ $dateTime" 

if [ -f /opt/knowesis/sift/core/sift/scripts/ApolloPullLogs/apolloAccountsdatapull.ctl ]
then
	echo "Accounts Pull already in process."
	exit
else
	touch /opt/knowesis/sift/core/sift/scripts/ApolloPullLogs/apolloAccountsdatapull.ctl
	fileDate=`date +%d%m%Y --date="yesterday"`

	for file in `ssh -i ${SSH_KEY_PATH} ${APOLLO_USER_ID}@${APOLLO_IP} "ls ${APOLLO_SOURCE_FILE_DIRECTORY}/*Accounts*|grep -v delete"`
	do
		echo "Deleting Files from Apollo ${file}" 
		#scp -i ${SSH_KEY_PATH} ${APOLLO_USER_ID}@${APOLLO_IP}:${file} ${SIFT_INPUT_DIRECTORY}
		ssh -i ${SSH_KEY_PATH} ${APOLLO_USER_ID}@${APOLLO_IP} "rm ${file}"
		if [ $? -eq 0 ]; then
			echo "Deleting File ${file} completed."
		else
			echo "Error while deleting file ${file} ."
		fi
	done
	dateTime=`date`
	echo "Accounts File Pull Compleeted @ $dateTime"
	rm /opt/knowesis/sift/core/sift/scripts/ApolloPullLogs/apolloAccountsdatapull.ctl
	echo "==================================================================="
fi
