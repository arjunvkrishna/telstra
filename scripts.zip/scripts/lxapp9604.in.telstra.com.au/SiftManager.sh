#!/bin/bash

#source ~/.bashrc
source /home/siftuser/.bashrc
source ${SIFT_INSTALL_PATH}/core/sift/scripts/envSift.sh

persistAddress=${PERSIST_ADDRESS}
if [ $# -lt 1 ]
then
	echo "USAGE SiftManager.sh {command}"
	exit
fi

command=$1

if [ ${command} == "startDS" ] || [ ${command} == "stopDS" ]
then
	if [ $# -lt 2 ]
	then
		echo "USAGE SiftManager.sh startDS/stopDS {sourceName}"
        	exit
	fi
fi


if [ ${command} == "failoverHost" ] || [ ${command} == "failoverCoreProcess" ]
then
	if [ $# -lt 4 ]
        then
		echo "USAGE SiftManager.sh failoverHost/failoverCoreProcess {hostList} {processIdList} {indexList}"
		exit
	fi
fi


submit_ds()
{
	thisSource=$1
	echo "Submitting Datasource ${thisSource}"
        echo "Bringing DataSource doc from Persist"
        sourceObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} "DATA_SOURCE_${thisSource}" 2> /dev/null |awk -F"_____" '{print $2}'`
	echo $sourceObj
        #sourceObj=10.0.16.4,10.0.16.4
        MainServer=`echo ${sourceObj}|cut -d',' -f1`
 	FailoverServer=`echo ${sourceObj}|cut -d',' -f2`
        MainServerStatus=`ping ${MainServer} -c 5 |grep ' 0% packet loss'|wc -l`
        PID=""
        usedHost=""
        if [ ${MainServerStatus} -eq 0 ]
        then
              echo "Server ${MainServer} is not accessible, trying to restart on ${FailoverServer} now"
              failoverServerStatus=`ping ${FailoverServer} -c 5|grep ' 0% packet loss'|wc -l`         
              if [ ${failoverServerStatus} -eq 0 ]
              then
                    echo "The server ${FailoverServer} is also not accessible, Not able to submit job : ${thisSource}"
                    exit
              else
                    echo "Submitting job : ${thisSource} on server ${FailoverServer}"
              	    PID=`ssh -q ${FailoverServer} 'export DS_NAME='${thisSource}'; export ELASTICSEARCH_SIFT_LOGS_INDEX='${elasticSearchDSLogsIndex}'; export CONTAINER_ID='${thisSource}'; export HOSTNAME='${FailoverServer}'; export ELASTICSEARCH_URL='${elasticSearchUrl}'; export ELASTICSEARCH_SIFT_BADRECORDS_INDEX='${elasticSearchBadRecIndex}'; export ELASTICSEARCH_SIFT_FILREPORT_INDEX='${elasticSearchFileReportIndex}'; export LOG_LEVEL='${logLevel}'; export LOG_TYPE='${logType}'; export LOG_PATH='${logPath}'; nohup java -Xms'${DSMinHeapSize}' -Xmx'${DSMaxHeapSize}' -Dlog4j.configurationFile='${log4jXMLPath}' -cp '${classPath}' '${dataSourceClassName}' '${persistAddress}' '${thisSource}' 0 '${persistClient}' '${persistPassword}' > '${logPath}'/siftcore_'${thisSource}'.stderrout 2>&1 & echo $!'`
                    usedHost=${FailoverServer}
              fi
        else
              echo "Submitting job : ${thisSource} on server ${MainServer}"
              PID=`ssh -q ${MainServer} 'export DS_NAME='${thisSource}'; export ELASTICSEARCH_SIFT_LOGS_INDEX='${elasticSearchDSLogsIndex}'; export CONTAINER_ID='${thisSource}'; export HOSTNAME='${MainServer}'; export ELASTICSEARCH_URL='${elasticSearchUrl}'; export ELASTICSEARCH_SIFT_BADRECORDS_INDEX='${elasticSearchBadRecIndex}'; export ELASTICSEARCH_SIFT_FILREPORT_INDEX='${elasticSearchFileReportIndex}'; export LOG_LEVEL='${logLevel}'; export LOG_TYPE='${logType}'; export LOG_PATH='${logPath}'; nohup java -Xms'${DSMinHeapSize}' -Xmx'${DSMaxHeapSize}' -Dlog4j.configurationFile='${log4jXMLPath}' -cp '${classPath}' '${dataSourceClassName}' '${persistAddress}' '${thisSource}' 0 '${persistClient}' '${persistPassword}' > '${logPath}'/siftcore_'${thisSource}'.stderrout 2>&1 & echo $!'`
              usedHost=${MainServer}
        fi
	
	grep -v "^${thisSource}," ${sourceToDeployPath} > ${sourceToDeployPath}.tmp
        echo "${thisSource},${usedHost}_${PID}" >> ${sourceToDeployPath}.tmp
        mv ${sourceToDeployPath}.tmp ${sourceToDeployPath}

}

stop_ds()
{
	thisSource=$1
	echo "Stopping Data Source ${thisSource}"
	if [ ! -f ${sourceToDeployPath} ]
	then
		echo "Datasource ${thisSource} was already Stopped"
		exit
	fi
		
        thisSourceConfig=`cat ${sourceToDeployPath}|grep "^${thisSource},"|cut -d',' -f2`

        if [ -z ${thisSourceConfig} ]
        then
                echo "Datasource ${thisSource} was already Stopped"
                exit
        fi

        Host=`echo ${thisSourceConfig}|cut -d'_' -f1`
        PID=`echo ${thisSourceConfig}|cut -d'_' -f2`
        echo "Stopping process ${PID} on server ${Host}"
        ssh -q ${Host} "kill -9 ${PID}"
        if [ `echo $?` -ne 0 ]
        then
                echo "Not able to stop process ID ${PID} on server ${Host}, Please kill the process manually on that server or Check the logs if process not found"
        else
                echo "Datasource ${thisSource} is stopped now"
        fi

}


if [ $command == "startPanda" ]
then
	echo "************** Going to Start Sift Jobs **************"

	echo "Bringing Config from Persist"
	configObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} Config.cfg 2> /dev/null |awk -F"_____" '{print $2}'`
	#configObj=GENERIC_PERSIST_ADDRESS^http://sift-persist:8091~GENERIC_CORE_HOST_LIST^indosat,streams~GENERIC_CORE_HOST_LIST_COUNT^2,1~DS_INTEGRATION_INTEGRATION_POINT^KAFKA
	coreHostList=`echo $configObj|sed 's/~/\n/g'|grep -w GENERIC_CORE_HOST_LIST|cut -d'^' -f2`

	coreHostListCount=`echo $configObj|sed 's/~/\n/g'|grep -w GENERIC_CORE_HOST_LIST_COUNT|cut -d'^' -f2`
	coreHostListCountArr=(`echo $coreHostListCount|sed 's/,/ /g'`)

	hostNo=0
	nslookup=""
	nWorkerId=0
	for host in `echo ${coreHostList}|sed 's/,/ /g'`
	do
		hostStatus=`ping ${host} -c 5 |grep ' 0% packet loss'|wc -l`
		if [ ${hostStatus} -eq 0 ]
		then
			echo "${host} is not accessible, please check panda configuration. Exiting Start Process"
			${SIFT_INSTALL_PATH}/core/sift/scripts/SiftManager.sh stopPanda
			exit 1
		fi
		pandaCount=1
		while [ 1 ]
		do
			if [ ${pandaCount} -le ${coreHostListCountArr[${hostNo}]} ]
			then
				echo "Running panda no. `expr ${nWorkerId} + 1` on host ${host}"
				coreLogIndex=`expr $nWorkerId + 1`	
				PID=`ssh -q ${host} 'export DS_NAME='${coreLogIndex}'; export ELASTICSEARCH_SIFT_LOGS_INDEX='${elasticSearchCoreLogsIndex}'; export CONTAINER_ID='${host}'; export HOSTNAME='${host}'; export ELASTICSEARCH_URL='${elasticSearchUrl}'; export ELASTICSEARCH_SIFT_BADRECORDS_INDEX='${elasticSearchBadRecIndex}'; export ELASTICSEARCH_SIFT_FILREPORT_INDEX='${elasticSearchFileReportIndex}'; export LOG_LEVEL='${logLevel}'; export LOG_TYPE='${logType}'; export LOG_PATH='${logPath}';nohup java -Xms'${pandaMinHeapSize}' -Xmx'${pandaMaxHeapSize}' '${xARGS}' -Dlog4j.configurationFile=file:'${log4jXMLPath}' -cp '${classPath}' '${pandaClassName}' '${persistAddress}' '${hostName}' '${cacheSize}' '${seekToBeginningFlag}' '${maxPollRecords}' '${PandaSleepTime}' '${persistClient}' '${persistPassword}' '${nWorkerId}' > '${logPath}'/siftcore_'${coreLogIndex}'.stderrout 2>&1 & echo $!'`

#				echo "ssh -q ${host} 'export DS_NAME='${coreLogIndex}'; export ELASTICSEARCH_SIFT_LOGS_INDEX='${elasticSearchCoreLogsIndex}'; export CONTAINER_ID='${host}'; export HOSTNAME='${host}'; export ELASTICSEARCH_URL='${elasticSearchUrl}'; export ELASTICSEARCH_SIFT_BADRECORDS_INDEX='${elasticSearchBadRecIndex}'; export ELASTICSEARCH_SIFT_FILREPORT_INDEX='${elasticSearchFileReportIndex}'; export LOG_LEVEL='${logLevel}'; export LOG_TYPE='${logType}'; export LOG_PATH='${logPath}';nohup java -Xms'${pandaMinHeapSize}' -Xmx'${pandaMaxHeapSize}' -Dlog4j.configurationFile=file:'${log4jXMLPath}' -cp '${classPath}' '${pandaClassName}' '${persistAddress}' '${hostName}' '${cacheSize}' '${seekToBeginningFlag}' '${maxPollRecords}' '${PandaSleepTime}' '${nWorkerId}' > '${logPath}'/siftcore_'${coreLogIndex}'.stderrout 2>&1 & echo $!'"
				if [ ${nWorkerId} -eq 0 ]
				then
					nslookup="${nslookup}${host}_${PID}"
				else
					nslookup="${nslookup},${host}_${PID}"
				fi

				java -cp ${classPath} ${registryKeeperClassName} ${persistAddress} "${host}_${PID}" "${nslookup}" 2> /dev/null|grep -v 'Initialised CouchClient'
				pandaCount=`expr $pandaCount + 1`
				nWorkerId=`expr $nWorkerId + 1`
			else
				break
			fi
		done
		hostNo=`expr $hostNo + 1`
	done
elif [ $command == "stopPanda" ]
then
	
	echo "Bringing Registry from Persist"
	registryObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} Registry 2> /dev/null |awk -F"_____" '{print $2}'`
	#registryObj="10.0.16.4_22213,10.0.16.4_22214,10.0.16.5_1323,10.0.16.5_1324"

	for thisRegistry in `echo ${registryObj}|sed 's/,/ /g'`
	do
		hostIP=`echo ${thisRegistry}|cut -d'_' -f1`
		PID=`echo ${thisRegistry}|cut -d'_' -f2`
		echo "Stopping process ${PID} on server ${hostIP}"
		date=`date +%s`
		logFileCount=`ssh -q ${hostIP} "ls ${logPath} | grep siftcore_ | wc -l"`
		ssh -q ${hostIP} "kill -9 ${PID}; if [ ${logFileCount} -gt 0 ]; then tar -czf ${logPath}_${date}.tar.gz ${logPath}/siftcore_*; mv ${logPath}_${date}.tar.gz ${logPath}/archive/; rm ${logPath}/siftcore_*; fi"
		#ssh -q ${hostIP} "if [ `ls ${logPath} | grep siftcore_ | wc -l` -gt 0 ]; then tar -czf ${logPath}_${date}.tar.gz ${logPath}/siftcore_*; mv ${logPath}_${date}.tar.gz ${logPath}/archive/; rm ${logPath}/siftcore_*; fi; kill -9 ${PID}"

		if [ `echo $?` -ne 0 ]
		then
			echo "Not able to stop process ID ${PID} on server ${hostIP}, Please kill the process manually on that server or check the logs if process not found"
		fi
	done
	
	echo "Cleaning Registry After Stoping Sift Services"
	java -cp ${classPath} ${registryKeeperClassName} ${persistAddress} "CLEAN" "" 2> /dev/null|grep -v 'Initialised CouchClient' 

elif [ $command == "startDS" ]
then
	sourceName=$2

	if [ ${sourceName} == "ALL" ]
	then
	
		echo "Starting Data Sources"
		for i in `cat ${sourceToDeployPath}|cut -d',' -f1`
		do
			submit_ds ${i}
		done
		echo "Started All Data Sources"
	else	
		submit_ds ${sourceName}
	fi

elif [ $command == "stopDS" ]
then
	sourceName=$2

	if [ ${sourceName} == "ALL" ]
        then

                echo "Stoping Data Sources"
                for i in `cat ${sourceToDeployPath}|cut -d',' -f1`
                do
                        stop_ds ${i}
                done
                echo "Stopped All Data Sources"
        else
		stop_ds ${sourceName}
		grep -v "^${sourceName}," ${sourceToDeployPath} > ${sourceToDeployPath}.tmp
        	mv ${sourceToDeployPath}.tmp ${sourceToDeployPath}
	fi

elif [ $command == "failoverHost" ]
then
	hostFailed=`echo $2|cut -d',' -f1`
	processIdList=$3
	indexList=$4

	echo "Failing over node ${hostFailed}"
	echo "Bringing Config from Persist"
        configObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} Config.cfg 2> /dev/null |awk -F"_____" '{print $2}'`
	coreHostList=`echo $configObj|sed 's/~/\n/g'|grep -w GENERIC_CORE_HOST_LIST|cut -d'^' -f2`
	workingCoreHostListArr=(`echo $coreHostList|sed 's/,/\n/g'|grep -wv "${hostFailed}"`)
	indexListArr=(`echo ${indexList}|sed 's/,/ /g'`)
	count=0
	index=0
	for thisProces in `echo ${processIdList}|sed 's/,/ /g'`
	do
		host=${workingCoreHostListArr[${count}]}
		echo "Failing over panda no. `expr ${index} + 1` on host ${host}"

		coreLogIndex=`expr ${indexListArr[${index}]} + 1`	
                PID=`ssh -q ${host} 'export DS_NAME='${coreLogIndex}'; export ELASTICSEARCH_SIFT_LOGS_INDEX='${elasticSearchCoreLogsIndex}'; export CONTAINER_ID='${host}'; export HOSTNAME='${host}'; export ELASTICSEARCH_URL='${elasticSearchUrl}'; export ELASTICSEARCH_SIFT_BADRECORDS_INDEX='${elasticSearchBadRecIndex}'; export ELASTICSEARCH_SIFT_FILREPORT_INDEX='${elasticSearchFileReportIndex}'; export LOG_LEVEL='${logLevel}'; export LOG_TYPE='${logType}'; export LOG_PATH='${logPath}'; nohup java -Xms'${pandaMinHeapSize}' -Xmx'${pandaMaxHeapSize}' -Dlog4j.configurationFile='${log4jXMLPath}' -cp '${classPath}' '${pandaClassName}' '${persistAddress}' '${hostName}' '${cacheSize}' '${seekToBeginningFlag}' '${maxPollRecords}' '${PandaSleepTime}' '${persistClient}' '${persistPassword}' '${indexListArr[${index}]}' > '${logPath}'/siftcore_'${coreLogIndex}'.stderrout 2>&1 & echo $!'`

		java -cp ${classPath} ${registryKeeperClassName} ${persistAddress} "${host}_${PID}" "" ${indexListArr[${index}]} 2> /dev/null|grep -v 'Initialised CouchClient'
		
		count=`expr ${count} + 1`
		if [ ${count} -ge ${#workingCoreHostListArr[@]} ]
		then
			count=0
		fi
		index=`expr ${index} + 1`
	done
	
	echo "Failover of ${hostFailed} is completed"
elif [ $command == "failoverCoreProcess" ]
then
	host=$2
	index=$4

	echo "Failing over process $3 on ${host}"
	coreLogIndex=`expr ${index} + 1`
	PID=`ssh -q ${host} 'export DS_NAME='${coreLogIndex}'; export ELASTICSEARCH_SIFT_LOGS_INDEX='${elasticSearchCoreLogsIndex}'; export CONTAINER_ID='${host}'; export HOSTNAME='${host}'; export ELASTICSEARCH_URL='${elasticSearchUrl}'; export ELASTICSEARCH_SIFT_BADRECORDS_INDEX='${elasticSearchBadRecIndex}'; export ELASTICSEARCH_SIFT_FILREPORT_INDEX='${elasticSearchFileReportIndex}'; export LOG_LEVEL='${logLevel}'; export LOG_TYPE='${logType}'; export LOG_PATH='${logPath}'; nohup java -Xms'${pandaMinHeapSize}' -Xmx'${pandaMaxHeapSize}' -Dlog4j.configurationFile='${log4jXMLPath}' -cp '${classPath}' '${pandaClassName}' '${persistAddress}' '${hostName}' '${cacheSize}' '${seekToBeginningFlag}' '${maxPollRecords}' '${PandaSleepTime}' '${persistClient}' '${persistPassword}' '${index}' > '${logPath}'/siftcore_'${coreLogIndex}'.stderrout 2>&1 & echo $!'`

        java -cp ${classPath} ${registryKeeperClassName} ${persistAddress} "${host}_${PID}" "" ${index} 2> /dev/null|grep -v 'Initialised CouchClient'

	echo "Failover of core process is completed"

fi
