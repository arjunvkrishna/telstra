#!/bin/sh

################################################################################
################################################################################
########                                                                ########
########        >This script is used to monitor native sift!!           ########
########                                                                ########
################################################################################
################################################################################

source ~/.bashrc
SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts/
source ${SCRIPTS_PATH}/envSift.sh

persistAddress=${PERSIST_ADDRESS}
#######################################################################################################################################
############################################################FUNCTIONS##################################################################
#######################################################################################################################################


# This function monitors Core Hosts and all the core processes running on those hosts.

CURRENT_DATE=`date '+%Y%m%d'`
function log {
    echo "[`date`] : $1" >> ${monitoringLogPath}/SiftMonitorLogs_${CURRENT_DATE}
}


function verify_process_failure {
	echo ""
}

func_monitor_hosts_core()
{
	log "INFO : ************** Monitoring Host Servers And Core Processes at `date` **************"
        log "INFO : Bringing Config from Persist"

        configObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} Config.cfg 2> /dev/null | awk -F"_____" '{print $2}'`
        coreHostList=`echo $configObj|sed 's/~/\n/g'|grep -w GENERIC_CORE_HOST_LIST|cut -d'^' -f2`

	log "INFO : All Core Hosts: " $coreHostList

	currentHostFailures=0
	currentHealthyHosts=","
	for host in `echo ${coreHostList}|sed 's/,/ /g'`
	do
                thisServerStatus=`ping ${host} -c 5 |grep ' 0% packet loss'|wc -l`
                if [ ${thisServerStatus} -le 0 ]
                then
			currentHostFailures=`expr ${currentHostFailures} + 1`
			if [ ${currentHostFailures} -gt ${maxHostFailuresAllowed} ]
			then
				log "ERROR : Total Hosts Failures exceeds maximum host failure allowed. Stopping the application"
			 	${SCRIPTS_PATH}/SiftManager.sh stop
				exit	
			fi
		else
			currentHealthyHosts=${currentHealthyHosts}${host}","
		fi		
	done

        for host in `echo ${coreHostList}|sed 's/,/ /g'`
        do
		thisServerStatus=`ping ${host} -c 5 |grep ' 0% packet loss'|wc -l`
	        if [ ${thisServerStatus} -gt 0 ]
        	then
        		registryObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} Registry 2> /dev/null |awk -F"_____" '{print $2}'`
        		log "INFO : Current Core Registry: "  $registryObj
			currentIndex=0
			log "INFO : Server ${host} is healthy. Verifying the Core processes on this host."
			for i in `echo $registryObj | sed 's/,/ /g'`
                        do
                                thisHost=`echo $i | cut -d'_' -f1`
                                thisPID=`echo $i | cut -d'_' -f2`
                                if [ ${thisHost} == ${host} ]
                                then
					thisProcessCount=`ssh ${thisHost} "ps -elf | grep -w ${thisPID} | grep -v grep | wc -l"`
					if [ ${thisProcessCount} -eq 0 ]
					then
                                        	log "ERROR : Process id ${thisPID} on host: ${thisHost} is not running"
						${SCRIPTS_PATH}/SiftManager.sh failoverCoreProcess ${thisHost} ${thisPID} ${currentIndex}
					else
                                        	log "INFO : Process ${thisPID} on host: ${thisHost} found healthy"
					fi
				fi
				currentIndex=`expr ${currentIndex} + 1`
			done
		else
			echo "Server ${host} is unhealthy"
			allFailedHosts=""
			allFailedPIDs=""
			allFailedIndexes=""
			currentIndex=0
			failHostIndex=0
        		registryObj=`java -cp ${classPath} ${configCfgClassName} ${persistAddress} Registry 2> /dev/null |awk -F"_____" '{print $2}'`
        		log "INFO : Current Core Registry: "  $registryObj
		        for i in `echo $registryObj | sed 's/,/ /g'`
			do
				thisHost=`echo $i | cut -d'_' -f1`
				thisPID=`echo $i | cut -d'_' -f2`
				if [ ${thisHost} == ${host} ]
				then
					log "WARN : Failed host: ${thisHost}, PID: ${thisPID}"
					if [ ${failHostIndex} -gt 0  ]
					then
						allFailedHosts="${allFailedHosts},${thisHost}"
						allFailedPIDs="${allFailedPIDs},${thisPID}"
						allFailedIndexes="${allFailedIndexes},${currentIndex}"
					else
						allFailedHosts="${thisHost}"
						allFailedPIDs="${thisPID}"
                                                allFailedIndexes="${currentIndex}"
					fi
					failHostIndex=`expr ${failHostIndex} + 1`
				fi
				currentIndex=`expr ${currentIndex} + 1`
			done
			if [ ! -z ${allFailedPIDs} ]
			then
				log "INFO : ALL FAILURES: ${allFailedHosts} ${allFailedPIDs} ${allFailedIndexes}"
				${SCRIPTS_PATH}/SiftManager.sh failoverHost ${allFailedHosts} ${allFailedPIDs} ${allFailedIndexes}
			else
				log "INFO : No core processes running on failed over node ${host}"
			fi
		fi
	done
}



# This function monitors the data source failures
func_monitor_ds()
{
	log "INFO : ************** Monitoring DataSources at `date` **************"
	for thisDS in `cat $sourceToDeployPath`
	do
		thisDSName=`echo ${thisDS} | awk -F',' '{print $1}'`
		thisDSHost_PID=`echo ${thisDS} | awk -F',' '{print $2}'`
		thisDSHost=`echo ${thisDSHost_PID} | awk -F'_' '{print $1}'`
		thisDSPID=`echo ${thisDSHost_PID} | awk -F'_' '{print $2}'`
		if [[ ${currentHealthyHosts} ==  *",${thisDSHost},"* ]]
		then 
			thisDSProcessCount=`ssh ${thisDSHost} "ps -elf | grep -w ${thisDSPID} | grep -v grep | wc -l"`
                	if [ ${thisDSProcessCount} -eq 0 ]
              		then
				log "WARN : The Data source ${thisDSName} is currently not running. Restarting the Data source now."
                        	${SCRIPTS_PATH}/SiftManager.sh startDS ${thisDSName}
				log "INFO : The Data source ${thisDSName} is restarted successfully."
			else
				log "INFO : Datasource ${thisDSName} found healthy on node ${thisDSHost}"
                	fi
		else
			thisServerStatus=`ping ${thisDSHost} -c 5 |grep ' 0% packet loss'|wc -l`
	                if [ ${thisServerStatus} -le 0 ]
        	        then
                	       	log "WARN : The Host ${thisDSHost} for Data source ${thisDSName} is currently not healthy. Restarting the Data source now."
                                ${SCRIPTS_PATH}/SiftManager.sh startDS ${thisDSName} 
				log "INFO : The Data source ${thisDSName} is restarted successfully."
			else
				thisDSProcessCount=`ssh ${thisDSHost} "ps -elf | grep -w ${thisDSPID} | grep -v grep | wc -l"`
                        	if [ ${thisDSProcessCount} -eq 0 ]
                      	  	then
                                	log "WARN : The Data source ${thisDSName} is currently not running. Restarting the Data source now."
                                	${SCRIPTS_PATH}/SiftManager.sh startDS ${thisDSName}
					log "INFO : The Data source ${thisDSName} is restarted successfully."
                        	else
                                	log "INFO : Datasource ${thisDSName} found healthy on node ${thisDSHost}"
                        	fi
			fi
		fi
	done	
}



log "INFO : ############################### MONITORING STARTED ###############################"
if [ ! -f ${mgmtHostFile} ]
then
        log "INFO : ${mgmtHostFile} does not exists. Creating a new Management file"
        echo `hostname` > ${mgmtHostFile}
fi


MGMTHOST=`cat ${mgmtHostFile}`
if [ ${MGMTHOST} != `hostname` ]
then
        mgmtServerStatus=`ping ${MGMTHOST} -c 5 |grep ' 0% packet loss'|wc -l`
        if [ ${mgmtServerStatus} -gt 0 ]
        then
                log "INFO : ${MGMTHOST} is the current Management Node. Monitoring from this Node will be ended."
                exit
        else
                rm ${mgmtHostFile}
                log "WARN : `hostname` is taking over as Management host, since ${MGMTHOST} is not available."
                echo `hostname` > ${mgmtHostFile}
        fi
else
        log "INFO : Current management host is: ${MGMTHOST}"
fi



if [ -f ${SIFT_MANAGER_PID_FILE} ]
then
        log "INFO : Monitoring Script will exit as SiftManager.sh is running"
        exit
fi

func_monitor_hosts_core
func_monitor_ds
