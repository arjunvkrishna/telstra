#!/bin/sh

exec >>  /opt/knowesis/sift/core/sift/scripts/LOGS/batchfile_status.log
echo "==================================================================="


while [ `ls /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/BATCH_TRIGGER|wc -l` == 1 ]
do
	sleep 600
done
dateTime=`date`
echo "File processsing finished at : "$dateTime
exit
