#!/bin/bash

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# title :cleanupHendrixProcessedData.sh
# description :This script cleanup the archived hendrix DS
# author :SIFT Team
# version :1.0.0
# usage :bash cleanupHendrixProcessedData.sh
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

SCRIPT_PATH=`echo $0|sed 's/cleanupHendrixProcessedData.sh//g'`

#Sourcing envSift.sh
source ${SCRIPT_PATH}envSift.sh

#Log configs
LOG_DIR=$HOUSEKEEPING_ARCHIVE_PATH/logs
LOG_FILE=$LOG_DIR/cleanup_`date +%F`.log

#date config
cleanup_date=`date +%F -d "10 day ago"`

#Logger Function
log() 
{
	echo "$(date) | $1" >> $LOG_FILE
}

#cleanup function
Remove_process()
{
	rm -rf $2/$1
	log "INFO | cleanup completed for $i dated on ${cleanup_date}"
}

log "INFO | starting cleanup for Hendrix DS archived files "

#looping over DS(HMER,HBAR,HUDR,HLDR) for cleanup
for i in HMER HBAR HUDR HLDR
do
   Remove_process $i/$cleanup_date $HOUSEKEEPING_ARCHIVE_PATH &
done

log "INFO | cleanup completed"
