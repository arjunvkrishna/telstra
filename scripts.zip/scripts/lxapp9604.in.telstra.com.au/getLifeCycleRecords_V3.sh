#! /bin/bash

#Archive Paths
SCRIPT_PATH=/home/siftuser/PSNM_Scripts
MER_ARCHIVE=/data/ARCHIVE/MER
BAR_ARCHIVE=/data/ARCHIVE/BAR
OLDR_ARCHIVE=/data/ARCHIVE/OLDR
BTR_ARCHIVE=/data/ARCHIVE/BTR
UDR_ARCHIVE=/data/ARCHIVE/UDR
PROFILE_ARCHIVE=/data/ARCHIVE/PROFILE
MODELSCORE_ARCHIVE=/data/ARCHIVE/MODEL_SCORE

INPUT_FILE=$1
while read LINE;
do

MSISDN=`echo $LINE | cut -d, -f1`
ACT_DATE=`echo $LINE | cut -d, -f2`
TODAY=`date "+%Y-%m-%d"`
START_DATE=$(date -d $ACT_DATE +%s)
END_DATE=$(date -d $TODAY +%s)

#Create Output File & Write MSISDN into Output File:
FILE_NAME=$SCRIPT_PATH/${MSISDN}_V3TEST.txt
touch $FILE_NAME
echo "$MSISDN:" >> $FILE_NAME

#Processing MER
echo "MER:" >> $FILE_NAME
for((i=START_DATE; i<=END_DATE; i+=86400))
do
LOOKUP_DATE=`date -d @$i +%Y-%m-%d`
cd $MER_ARCHIVE/$LOOKUP_DATE
zcat */*.gz | grep -a ",$MSISDN," >> $FILE_NAME
done
echo "" >> $FILE_NAME

#Processing BAR
echo "BAR:" >> $FILE_NAME
for((i=START_DATE; i<=END_DATE; i+=86400))
do
LOOKUP_DATE=`date -d @$i +%Y-%m-%d`
cd $BAR_ARCHIVE/$LOOKUP_DATE
zcat */*.gz | grep -a ",$MSISDN," >> $FILE_NAME
done
echo "" >> $FILE_NAME

#Processing OLDR
#echo "OLDR:" >> $FILE_NAME
#for((i=START_DATE; i<=END_DATE; i+=86400))
#do
#LOOKUP_DATE=`date -d @$i +%Y-%m-%d`
#cd $OLDR_ARCHIVE/$LOOKUP_DATE
#zcat */*.gz | grep -a ",$MSISDN," >> $FILE_NAME
#done
#echo "" >> $FILE_NAME

#Processing BTR
#echo "BTR:" >> $FILE_NAME
#for((i=END_DATE; i>=START_DATE; i-=86400));
#do
#LOOKUP_DATE=`date -d @$i +%Y-%m-%d`
#cd $BTR_ARCHIVE/$LOOKUP_DATE
#FILE_COUNT=`zcat */*.gz | grep -a ",$MSISDN," | wc -l`
#if [ $FILE_COUNT -gt 0 ]
#then
#zcat */*.gz | grep -a ",$MSISDN," >> $FILE_NAME
#break
#fi
#done
#echo "" >> $FILE_NAME

#Processing UDR
echo "UDR:" >> $FILE_NAME
for((i=END_DATE; i>=START_DATE; i-=86400));
do
LOOKUP_DATE=`date -d @$i +%Y-%m-%d`
cd $UDR_ARCHIVE/$LOOKUP_DATE
FILE_COUNT=`zcat */*.gz | grep -a ",$MSISDN," | wc -l`
if [ $FILE_COUNT -gt 0 ]
then
zcat */*.gz | grep -a ",$MSISDN," >> $FILE_NAME
break
fi
done
echo "" >> $FILE_NAME

#Processing BATCH TRIGGER
echo "ETL:" >> $FILE_NAME
for((i=END_DATE; i>=START_DATE; i-=86400));
do
LOOKUP_DATE=`date -d @$i +%Y-%m-%d`

if [ $i -eq $END_DATE ]
then
cd $PROFILE_ARCHIVE/$LOOKUP_DATE
FILE_COUNT=`cat */*.txt | grep -a "$MSISDN|" | wc -l`
if [ $FILE_COUNT -gt 0 ]
then
cat */*.txt | grep -a "$MSISDN|" >> $FILE_NAME
break
fi
else
cd $PROFILE_ARCHIVE/$LOOKUP_DATE
FILE_COUNT=`zcat *.gz | grep -a "$MSISDN|" | wc -l`
if [ $FILE_COUNT -gt 0 ]
then
zcat *.gz | grep -a "$MSISDN|" >> $FILE_NAME
break
fi
fi
done
echo "" >> $FILE_NAME

#Processing Model Score
echo "MODEL SCORE:" >> $FILE_NAME
for((i=END_DATE; i>=START_DATE; i-=86400));
do
LOOKUP_DATE=`date -d @$i +%Y-%m-%d`

if [ $i -eq $END_DATE ]
then
cd $MODELSCORE_ARCHIVE/$LOOKUP_DATE
FILE_COUNT=`cat */*.csv | grep "$MSISDN" | wc -l`
if [ $FILE_COUNT -gt 0 ]
then
cat */*.csv | grep "$MSISDN" >> $FILE_NAME
break
fi
else
cd $MODELSCORE_ARCHIVE/$LOOKUP_DATE
FILE_COUNT=`zcat *.gz | grep -a "$MSISDN" | wc -l`
if [ $FILE_COUNT -gt 0 ]
then
zcat *.gz | grep -a "$MSISDN" >> $FILE_NAME
break
fi
fi
done
echo "" >> $FILE_NAME
echo "Life Cycle Records of $MSISDN Completed" >> $FILE_NAME
done < $INPUT_FILE
