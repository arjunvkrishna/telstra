PID=`ps -ef|grep -i SiftETL.jar|grep -v 'grep' |wc -l`
if [ ${PID} -eq 0 ]
then
	echo "Process not found"
else
	echo "Process found"
fi
