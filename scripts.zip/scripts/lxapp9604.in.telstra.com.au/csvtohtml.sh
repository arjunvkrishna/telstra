#!/bin/bash
 
while true; do
    case "$1" in
    -d)
      shift
      d="$1"
      ;;
    --foot)
      foot="-v ftr=1"
      ;;
    --help)
      usage
      exit 0
      ;;
    --head)
      head="-v hdr=1"
      ;;
    -*)
      echo "ERROR: unknown option '$1'"
      echo "see '--help' for usage"
      exit 1
      ;;
    *)
      f=$1
      break
      ;;
  esac
  shift
done
 
if [ -z "$d" ]; then
    d=","
fi
 
if [ -z "$f" ]; then
    echo "ERROR: input file is required"
    echo "see '--help' for usage"
    exit 1
fi
   
if ! [ -f "$f" ]; then
    echo "ERROR: input file '$f' is not readable"
    exit 1
else
    data=$(sed '/^$/d' $f)
    last=$(wc -l <<< "$data")
fi
 
awk -F "$d" -v last=$last $head $foot '
BEGIN {
    print "To: Anshul.Tiwari@team.telstra.com"
    print "Subject: Health check"
    print "MIME-Version: 1.0"
    print "Content-Type: text/html"

    print "<html>"
    print "  <table style=font-family:calibri  border="1" width="1000">"
}       
{
    if(NR == 1 && hdr) 
    {  
        printf "    <thead>\n"
        gsub(/&/, "\\&gt;")    
    }
    if(NR == last && ftr) 
        printf "    <tfoot>\n"

    print "      <tr>"
  
    for(f = 1; f <= NF; f++)  
    {
        if( NR == 1 ) 
            printf "  <th colspan="4" bgcolor=NAVY height=40><font color=WHITE size=5>%s</font></th>\n", $f
        else if ( $f ~ /Servers Availability/ || $f ~ /Process Status/) 
            printf "<th colspan="4" bgcolor=SANDYBROWN height=30 align=center>%s</th>\n", $f
        else if ( NR == 3  || NR == 13 || NR == 26) 
            printf "<td bgcolor=LIGHTSKYBLUE height=20 align=left><font size=2>%s</font></td>\n", $f
        else if( $f ~ /AVAILABLE/ || $f ~ /RUNNING/ || $f ~ /SUCCESSFUL/ ) 
            printf "<td bgcolor=LIMEGREEN><font size=2>%s</font></td>\n", $f
        else if( $f ~ /Not Available/ || $f ~ /Not Running/ || $f ~ /Failed/ ) 
            printf "<td bgcolor=RED><font size=2>%s</font></td>\n", $f
        else if ( $f ~ /Memory Usage/ )
        {
            printf "</table>\n"
            printf "<br><br>\n"
            printf "<table style=font-family:calibri  border="1" width="1000">\n"
            printf "<th colspan="11" bgcolor=SANDYBROWN height=30 align=center>%s</th>\n", $f
        }
        else if ( $f ~ /Statistics /) 
            printf "<th colspan="11" bgcolor=SANDYBROWN height=30 align=center>%s</th>\n", $f
        else if ( NR == 52|| NR == 62 || NR == 66) 
            printf "<td bgcolor=LIGHTSKYBLUE height=20 align=left><font size=2>%s</font></td>\n", $f
        else if (( NR == 51) && (f == 2 || f == 3)) 
            printf "<td colspan="4" bgcolor=SANDYBROWN><font size=2>%s</font></td>\n", $f
        else 
            printf "        <td><font size=2>%s</font></td>\n", $f
    }     
    print "      </tr>"
    if(NR == 1 && hdr) 
        printf "    </thead>\n"
    if(NR == last && ftr) 
        printf "    </tfoot>\n"
}       
END {
    print "  </table>"
    print "</html>"
}
' <<< "$data"