#!/bin/sh

source /home/siftuser/.bashrc

PID=`ps -ef|grep -i SiftETL.jar|grep -v 'grep' |awk '{print $2}'`
if [ ${#PID} -ne 0 ]
then
kill -15 $PID
fi

source /opt/knowesis/sift/core/sift/scripts/envSift.sh
ETL_PATH=/opt/knowesis/sift/core/sift/scripts/ETLExtract
cd ${ETL_PATH}
nohup java -Xmx10G -Dlog4j.configurationFile=file:${ETL_PATH}/log4j.xml -jar ${ETL_PATH}/SiftETL.jar ${PERSIST_ADDRESS}  ${ETL_PATH}/input/  MSISDN &
