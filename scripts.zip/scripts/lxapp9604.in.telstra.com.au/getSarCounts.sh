#!/bin/sh
##################################################################################
#Script Name: getSarCounts.sh
#Author: Infosys
#Date: 21-Sep-2017
#Descrption: 			 This Script Will Extract System Activity Report (SAR),
#                        Along With Memory and Swap Details From SAR logs in /var/log/sa
#                        For Last 30 Days From the Date Passed (Including the Date Passed)
#                        Script Can be Run to Generate SAR Reports For Last 'n' Number of Days
#						 From Date Passed.
#
#Parameters: 			 Input Date - 1st Parameter To Be Passed - Date From Which Report Should Be Generated (Format: YYYY-MM-DD)
#						 Number of Days, 2nd Parameter To Be Passed - Number of Days For Which 
#						 Report Should Be Generated From Date Supplied in Parameter 1 (Format 0-9: N, 10-29: NN)
#						 No Inscript Checks For Order of Parameter Passed, Format of Input Date and Format of Number of Days
#						 Incorrect Order and Incorrect Formats Will Yeild Undesired Results
#
#Things to Note:		 Input Date Should Be Between Today & Last 30 Days
#                   	 Number of Days Passed Can Be a Maximum of 29. Minimum is 0 and that Would Generate Report For Input Date Alone.
#						 Maximum Value That Can be Passed to The Number of Days Parameter will Vary According to Input Date Passed in 
#						 Parameter 1.
#						 The Above Restrictions Are in Place Because /var/log/sa has only SAR Logs of Last 30 days From Today.
#
#                        Daily Reports Will be Merged Together to Make a Monthly Report,
#                        Only if Parameter2 is 29.
#                        Monthly Report Name Will Have the Month When the Report Generation is Done.
##################################################################################


SARLOGPATH=/var/log/sa
OUTPUTPATH=/home/siftuser/PSNM_Scripts/Output_SAR
LOGFILE=${OUTPUTPATH}/`date +"%F"`_getSarCountsLog
TEMPSARACTFILE=${OUTPUTPATH}/`date "+%Y%m%d"`/tempSarAct.csv
TEMPSARMEMFILE=${OUTPUTPATH}/`date "+%Y%m%d"`/tempSarMem.csv
TEMPSARSWPFILE=${OUTPUTPATH}/`date "+%Y%m%d"`/tempSarSwp.csv
TEMPSARMEMFILE_CUT=${OUTPUTPATH}/`date "+%Y%m%d"`/tempSarMemCut.csv
TEMPSARSWPFILE_CUT=${OUTPUTPATH}/`date "+%Y%m%d"`/tempSarSwpCut.csv
SIFTSERVER=`hostname`
CURRENTDATE=$(date +"%F")

echo "getSarCounts Script For ${SIFTSERVER} Started" >> ${LOGFILE}

if [ $# -eq 0 ]
then
        INPUTDATE=$(date +"%F")
		DAYSNUMBER=29
        echo "No Parameters Supplied, So SAR Reports Generated From Today i.e., "$INPUTDATE " For Last "`expr ${DAYSNUMBER} + 1` "Days" >> ${LOGFILE}
elif [ $# -eq 2 ]
then
        INPUTDATE=$(date -d "$1" +"%F")
		DAYS=$(echo "( `date -d $CURRENTDATE +%s` - `date -d $INPUTDATE +%s`) / (24*3600)" | bc)
			if [ $DAYS -lt 0 -o $DAYS -gt 29 ]
			then
			echo "Please Input a Date Between `date --date="${CURRENTDATE} -29 day" +%F` and ${CURRENTDATE}"  >> ${LOGFILE}
			echo "Exiting Script" >> ${LOGFILE}
			exit
			fi
			if [ $DAYS -eq 0 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 30. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 29 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 29, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 1 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 29. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 28 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 28, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 2 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 28. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 27 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 27, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 3 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 27. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 26 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 26, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 4 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 26. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 25 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 25, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 5 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 25. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 24 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 24, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 6 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 24. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 23 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 23, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 7 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 23. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 22 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 22, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 8 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 22. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 21 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 21, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 9 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 21. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 20 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 20, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 10 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 20. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 19 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 19, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 11 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 19. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 18 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 18, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 12 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 18. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 17 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 17, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 13 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 17. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 16 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 16, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 14 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 16. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 15 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 15, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 15 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 15. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 14 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 14, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 16 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 14. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 13 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 13, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 17 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 13. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 12 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 12, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 18 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 12. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 11 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 11, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 19 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 11. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 10 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 10, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 20 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 10. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 9 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 9, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 21 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 9. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 8 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 8, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 22 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 8. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 7 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 7, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 23 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 7. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 6 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 6, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 24 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 6. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 5 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 5, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 25 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 5. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 4 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 4, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 26 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 4. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 3 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 3, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 27 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 3. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 2 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 2, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 28 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 2. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -lt 0 -o $2 -gt 1 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be Between 0 and 1, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
			if [ $DAYS -eq 29 ]
			then
			echo "Input Date is ${INPUTDATE}, Number of Days For Which Report Can be Run is 1. Checking 2nd Parameter Passed" >> ${LOGFILE}
				if [ $2 -ne 0 ]
				then
				echo "Parameter Out of Range, Input Number of Days Should be 0, Exiting Script"  >> ${LOGFILE}
				exit
				else
				DAYSNUMBER=$2
				fi
			fi
else

echo "Number of Parameters Supplied	Should be Either 0 or 2, Exiting Script" >> ${LOGFILE}
exit
fi
			 
echo "Date Supplied is "$INPUTDATE" ,SAR Reports Generated From this Date For Last "`expr ${DAYSNUMBER} + 1` "Days"  >> ${LOGFILE}

if [ ! -d ${OUTPUTPATH}/`date "+%Y%m%d"` ]
        then
        mkdir -p ${OUTPUTPATH}/`date "+%Y%m%d"`
                echo "Created New Sub Directory " `date "+%Y%m%d"` " in /home/siftuser/PSNM_Scripts/Output_SAR" >> ${LOGFILE}
else
        rm -rf ${OUTPUTPATH}/`date "+%Y%m%d"`/*.csv
        echo "Removed Previous Run Files From /home/siftuser/PSNM_Scripts/Output_SAR/`date "+%Y%m%d"`" >> ${LOGFILE}
fi


for FileDate in `seq 0 ${DAYSNUMBER}`
do
NEWDATE=$(date --date="${INPUTDATE} -${FileDate} day" +%F)
echo "Generating Report For "${NEWDATE} "Started">> ${LOGFILE}
SARFILEDATE=$(echo ${NEWDATE} | cut -d'-' -f3)
cd ${SARLOGPATH}
sar -f /var/log/sa/sa${SARFILEDATE}    >> ${TEMPSARACTFILE}
sar -r -f /var/log/sa/sa${SARFILEDATE} >> ${TEMPSARMEMFILE}
sar -W -f /var/log/sa/sa${SARFILEDATE} >> ${TEMPSARSWPFILE}

sed -i -e 1,3d ${TEMPSARACTFILE}
sed -i -e 1,3d ${TEMPSARMEMFILE}
sed -i -e 1,3d ${TEMPSARSWPFILE}

sed -i -e 's/  */\,/g' ${TEMPSARACTFILE}
sed -i -e 's/  */\,/g' ${TEMPSARMEMFILE}
sed -i -e 's/  */\,/g' ${TEMPSARSWPFILE}

sed -i "s/^/${NEWDATE},/" ${TEMPSARACTFILE}
cut -d, -f1-2 --complement ${TEMPSARMEMFILE} > ${TEMPSARMEMFILE_CUT}
cut -d, -f1-2 --complement ${TEMPSARSWPFILE} > ${TEMPSARSWPFILE_CUT}

echo "Date,Time,AM/PM,CPU,%User,%Nice,%System,%IOWait,%Steal,%Ideal,KBMemFree,KBMemUsed,%MemUsed,KBBuffers,KBCached,KBCommit,%Commit,PSWPin/S,PSWPout/S" > ${OUTPUTPATH}/`date "+%Y%m%d"`/SAR_REPORT_${SIFTSERVER}_${NEWDATE}.csv
paste -d "," ${TEMPSARACTFILE} ${TEMPSARMEMFILE_CUT} ${TEMPSARSWPFILE_CUT} >> ${OUTPUTPATH}/`date "+%Y%m%d"`/SAR_REPORT_${SIFTSERVER}_${NEWDATE}.csv

rm -r ${TEMPSARACTFILE}
rm -r ${TEMPSARMEMFILE}
rm -r ${TEMPSARSWPFILE}
rm -r ${TEMPSARMEMFILE_CUT}
rm -r ${TEMPSARSWPFILE_CUT}

echo "Generating Report For "${NEWDATE} "Completed" >> ${LOGFILE};
done

if [ ${DAYSNUMBER} -gt 15 ]
        then
        echo "Generating Monthly Report For ${SIFTSERVER} Started" >> ${LOGFILE}
        cat ${OUTPUTPATH}/`date "+%Y%m%d"`/SAR_REPORT_${SIFTSERVER}_*.csv >> ${OUTPUTPATH}/`date "+%Y%m%d"`/SAR_MONTHLY_REPORT_${SIFTSERVER}_`date "+%Y%m"`.csv
        echo "Generating Monthly Report For ${SIFTSERVER} Completed" >> ${LOGFILE}
echo "Please Find Attached Monthly SAR Reports For ${SIFTSERVER} "| mailx -a ${OUTPUTPATH}/`date "+%Y%m%d"`/SAR_MONTHLY_REPORT_${SIFTSERVER}_`date "+%Y%m"`.csv -s "Monthly SAR Report - ${SIFTSERVER}"  -S smtp=mail.in.telstra.com.au  "Nirmal_Thekkekkota@infosys.com,Shabeena_M@infosys.com,Telstra_SIFT@infosys.com,Sowmya.T02@infosys.com"        
echo "Sending Monthly Report Email For ${SIFTSERVER}" >> ${LOGFILE}
echo "SAR Monthly Reports For ${SIFTSERVER} Delivered" >> ${LOGFILE}
fi

echo "getSarCounts Script For ${SIFTSERVER} Completed" >> ${LOGFILE}

