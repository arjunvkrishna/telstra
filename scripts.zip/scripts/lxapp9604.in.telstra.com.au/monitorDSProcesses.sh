#!/bin/bash

source /home/siftuser/.bashrc
SCRIPTS_PATH=${SIFT_INSTALL_PATH}/core/sift/scripts/
source ${SCRIPTS_PATH}/envSift.sh
UNIQUE_DS_HOSTS=/tmp/alluniquedshosts.tmp
DS_PROCESSES=com.knowesis.sift.dataSourceFactory.SourceFactory

cat ${SCRIPTS_PATH}/sourcesToDeploy | awk -F',' '{print $2}' | awk -F'_' '{print $1}' | sort -u > ${UNIQUE_DS_HOSTS}

for i in `cat ${UNIQUE_DS_HOSTS}`
do 
	for DS_LIST in `grep ${i} ${SCRIPTS_PATH}/sourcesToDeploy`
	do
		THIS_DS=`echo ${DS_LIST} | awk -F',' '{print $1}'`
		THIS_DS_ACTUAL_PROCESS=`echo ${DS_LIST} | awk -F',' '{print $2}' |awk -F'_' '{print $2}'`
		THIS_HOST_PROCESSES=`ssh ${i} "ps -elf | grep -i ${DS_PROCESSES} | grep -v grep | grep -w ${THIS_DS}" | grep -vw ${THIS_DS_ACTUAL_PROCESS} | awk '{print $4}'`
	
		for PRC in ${THIS_HOST_PROCESSES}	
		do
			echo "Attempting to terminate process '${PRC}' on '${i}' at `date +%s`" >> ${SCRIPTS_PATH}/out
			ssh ${i} "kill -9 '${PRC}'"
		done
	done
done
