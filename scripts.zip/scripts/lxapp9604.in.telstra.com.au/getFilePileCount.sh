#!/bin/sh
clear
SIFT_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input
APOLLO_LANDING_PATH=/data/ingest/APOLLO
echo "File count at Sift Input :
"
for i in `echo "CDR LDR SUBSCRIBER_PROFILE PROFILE_SNAPSHOT"`
do
SIFT_INPUT_PATH_LOCAL=${SIFT_INPUT_PATH}/$i
echo " ${i} : `ls $SIFT_INPUT_PATH_LOCAL|wc -l`"
done

echo "
File count at Apollo Landing :
"
for i in `echo "CDR LDR Accounts Customers"`
do
echo " ${i} : `ls $APOLLO_LANDING_PATH|grep ${i}| wc -l`"
done
