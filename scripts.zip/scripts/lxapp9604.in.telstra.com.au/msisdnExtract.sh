#!/bin/sh
#v2.0.0.001
#########################################
## MSISDN Extract Script
#########################################

#Folder Path Configs
sourcePath=/data/processed
resultPath=/opt/knowesis/sift/scripts/tmp/MsisdnExtractTmp
extractBackup=/opt/knowesis/sift/scripts/tmp/MsisdnExtract_BACKUP

#Destination Configs
destinationPath=/opt/knowesis/sift/core/sift/scripts/ETLExtract
destinationFilename=msisdn_list.txt

#File Configs
#sourceFile=SFMC_Opolo_PrepaidProfile_$(date +"%Y%m%d")*.csv
sourceFile=SFMC_Opolo_PrepaidProfile_$(date --date="1 days ago" +"%Y%m%d")*.csv

#Log Path Config
log=/opt/knowesis/sift/scripts/log/msisdnExtract_$(date +"%Y%m").log

echo $(date)' - Starting process '  >> $log 2>&1

#taking fileCount
currentFileCount=`ls ${sourcePath}/${sourceFile} |wc -l`

#if fileCount greater than 0
if [ ${currentFileCount} -gt 0 ]; then
    echo $(date)' - Starting to cut data' >> $log 2>&1
    for i in `ls ${sourcePath}/${sourceFile}`
    do
        sourceFilename=$i
        #picking the first field (msisdn) from the file.
        awk -F "," '{print $1}' $sourceFilename | grep -v '-' >> $resultPath/$destinationFilename
        #rm $sourceFilename
    done

    #filtering uniq msisdn list(to avoid dulpicate msisdn)
    sort -u $resultPath/$destinationFilename > tempFile; mv tempFile $resultPath/$destinationFilename

    #replacing countryCode ( 61 ) with 0
    sed -i s/^61/0/g $resultPath/$destinationFilename

    echo $(date)' - Starting to Transfer' >> $log 2>&1
    echo $(date)' - Starting to backup' >> $log 2>&1

    #Removing the current backup msisdnList and update with the recent list.
    rm -f $extractBackup/$destinationFilename
    cp  $resultPath/$destinationFilename $extractBackup/$destinationFilename
    echo $(date)' - backup Successful' >> $log 2>&1

    #sending the file to destination Server:Path
    mv $resultPath/$destinationFilename $destinationPath
    if [ $? -eq 0 ];
    then
        echo $(date)' - Transfer Successful '  >> $log
    else
        echo $(date)' - Error! cannot Transfer '  >> $log
    fi

#if fileCount equals 0, then check for backup file
elif [ -f $extractBackup/$destinationFilename ]; then
    echo $(date)' - No process File available, so transfering previously extracted list' >> $log 2>&1
    cp $extractBackup/$destinationFilename $destinationPath
    if [ $? -eq 0 ];
    then
        echo $(date)' - Transfer Successful '  >> $log
    else
        echo $(date)' - Error! cannot Transfer '  >> $log
    fi
else
    echo $(date)' - Process File or previously extracted list is not available' >> $log 2>&1
fi

echo $(date)' - End of the Script'  >> $log 2>&1
