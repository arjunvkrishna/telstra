#!/bin/sh

SCRIPT_PATH=`pwd`
source $SCRIPT_PATH/envSift.sh;

java -jar /opt/knowesis/sift/core/sift/libs/OneTimeETLLoaderCommercialOffer.jar $PERSIST_ADDRESS $1
