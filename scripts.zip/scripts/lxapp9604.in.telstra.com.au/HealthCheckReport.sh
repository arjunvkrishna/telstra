#####################################################################
#####################################################################
# Script name: HealthCheckReport.sh
# Description: 
# Date       : 11-Mar-2016
# Version    : 1.0
# Author     : Infosys
#####################################################################
#####################################################################



#####################################################################
# Function   : usage
# Description: Displays the usage of the script
#####################################################################
function usage ()
{
    echo "Usage"
    exit
}

#####################################################################
# Function   : setParams
# Description: 
#####################################################################
function setParams ()
{
    # Variables
    all_hostnames=('lxapp9604.in.telstra.com.au' 'lxapp9605.in.telstra.com.au' 'lxapp9702.dc.corp.telstra.com' 'lxapp9703.dc.corp.telstra.com'\
    'lxapp9608.in.telstra.com.au')
    core_hostnames=('lxapp9604.in.telstra.com.au' 'lxapp9605.in.telstra.com.au' 'lxapp9702.dc.corp.telstra.com' 'lxapp9703.dc.corp.telstra.com')
    Scripts_loc="/home/siftuser/PSNM_Scripts"
    current_host="lxapp9604"
    healthCheckReport="/home/siftuser/PSNM_Scripts/test/Main_Report.`date +%F`.csv"
    logs_dir="/home/siftuser/PSNM_Scripts/HealthCheck"
    ApolloLogLoc=/opt/knowesis/sift/core/sift/scripts/ApolloPullLogs
    OrpheusLogLoc=/opt/knowesis/sift/core/sift/scripts/OrpheusPullLogs
    temp_log="/home/siftuser/PSNM_Scripts/test/temp_healthchk.log"
    temp_log_2="/home/siftuser/PSNM_Scripts/test/temp_healthchk_2.log"
    
    if [ -f $healthCheckReport ]; then
       rm $healthCheckReport
    fi

}

#####################################################################
# Function   : serverAvailability
# Description: 
#####################################################################
function serverAvailability ()
{
    echo "Application Servers Availability" >> $healthCheckReport
    echo "Component,HostName,Status, Comments" >> $healthCheckReport
    for i in "${all_hostnames[@]}"
    do
        if [ "$i" = "lxapp9603.in.telstra.com.au" ]; then
            component="SIFT Portal"
        elif [ "$i" = "lxapp9604.in.telstra.com.au" ]; then
            component="SIFT core 1"
        elif [ "$i" = "lxapp9605.in.telstra.com.au" ]; then
            component="SIFT core 2"
        elif [ "$i" = "lxapp9702.dc.corp.telstra.com" ]; then
            component="SIFT core 3"
        elif [ "$i" = "lxapp9703.dc.corp.telstra.com" ]; then
            component="SIFT core 4"
        elif [ "$i" = "lxdb9123.in.telstra.com.au" ]; then
            component="SIFT Persist 1"
        elif [ "$i" = "lxdb9124.in.telstra.com.au" ]; then
            component="SIFT Persist 2"
        elif [ "$i" = "lxapp9606.in.telstra.com.au" ]; then
            component="SO 1"
        elif [ "$i" = "lxapp9607.in.telstra.com.au" ]; then
            component="SO 2"
        elif [ "$i" = "lxapp9608.in.telstra.com.au" ]; then
            component="SO 3"
        fi

        ping -c 1 $i
        if [ $? -eq 0 ]; then 
            echo "$component, $i, AVAILABLE" >> $healthCheckReport
        else
            echo "$component, $i, Not Available, Not able to ping/connect"
        fi
    done

    echo "" >> $healthCheckReport
}


#####################################################################
# Function   : checkETLStatus
# Description: 
#####################################################################
function checkETLStatus ()
{
    ETL_logFile="$logs_dir/ETLStats_new.`date -d '1 day ago' +%F`"
    ETL_Start=`grep "ETL files have arrived" $ETL_logFile | head -1`
    ETL_Complete=`grep "ETL file processing completed" $ETL_logFile`
    if [ "$ETL_Complete" = "" ]; then
        ETL_error=`grep "WARN" $ETL_logFile | tail -1`
        echo  "SIFTcore 1+core 2+core 3+core 4, ETL file processing, Failed , $ETL_Start <br> $ETL_Complete <br> $ETL_error" >> $healthCheckReport
    else
        echo  "SIFTcore 1+core 2+core 3+core 4, ETL file processing,  SUCCESSFUL , $ETL_Start <br> $ETL_Complete " >> $healthCheckReport
    fi
}

#####################################################################
# Function   : checkStreamsStatus
# Description: 
#####################################################################
function checkStreamsStatus ()
{
    streams_status=`streamtool lsjobs -i SiFTInstance --xheaders`
    is_running=`echo $streams_status | awk '{print $3}'`
    if [ $is_running = "yes" ]; then
        echo  "SIFTcore 1+core 2+core 3+core 4, Core Stream Jobs, RUNNING , $streams_status" >> $healthCheckReport
    else
        echo  "SIFTcore 1+core 2+core 3+core 4, Core Stream Jobs, Not Running , $streams_status " >> $healthCheckReport
    fi
}

#####################################################################
# Function   : checkFilePull
# Description: 
#####################################################################
function checkFilePull ()
{
    interface_type="$1"
 
    for i in  $2 $3 $4 $5 $6 $7
    do   
        if [ $interface_type = "Apollo" ]; then
            LogFile=$ApolloLogLoc/apollo_Apollo_"$i"_datapull_`date +%F`.log
            filePattern=Apollo_"$i".*.`date +%d%m%Y`*
            move_details=`grep "Moving Files" $LogFile | tail -3`
            complete_details=`grep "File Pull Completed" $LogFile | tail -3`
            timestamp=`grep "File Pull Completed" $LogFile | tail -3 | awk '{print $7,$8,$9}'`
        elif [ $interface_type = "Orpheus" ]; then
            LogFile=$OrpheusLogLoc/orpheus"$i"datapull_`date +%F`.log
            file_type=`echo $i | tr '[:upper:]' '[:lower:]'`
            filePattern=ocs_"$file_type"*
            move_details=`grep "Copying Files from" $LogFile | tail -3`
            complete_details=`grep "File Pull Compl" $LogFile | tail -3`
            timestamp=`grep "File Pull Compl" $LogFile | tail -3 | awk '{print $7,$8,$9}'`
        else
            echo "Cannot determine log file name"
            exit 1
        fi
    
        start_details=`grep "Starting to pull $interface_type Files" $LogFile | tail -3`
        file_details=`grep $filePattern $LogFile | tail -3`

        t1=`echo $timestamp | awk '{print $1,$2,$3}'`
        t2=`echo $timestamp | awk '{print $4,$5,$6}'`
        t3=`echo $timestamp | awk '{print $7,$8,$9}'`
        diff1=$(expr `date -d "$t2" +%M` - `date -d "$t1" +%M`)
        diff2=$(expr `date -d "$t3" +%M` - `date -d "$t2" +%M`)
    

        if [[ "$start_details" = "" ]] || [[ "$move_details" = "" ]] || [[ "$file_details" = "" ]] || [[ "$complete_details" = "" ]] || [[ $diff1 -gt 30 ]] || [[ $diff2 -gt 30 ]] && [[ "$interface_type" -ne "EXP" ]]; then    
            echo  "SIFTcore 1+core 2+core 3+core 4, $interface_type $i file pull, Not Running , Please check log files" >> $healthCheckReport
        elif [[ "$start_details" = "" ]] || [[ "$move_details" = "" ]] || [[ "$file_details" = "" ]] || [[ "$complete_details" = "" ]] && [[ "$interface_type" -eq "EXP" ]]; then    
            echo  "SIFTcore 1+core 2+core 3+core 4, $interface_type $i file pull, Not Running , Please check log files" >> $healthCheckReport
        else
            comments=`echo $complete_details | sed "s/$i/<br>$i/g"`
            echo  "SIFTcore 1+core 2+core 3+core 4, $interface_type $i file pull, RUNNING , Status of latest three file pulls: $comments" >> $healthCheckReport
        fi
    done
}

#####################################################################
# Function   : checkAPIServer
# Description: 
#####################################################################
function checkAPIServer()
{
   ssh lxapp9605 -q 'ps -ef | grep "8111" | grep "API" | grep -v "grep"' > $temp_log
   APIServer_running=`grep "8111" $temp_log | grep "API" | sed 's/,//g'`
   if [ $? -ne 0 ]; then
       echo "SIFT API server,API server, Not Running, $APIServer_running" >> $healthCheckReport
   else
       echo "SIFT API server,API server, RUNNING, $APIServer_running" >> $healthCheckReport
   fi
}


#####################################################################
# Function   : checkCoreProcesses
# Description: 
#####################################################################
function checkCoreProcesses ()
{
    echo "SIFT Core Jobs and Process Status" >> $healthCheckReport
    echo "Component,Job/Process,Status,Comments" >> $healthCheckReport

    #ETL
    checkETLStatus 

    #Stream jobs
    checkStreamsStatus 
    
    #Apollo file pull
    checkFilePull Apollo CDR LDR
    
    #Orpheus file pull
    checkFilePull Orpheus BAR UDR MER LDR BTR EXP

    #API server
    checkAPIServer

    echo "" >> $healthCheckReport
}

#####################################################################
# Function   : memoryUsage
# Description: 
#####################################################################
function memoryUsage ()
{
    echo "Memory Usage" >> $healthCheckReport
    echo ", Disk Usage: Location (/data),Memory usage" >> $healthCheckReport
    echo "Server name, Total Space, Used Space, Free Space, Use in %,Total Space, Used Space, Free Space, Use in %" >> $healthCheckReport
    for i in "${all_hostnames[@]}"
    do
        ssh $i -q 'sh /home/siftuser/PSNM_Scripts/checkMemoryUsage.sh' > $temp_log
        server_shortname=`echo $i | cut -d "." -f1`
        echo `grep $server_shortname $temp_log | head -1 | awk '{print $1,",",$3,",",$4,",",$5,",",$6}'`, \
        `grep $server_shortname $temp_log | tail -1 | awk '{print $2,",",$3,",",$4,",",$5}'` >> $healthCheckReport
    done

    echo "" >> $healthCheckReport
}

#####################################################################
# Function   : getStatusSO2
# Description: 
#####################################################################
function getStatusSO2 ()
{
    echo "SIFT Orchestrator Process Status" >> $healthCheckReport
    echo "Component,Job/Process,Status,Comments" >> $healthCheckReport
    
    activeMQStatus=RUNNING
    redisStatus=RUNNING
    webConsoleStatus=RUNNING
    coreHandlerStatus=RUNNING
    interactHandlerStatus=RUNNING
    mainsHandlerStatus=RUNNING
    responsysHandlerStatus=RUNNING
    apolloProvsionHandlerStatus=RUNNING
    webHandlerStatus=RUNNING
    apiOptinHanlderStatus=RUNNING
    MOHanlderStatus=RUNNING

    echo "SIFT Orchestrator 2 - Real time handlers, ActiveMQ, $activeMQStatus" >> $healthCheckReport
    echo ", Redis Cache server, $redisStatus" >> $healthCheckReport
    echo ", Web console, $webConsoleStatus" >> $healthCheckReport
    echo ", Core handler, $coreHandlerStatus" >> $healthCheckReport
    echo ", Interact handler, $interactHandlerStatus" >> $healthCheckReport
    echo ", Mains handler, $mainsHandlerStatus" >> $healthCheckReport
    echo ", Responsys handler, $responsysHandlerStatus" >> $healthCheckReport
    echo ", Apollo Provision Handler, $apolloProvsionHandlerStatus" >> $healthCheckReport
    echo ", Web Handler, $webHandlerStatus" >> $healthCheckReport
    echo ", API opt-in handler, $apiOptinHanlderStatus" >> $healthCheckReport
    echo ", MO handler, $MOHanlderStatus" >> $healthCheckReport
}

#####################################################################
# Function   : getStatusSO1
# Description: 
#####################################################################
function getStatusSO1 ()
{
    activeMQStatus=RUNNING
    redisStatus=RUNNING
    webConsoleStatus=RUNNING
    UCHandlerStatus=RUNNING
    interactHandlerStatus=RUNNING
    mainsHandlerStatus=RUNNING
    responsysHandlerStatus=RUNNING
    apolloReplicatorHandlerStatus=RUNNING
    monitorReplicatorHandlerStatus=RUNNING
    webHandlerStatus=RUNNING
    apiOptinHanlderStatus=RUNNING
    MOHanlderStatus=RUNNING

    echo "SIFT Orchestrator 1 - Batch handlers, ActiveMQ, $activeMQStatus" >> $healthCheckReport
    echo ", Redis Cache server, $redisStatus" >> $healthCheckReport
    echo ", Web console, $webConsoleStatus" >> $healthCheckReport
    echo ", BatchUnica Campaign handler, $UCHandlerStatus" >> $healthCheckReport
    echo ", Batch Interact handler, $interactHandlerStatus" >> $healthCheckReport
    echo ", Batch Mains handler, $mainsHandlerStatus" >> $healthCheckReport
    echo ", Batch Responsys handler, $responsysHandlerStatus" >> $healthCheckReport
    echo ", Batch Apollo Replicator handler, $apolloReplicatorHandlerStatus" >> $healthCheckReport
    echo ", Batch Monitor Replicator handler, $monitorReplicatorHandlerStatus" >> $healthCheckReport
    echo ", Web handler, $webHandlerStatus" >> $healthCheckReport
    echo ", API opt-in handler, $apiOptinHanlderStatus" >> $healthCheckReport
    echo ", MO handler, $MOHanlderStatus" >> $healthCheckReport
}

#####################################################################
# Function   : getApolloStats
# Description: 
#####################################################################
function getApolloStats ()
{
    echo "Apollo Input file Statistics Usage" >> $healthCheckReport
    
    echo "" >> $healthCheckReport
    
    for (( interval=9; interval>=0 ; interval--))
    do 
        run_date=`date -d "$interval days ago" +%F`
        if [ `uname -n` = "$current_host" ]
        then
           sh /home/siftuser/PSNM_Scripts/countCDRLDRSNAPSHOTFiles.sh $run_date > $temp_log
        else 
           ssh ${core_hostnames[0]} -p 'sh /home/siftuser/PSNM_Scripts/countCDRLDRSNAPSHOTFiles.sh $run_date' > $temp_log
        fi
    
        echo "$run_date" >> $temp_log_2
        echo `grep "CDR" $temp_log | grep $run_date | awk '{print $7}'`  >> $temp_log_2
        echo `grep "LDR" $temp_log | grep $run_date |awk '{print $7}'` >> $temp_log_2
    done 

    pr -10 -s"," -t $temp_log_2 > $temp_log
    echo -e "\n" "CDR" "\n" "LDR" > $temp_log_2
    paste -d "," $temp_log_2 $temp_log >> $healthCheckReport
    echo "" >> $healthCheckReport
    
    deleteTempFiles
}


#####################################################################
# Function   : getOrpheusStats
# Description: 
#####################################################################
function getOrpheusStats ()
{
    echo "Orpheus Input file Statistics Usage" >> $healthCheckReport
    
    for (( interval=9; interval>=0 ; interval--))
    do 
        run_date=`date -d "$interval days ago" +%F`
        if [ `uname -n` = "$current_host" ]
        then
            sh /home/siftuser/PSNM_Scripts/getOrpheusFileCount.sh $run_date >> $temp_log
        else 
           ssh ${core_hostnames[0]} -p 'sh /home/siftuser/PSNM_Scripts/getOrpheusFileCount.sh $run_date' >> $temp_log
        fi
        
        echo "$run_date" >> $temp_log_2
        echo `grep "BAR" $temp_log | grep $run_date | awk '{print $7}'` >> $temp_log_2
        echo `grep "UDR" $temp_log | grep $run_date | awk '{print $7}'` >> $temp_log_2
        echo `grep "MER" $temp_log | grep $run_date | awk '{print $7}'` >> $temp_log_2
        echo `grep "LDR" $temp_log | grep $run_date | awk '{print $7}'` >> $temp_log_2
        echo `grep "BTR" $temp_log | grep $run_date | awk '{print $7}'` >> $temp_log_2
        echo `grep "EXP" $temp_log | grep $run_date | awk '{print $7}'` >> $temp_log_2
    done
    
    pr -10 -s"," -t $temp_log_2 > $temp_log
    echo -e "\n" "BAR" "\n" "UDR" "\n" "MER" "\n" "LDR" "\n" "BTR" "\n" "EXP"> $temp_log_2
    paste -d "," $temp_log_2 $temp_log >> $healthCheckReport
    echo "" >> $healthCheckReport
    
    deleteTempFiles
}

#####################################################################
# Function   : deleteTempFiles
# Description: 
#####################################################################
function deleteTempFiles()
{
    rm -f $temp_log
    rm -f $temp_log_2
}

#####################################################################
# Function   : convertCSVtoHTML
# Description: 
#####################################################################
function convertCSVtoHTML ()
{
  sh csvtohtml.sh $healthCheckReport > health.html
}

function checkSIFTPersist ()
{
    echo "SIFT Persist Process Status" >> $healthCheckReport
    echo "Component,Job/Process,Status,Comments" >> $healthCheckReport

    persist_running=`ps -ef | grep 8091 | grep -v "grep"`
    if [ $? -ne 0 ]; then
        echo "SIFT Persist 1,CouchBase, Not Running, $persist_running" >> $healthCheckReport
    else
       echo "SIFT Persist 1,CouchBase, RUNNING, $persist_running" >> $healthCheckReport
    fi
}


function checkSIFTPortal ()
{
    portalURL="http://lxapp9603.in.telstra.com.au:81/sift-portal/"

    echo "SIFT Portal Process Status" >> $healthCheckReport
    echo "Component,Job/Process,Status,Comments" >> $healthCheckReport

    wget `echo $portalURL` -O portal.html
    signInPage=`grep -c 'Sift Portal : Sign In' portal.html`
    if [ $signInPage -eq 1 ]; 
    then
        echo "SIFT portal, GUI, RUNNING, " >> $healthCheckReport
    else
        echo "SIFT portal, GUI, Not Running, " >> $healthCheckReport
    fi
}

#####################################################################
# Function   : main
# Description: 
#####################################################################

setParams

echo "" >> $healthCheckReport
echo "Athenian-SIFT Application - Daily Health Check Date Report :`date +%F`" >> $healthCheckReport
echo "" >> $healthCheckReport

serverAvailability
checkSIFTPortal
checkCoreProcesses
getStatusSO2
getStatusSO1
memoryUsage
getOrpheusStats
convertCSVtoHTML
