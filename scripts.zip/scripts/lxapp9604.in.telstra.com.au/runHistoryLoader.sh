#!/bin/sh

SCRIPT_PATH=`pwd`
source $SCRIPT_PATH/envSift.sh;
if [ -f $SCRIPT_PATH/admin_scripts/INPUT_ONE_TIME_LOAD/tmp3.txt ]
then
rm $SCRIPT_PATH/admin_scripts/INPUT_ONE_TIME_LOAD/tmp3.txt
fi
COUNT=`cat $1|wc -l`
ACTUAL_RECORDS=`expr $COUNT - 1`
cat $1|tail -${ACTUAL_RECORDS} > $SCRIPT_PATH/admin_scripts/INPUT_ONE_TIME_LOAD/tmp3.txt
chmod 770 $SCRIPT_PATH/admin_scripts/INPUT_ONE_TIME_LOAD/tmp3.txt

java -jar /opt/knowesis/sift/core/sift/libs/OneTimeHistoryETLLoader.jar $PERSIST_ADDRESS $SCRIPT_PATH/admin_scripts/INPUT_ONE_TIME_LOAD/tmp3.txt
