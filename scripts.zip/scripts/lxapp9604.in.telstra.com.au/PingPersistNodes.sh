#!/bin/sh
PERSIST1=lxdb9123.in.telstra.com.au
PERSIST2=lxdb9124.in.telstra.com.au
PERSIST3=lxdb9177.in.telstra.com.au
PING_STATUS_DIR=/home/siftuser/PSNM_Scripts/PersistPingStatus
TODAY_DATE=`date "+%Y%m%d"`
PING_NO=1
PERSIST1_STATUS_FILE=lxdb9123_Pings_${TODAY_DATE}.txt
PERSIST2_STATUS_FILE=lxdb9124_Pings_${TODAY_DATE}.txt
PERSIST3_STATUS_FILE=lxdb9177_Pings_${TODAY_DATE}.txt

function sendEmailAlert ()
{
emailSubject="SIFT EMAIL ALERT "\!\!\!" $NOTIFY_MSG - `date +%F`"
toAddressArray=('Manoj_Kumar51@infosys.com' 'sumit.srivastava02@infosys.com' 'Twinku.Thomas@team.telstra.com')
tail -7 ${LOG_FILE} | head -6 | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0408574590@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0466961887@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919496152994@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919663679814@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0431812571@sms.in.telstra.com.au"
}

echo "Pinging at `date +"%Y-%m-%d %H:%M:%S"`" >> ${PING_STATUS_DIR}/${PERSIST1_STATUS_FILE}
ping -c${PING_NO} ${PERSIST1} >> ${PING_STATUS_DIR}/${PERSIST1_STATUS_FILE}
tail -2 ${PING_STATUS_DIR}/${PERSIST1_STATUS_FILE} | head -1 | grep '100% packet loss'
if [ $? -eq 0 ]
then
LOG_FILE=${PING_STATUS_DIR}/${PERSIST1_STATUS_FILE}
NOTIFY_MSG="Unable to Ping lxdb9123"
sendEmailAlert
fi

echo "Pinging at `date +"%Y-%m-%d %H:%M:%S"`" >> ${PING_STATUS_DIR}/${PERSIST2_STATUS_FILE}
ping -c${PING_NO} ${PERSIST2} >> ${PING_STATUS_DIR}/${PERSIST2_STATUS_FILE}
tail -2 ${PING_STATUS_DIR}/${PERSIST2_STATUS_FILE} | head -1 | grep '100% packet loss'
if [ $? -eq 0 ]
then
LOG_FILE=${PING_STATUS_DIR}/${PERSIST2_STATUS_FILE}
NOTIFY_MSG="Unable to Ping lxdb9124"
sendEmailAlert
fi

echo "Pinging at `date +"%Y-%m-%d %H:%M:%S"`" >> ${PING_STATUS_DIR}/${PERSIST3_STATUS_FILE}
ping -c${PING_NO} ${PERSIST3} >> ${PING_STATUS_DIR}/${PERSIST3_STATUS_FILE}
tail -2 ${PING_STATUS_DIR}/${PERSIST3_STATUS_FILE} | head -1 | grep '100% packet loss'
if [ $? -eq 0 ]
then
LOG_FILE=${PING_STATUS_DIR}/${PERSIST3_STATUS_FILE}
NOTIFY_MSG="Unable to Ping lxdb9177"
sendEmailAlert
fi

