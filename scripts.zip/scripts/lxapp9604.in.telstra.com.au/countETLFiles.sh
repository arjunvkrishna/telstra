#If no arguement has passed, this script will run for current day
if [ $# -eq 0 ]
then
currentDate=$(date +"%F")
echo "No Date Supplied So counting the files for today i.e., "$currentDate
else
currentDate=$(date -d "$1" +"%F")
echo "Date Supplied is "$currentDate
fi
archiveDir="/data/ARCHIVE/PROFILE/"$currentDate
if [ "$(ls -A $archiveDir)" ]
	then
	cd $archiveDir	
	allFiles=$archiveDir/*
	for eachFile in $allFiles
	do
	eachUncompressedFiles=$(tar tzf $eachFile)
	filesCount=0	
	for i in $eachUncompressedFiles
	do
	filesCount=$[filesCount + 1]
	done
	isFileCame= false
	if [ $filesCount -gt 1 ]
		then
		isFileCame= true
		echo "File Exists in Archive Dir and the files are"
		for i in $eachUncompressedFiles
		do
		echo $i
		done
	fi
	done
	if [ "$isFileCame" == "false" ] 
		then
		echo "ETL File didn't come for "$currentDate
		exit
	fi
else
echo "ETL File didn't come for "$currentDate
exit
fi