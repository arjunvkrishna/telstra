#!/bin/sh
MONITORING_PATH=/home/siftuser/PSNM_Scripts/HealthCheck/Bundle_Monitoring
BUNDLE_INPUT_PATH=/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/input/BUNDLE_SNAPSHOT
COPY_TEMP=/data/BUNDLE_COPY_TEMP
TMP_FILE=$MONITORING_PATH/Input_Bundle_File_List.tmp
LOG_FILE=$MONITORING_PATH/Bundle_Final_Processing_`date +%Y%m%d`.log
rm $TMP_FILE

TOT_FILE_COUNT=100
FILE_COUNT=0

function sendEmailAlert ()
{
    emailSubject="SIFT EMAIL ALERT "\!\!\!" Bundle Monitoring - `date +%F`"
    toAddressArray=('Shabeena_M@infosys.com' 'Saikrishna_Doli@infosys.com' 'Shiju_R@infosys.com' 'Manoj_Kumar51@infosys.com' 'bhuvan.siddaramu@infosys.com')
#     toAddressArray=('Nirmal_Thekkekkota@infosys.com')
        echo $MSG | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
}


echo "`date '+%F %T'` | INFO | Starting Monitoring Script For Bundle Processing Of `date +%F`"  >> $LOG_FILE

ls -1 $COPY_TEMP/BAL_BUNDLE_`date +%Y%m%d`*.csv >> $TMP_FILE
FILE_COUNT=`cat $TMP_FILE | sort | uniq | wc -l`
echo "`date '+%F %T'` | INFO | $FILE_COUNT Files Has Been Feeded To SIFT Core From SO1 For Bundle Processing Of `date +%F`." >> $LOG_FILE

while [ $FILE_COUNT -ne $TOT_FILE_COUNT ]
do
sleep 20m
ls -1 $COPY_TEMP/BAL_BUNDLE_`date +%Y%m%d`*.csv >> $TMP_FILE
FILE_COUNT=`cat $TMP_FILE | sort | uniq | wc -l`
echo "`date '+%F %T'` | INFO | $FILE_COUNT Files Has Been Feeded To SIFT Core From SO1 For Bundle Processing Of `date +%F`." >> $LOG_FILE
currHour=`date "+%H"`
	if [ $FILE_COUNT -eq 0 ] && [ $currHour -eq 7 ];
	then
	echo "`date '+%F %T'` | ERR | No Files Feeded To SIFT Core From SO1 For Bundle Processing Of `date +%F`, Till 7 AM." >> $LOG_FILE
	echo "`date '+%F %T'` | ERR | Exiting Monitoring Script."  >> $LOG_FILE
	MSG="No Files Feeded To SIFT Core From SO1 For Bundle Processing Of `date +%F`, Till 7 AM. Monitoring Script Exit."
	sendEmailAlert
	exit
	fi
done
rm $COPY_TEMP/*.csv
echo "`date '+%F %T'` | INFO | All Bundles Files Has Been Feeded To SIFT Core For Bundle Processing Of `date +%F`." >> $LOG_FILE

FILES_REMAINING=`ls -1 $BUNDLE_INPUT_PATH/BAL_BUNDLE_*.csv | wc -l`
while [ $FILES_REMAINING -ne 0 ]
do
echo "`date '+%F %T'` | INFO | Bundle Processing For `date +%F` is in Progress. $FILES_REMAINING Bundle Files Remaining To Be Processed." >> $LOG_FILE
sleep 1m
FILES_REMAINING=`ls -1 $BUNDLE_INPUT_PATH/BAL_BUNDLE_*.csv | wc -l`
currHour=`date "+%H"`
	if [ $currHour -eq 23 ];
	then
	echo "`date '+%F %T'` | ERR | Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script."  >> $LOG_FILE
	MSG="Processing Going Beyond 11 PM. Forcefully Exiting Monitoring Script For The Day. Tomorrow's Instance Will Capture Processing of Tomorrow's File."
	sendEmailAlert
	exit
	fi
done

if [ $FILES_REMAINING -eq 0 ];
then
echo "`date '+%F %T'` | INFO | Bundle Processing For `date +%F` Completed." >> $LOG_FILE
MSG="Bundle Processing For `date +%F` Completed."
sendEmailAlert
exit
fi

