tar -cvzf /data/siftLogsArchive/SiftCoreLogs_`date +%Y%m%d`.tar.gz /opt/knowesis/sift/core/logs/corelogs/sift* >> /dev/null

