#!/bin/sh

(
echo "From: Telstra_SIFT@infosys.com "
echo "To:Nirmal_Thekkekkota@infosys.com"
echo "MIME-Version: 1.0"
echo "Subject: SIFT Daily Health Check Report"
echo "Content-Type: text/html"
cat health.html
) | sendmail -t
