#!/bin/bash
#########################################
## Change Permission Script
#########################################


#running the script 
#sh changePermission.sh JOB_NAME

#Dir Configs.
CONFIG_FILE=/opt/knowesis/sift/scripts/conf/changePermission.config
LOG_DIR=/opt/knowesis/sift/scripts/log
LOG_FILE=$LOG_DIR/changePermission_$(date +"%Y%m").log

#Job Cofigs
JOB_NAME=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $1}')
SOURCE_PATH=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $2}')   #/a/b/c
DESTINATION_PATH=$SOURCE_PATH/temp  #/a/b/c/temp
FILENAME_PATTERN=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $3}')
FNAME=$(eval echo $FILENAME_PATTERN)
FILE_PERMISSION=$(grep ^$1~ $CONFIG_FILE | awk -F'~' '{print $4}')
LOCK_FILE=/opt/knowesis/sift/scripts/lock/changePermission.sh.$JOB_NAME.lock

#Logger Function
function logger {
    echo "$(date) | $JOB_NAME | $1" >> $LOG_FILE
}

#if the destination dir. does not exist create the output folder
if [ ! -d $DESTINATION_PATH ]
then
	logger "INFO  | Temp folder doesn't exists"
    mkdir -p $DESTINATION_PATH
fi

##.this function does the following:
#1. change permission of the incoming files
#2. move the files to Output folder.


function changePermission {
	
	# Looping through the fileNames in dir.
    for file in $SOURCE_PATH/$FNAME;
    do
    	if [[ "$file" != *"$SOURCE_PATH"* ]]; then
    		file=$SOURCE_PATH/$file
    	fi
        
        # Check if the files are one min older
	if [ ! $(find $file -mmin +1) ];
        then
            logger "ERROR | The file - $file is quite fresh. Will continue to the next file"
            continue;
        fi

        # Changing the permission of the files (both .csv and .eot files)
        chmod $FILE_PERMISSION ${file%%.*}*

        if [ $? -eq 0 ];
        then
            logger "INFO  | File Permission changed for $file to $FILE_PERMISSION with Status - $?"
            # Moving the files to the Output dir. 
            mv ${file%%.*}* $DESTINATION_PATH
            logger "INFO  | Moved $file to destination dir with status - $?"
        else
            logger "ERROR  | Changing Permission failed for $file . Moving on to next file."
        fi

    done 
}


if [ -f $LOCK_FILE ]
then
        if [ $(find $LOCK_FILE -mtime +1) ]
        then
            rm $LOCK_FILE
            logger "WARN | Script was abruptly exited. Removed the lock file with status $?"
        else
            logger "ERROR | Script is currently running for the Job $1, Exiting now.!"
            exit 1
        fi
fi

#Creating lock file
touch $LOCK_FILE
logger "INFO  | Lock File generated with status $?"

logger "INFO  | Starting Processing"
changePermission
logger "INFO  | Processing Completed.! "

#Removing lock file
rm $LOCK_FILE
logger "INFO  | Lock File deleted with status $?"
