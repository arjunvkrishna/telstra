#!/bin/sh

APOLLO_USER_ID=sift
APOLLO_IP=asapnrmgt1-b.ain.nexus.telstra.com.au
APOLLO_SOURCE_FILE_DIRECTORY=/ETL/OUTPUT/intelestage
SIFT_INPUT_DIRECTORY=/data/ingest/APOLLO
SSH_KEY_PATH=/home/siftuser/ssh_keys/prodsiftcore1
tempDir=/ETL/OUTPUT/intelestage/siftTemp


if [ "$#" -ne 1 ]
then
	echo "Specify pattern !!"
	exit
fi

PATTERN=$1
LOGFILE=/opt/knowesis/sift/core/sift/scripts/ApolloPullLogs/apollo_${PATTERN}_datapull_`date +%F`.log
echo "===================================================================" >> ${LOGFILE}
echo "Starting to pull Apollo Files at `date`" >> ${LOGFILE}
CONTROL_FILE=/home/siftuser/apollo${PATTERN}datapull.ctl
dateTime=`date`
echo "Starting CDR File Pull @ $dateTime" >> ${LOGFILE}

if [ -f ${CONTROL_FILE} ]
then
        echo "CDR Pull already in progress.">> ${LOGFILE}
        exit
else
        touch ${CONTROL_FILE}
        fileDate=`date +%d%m%Y --date="yesterday"`

                echo "Copying Files from Apollo">> ${LOGFILE}
                ssh -i ${SSH_KEY_PATH} -q ${APOLLO_USER_ID}@${APOLLO_IP}  "mv  ${APOLLO_SOURCE_FILE_DIRECTORY}/*${PATTERN}* ${tempDir} " 2>/dev/null
		echo "Moving Files : ">> ${LOGFILE}
		a=`ssh  -i ${SSH_KEY_PATH} ${APOLLO_USER_ID}@${APOLLO_IP}  "ls ${tempDir}/*${PATTERN}*  "`
		echo $a|tr ' ' '\n' >> ${LOGFILE}
		scp -i ${SSH_KEY_PATH} ${APOLLO_USER_ID}@${APOLLO_IP}:${tempDir}/*${PATTERN}* ${SIFT_INPUT_DIRECTORY}
		echo "Removing Copied Files." >>${LOGFILE}
		ssh -i ${SSH_KEY_PATH} -q ${APOLLO_USER_ID}@${APOLLO_IP}  " rm ${tempDir}/*${PATTERN}* "
        dateTime=`date`
        echo "CDR File Pull Completed @ $dateTime" >>${LOGFILE}
        rm ${CONTROL_FILE}
        echo "===================================================================" >>${LOGFILE}
fi
