SUBJECT="[TELSTRA]Disk Usage Alert on "`date`""
MESSAGE="/home/siftuser/kw_utils/disk-usage.out"
MESSAGE1="/home/siftuser/kw_utils/disk-usage-1.out"
THRESHOLD="80"
TO="chakravarthi@knowesis.com, Twinku.Thomas@team.telstra.com"
echo "----------------------------------------------" >> $MESSAGE1
echo "HostName     Mounted on  Use%" >> $MESSAGE1
echo "----------------------------------------------" >> $MESSAGE1
for server in `more /home/siftuser/kw_utils/servers.list`
do
output=`ssh $server df -Ph| grep -vE '^Filesystem|tmpfs|cdrom|/dev/mapper/VG00-lv_root|/dev/sda1|/repo' |awk '{print $6"\t"$5}'| sed s/%//g | awk '{ if($2 > 80) print $0;}'`
if [ "$output" != "" ]; then
echo -e "\n$server\t:\t$output" >> $MESSAGE
fi
done
if [ -s "$MESSAGE" ]; then
cat $MESSAGE | column -t >> $MESSAGE1
mailx -S smtp=mail.in.telstra.com.au -s "$SUBJECT" "$TO" < $MESSAGE1
fi
rm $MESSAGE
rm $MESSAGE1
