sar -P ALL -f /var/log/sa/sa04 > /home/siftuser/kw_utils/CPU04
sar -P ALL -f /var/log/sa/sa03 > /home/siftuser/kw_utils/CPU03
sar -P ALL -f /var/log/sa/sa02 > /home/siftuser/kw_utils/CPU02
sar -P ALL -f /var/log/sa/sa01 > /home/siftuser/kw_utils/CPU01
sar -P ALL -f /var/log/sa/sa30 > /home/siftuser/kw_utils/CPU30
sar -P ALL -f /var/log/sa/sa29 > /home/siftuser/kw_utils/CPU29
sar -P ALL -f /var/log/sa/sa28 > /home/siftuser/kw_utils/CPU28
