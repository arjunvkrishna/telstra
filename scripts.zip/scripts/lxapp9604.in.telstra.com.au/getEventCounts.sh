#!/bin/sh
if [ $# -eq 0 ]
	then
	currentDate=$(date +"%F")
	echo "No Date Supplied So counting the files for today i.e., "$currentDate
else
	currentDate=$(date -d "$1" +"%F")
	if [[ -z "$currentDate" ]]
        then
        echo "Please supply the date in YYYY-MM-DD Format i.e.,"$(date +"%F")
        exit
        fi
	echo "Date Supplied is "$currentDate
fi
timestamp=`date +%s --date="${currentDate} 10:00:00"`
# If condition to check for the Event Ids File Existance
if [ ! -f "/home/siftuser/PSNM_Scripts/EventIds_List_For_Counts.txt" ]; then
    echo "Event File Not Found, Please create a Event File EventIds_List_For_Counts.txt and add the event names for which you wanto to generate the stats"
    exit
fi
#inputDateTimeStamp=$(date -d $currentDate +%s)
#today_Date=`date +%s --date="$date 00:00:00"`
#if [ "$inputDateTimeStamp" -lt "$today_Date" ]; then
#sinkFilesPath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/"$currentDate"/Event_Sink_FS1-*"${timestamp}"*.csv"
#fileCount=`ls /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/$currentDate"/"Event_Sink_FS1-*${timestamp}*.csv|wc -l`
#else
#sinkFilesPath="/opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*"${timestamp}"*.csv"
#fileCount=`ls /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*${timestamp}*.csv|wc -l`
#fi
#fileCount=`ls $sinkFilesPath|wc -l`
#if [ $fileCount -eq 0 ]
#then
#	echo "No event Files for "$currentDate
#	exit
#fi
# Event COunts Output will be stored in this folder
mkdir -p /home/siftuser/PSNM_Scripts/Output_EventCounts
#echo "Event_Id Count for "$currentDate" is"
rm -f /home/siftuser/PSNM_Scripts/Output_EventCounts/EventCounts_$currentDate.csv
exec > /home/siftuser/PSNM_Scripts/Output_EventCounts/EventCounts_$currentDate.csv
# For loop to run recursively for all the events in EventIds_List_For_Counts.txt
for i in `cat /home/siftuser/PSNM_Scripts/EventIds_List_For_Counts.txt`
do
#count=$(grep '"'$i'"' /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/Event_Sink_FS1-*${timestamp}*.csv | wc -l)
cd /opt/knowesis/sift/core/sift/pworkspace/SiFT_Source_data/data/
count=$(grep -r '"'$i'"' --include="Event_Sink_FS1-*${timestamp}*.csv" --exclude-dir={all_old_event_files} . | wc -l)
echo $i","$count
done
#####################################################################
# Function   : sendFilesSFTP
# Description: This function does the following
#              -> transfers the files to lxfile 0023
# Input Args : None
#####################################################################
function sendFilesSFTP ()
{
    AthenianFileServer="lxfile0023.in.telstra.com.au"
    AthenianUserId="n100417"
    AthenianPath="/Athenian/Sift/reporting/BAU_reporting"
    EventCountFile="/home/siftuser/PSNM_Scripts/Output_EventCounts/EventCounts_$currentDate.csv"
    scp -p $EventCountFile $AthenianUserId@$AthenianFileServer:$AthenianPath
    scp_status=`echo $?`
    if [ $scp_status -ne 0 ]
    then
        echo "Failed to TRANSFER the file `basename $EventCountFile` to Athenian file Server" 
        exit 1
    fi
 
    echo "Sucessfully transferred the files `basename $EventCountFile` to Athenian file server" 
    exit 0
}

sendFilesSFTP



