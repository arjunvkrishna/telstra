#!/bin/sh
SO1=lxapp9606.in.telstra.com.au
SO2=lxapp9607.in.telstra.com.au
SO3=lxapp9608.in.telstra.com.au
PING_STATUS_DIR=/home/siftuser/PSNM_Scripts/PersistPingStatus
TODAY_DATE=`date "+%Y%m%d"`
PING_NO=1
SO1_STATUS_FILE=lxapp9606_Pings_${TODAY_DATE}.txt
SO2_STATUS_FILE=lxapp9607_Pings_${TODAY_DATE}.txt
SO3_STATUS_FILE=lxapp9608_Pings_${TODAY_DATE}.txt

function sendEmailAlert ()
{
emailSubject="SIFT EMAIL ALERT "\!\!\!" $NOTIFY_MSG - `date +%F`"
toAddressArray=('Shabeena_M@infosys.com' 'Saikrishna_Doli@infosys.com' 'Shiju_R@infosys.com' 'Manoj_Kumar51@infosys.com' 'bhuvan.siddaramu@infosys.com')
tail -7 ${LOG_FILE} | head -6 | mailx -s "`echo $emailSubject`"  -S smtp=mail.in.telstra.com.au  "`echo ${toAddressArray[*]}`"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0408574590@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0466961887@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919496152994@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "919663679814@sms.in.telstra.com.au"
echo $NOTIFY_MSG | mailx -s $NOTIFY_MSG "0431812571@sms.in.telstra.com.au"
}
echo "Pinging at `date +"%Y-%m-%d %H:%M:%S"`" >> ${PING_STATUS_DIR}/${SO1_STATUS_FILE}
ping -c${PING_NO} ${SO1} >> ${PING_STATUS_DIR}/${SO1_STATUS_FILE}
tail -2 ${PING_STATUS_DIR}/${SO1_STATUS_FILE} | head -1 | grep '100% packet loss'
if [ $? -eq 0 ]
then
LOG_FILE=${PING_STATUS_DIR}/${SO1_STATUS_FILE}
NOTIFY_MSG="Unable to Ping lxapp9606"
sendEmailAlert
fi

echo "Pinging at `date +"%Y-%m-%d %H:%M:%S"`" >> ${PING_STATUS_DIR}/${SO2_STATUS_FILE}
ping -c${PING_NO} ${SO2} >> ${PING_STATUS_DIR}/${SO2_STATUS_FILE}
tail -2 ${PING_STATUS_DIR}/${SO2_STATUS_FILE} | head -1 | grep '100% packet loss'
if [ $? -eq 0 ]
then
LOG_FILE=${PING_STATUS_DIR}/${SO2_STATUS_FILE}
NOTIFY_MSG="Unable to Ping lxapp9607"
sendEmailAlert
fi

echo "Pinging at `date +"%Y-%m-%d %H:%M:%S"`" >> ${PING_STATUS_DIR}/${SO3_STATUS_FILE}
ping -c${PING_NO} ${SO3} >> ${PING_STATUS_DIR}/${SO3_STATUS_FILE}
tail -2 ${PING_STATUS_DIR}/${SO3_STATUS_FILE} | head -1 | grep '100% packet loss'
if [ $? -eq 0 ]
then
LOG_FILE=${PING_STATUS_DIR}/${SO3_STATUS_FILE}
NOTIFY_MSG="Unable to Ping lxapp9608"
sendEmailAlert
fi

