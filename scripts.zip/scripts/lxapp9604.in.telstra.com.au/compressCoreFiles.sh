#Parent Path to be Defined Here
folderPathToCompress=/data/ARCHIVE/
#Log will be written in this file
mkdir -p $folderPathToCompress"logs"
exec >>  /data/ARCHIVE/logs/compress_`date +%F`.log
echo "==================================================================="
#Function to Compress the Folders
function compress_Dir ()
{
echo "Compress Process Has Started For "$1" Directory at `date "+%Y%m%d%H%M%S"`"
        date_Folder=`date --date="1 days ago" +"%F"`
        folderPath=$folderPathToCompress$1"/"$date_Folder"/"
        if [ -d "$folderPath" ]
        then
        cd $folderPath
        allDirs=$(ls -trh $folderPath)
        for eachDir in ${allDirs}
        do
	if [ -d "$eachDir" ]
	then
        archive_Dir_Name=$folderPath$eachDir".tar.gz"
        actual_Dir_Name=$folderPath$eachDir
        #export GZIP=-9
        tar cfz $archive_Dir_Name -P $actual_Dir_Name
        rm -rf $actual_Dir_Name
	fi
        done
        fi
echo "Compress Process Has Finished For "$1" at `date "+%Y%m%d%H%M%S"`"
}
# For loop to define what all the folders to be Compress
for i in CDR LDR PROFILE MOB_ACTIVITY MODEL_SCORE
#for i in MOB_ACTIVITY_1 MODEL_SCORE_1
do
       compress_Dir $i
done
echo "==================================================================="
